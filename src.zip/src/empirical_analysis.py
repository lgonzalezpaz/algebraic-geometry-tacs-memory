#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
empirical_analysis.py
=====================
Extracts, verifies, and statistically analyzes the complete empirical human dataset
from Akturk & Sack (2026) (OSF: https://osf.io/4xwkj/; Cortex 205:154-175),
combining participant-level behavioral/EEG spectral records (N = 42, 252 sessions)
with trial-level Temporal Order Judgment (TOJ) and confidence ratings (8,032 trials
decoded from RAW_TOJ.zip).

Also loads and characterizes the Desikan-Killiany 68-region human structural
connectome (dk68) to extract empirical fronto-parietal-hippocampal tract lengths,
conduction delays, and coupling weights.
"""

from __future__ import annotations
import os
import io
import zipfile
import struct
import warnings
import numpy as np
import pandas as pd
import scipy.io
import scipy.stats as stats
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests

warnings.filterwarnings("ignore", category=FutureWarning)

BASE_DIR = r"C:\Users\CBM\.gemini\antigravity\scratch\algebraic-geometry-tacs-memory"
OSF_DIR = os.path.join(BASE_DIR, "data", "osf")
DK68_DIR = os.path.join(BASE_DIR, "data", "dk68")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)


def load_dk68_connectome():
    """Load and summarize the 68-region human structural connectome."""
    weights = np.loadtxt(os.path.join(DK68_DIR, "dk68_weights.txt"))
    lengths = np.loadtxt(os.path.join(DK68_DIR, "dk68_tract_lengths.txt"))
    centres = np.loadtxt(os.path.join(DK68_DIR, "dk68_centres.txt"), usecols=(1, 2, 3))
    with open(os.path.join(DK68_DIR, "dk68_regions.txt"), "r", encoding="utf-8") as f:
        regions = [line.strip() for line in f if line.strip()]

    # Identify fronto-parietal and hippocampal/parahippocampal ROIs matching LF/LP, RF/RP
    idx_map = {r: i for i, r in enumerate(regions)}
    lf_names = ["l_rostralmiddlefrontal", "l_caudalmiddlefrontal", "l_superiorfrontal", "l_parsopercularis"]
    lp_names = ["l_inferiorparietal", "l_superiorparietal", "l_supramarginal", "l_precuneus"]
    rf_names = ["r_rostralmiddlefrontal", "r_caudalmiddlefrontal", "r_superiorfrontal", "r_parsopercularis"]
    rp_names = ["r_inferiorparietal", "r_superiorparietal", "r_supramarginal", "r_precuneus"]
    hipp_names = ["l_parahippocampal", "l_entorhinal", "r_parahippocampal", "r_entorhinal"]

    def mean_submatrix(rows, cols, mat):
        vals = [mat[idx_map[r], idx_map[c]] for r in rows for c in cols if mat[idx_map[r], idx_map[c]] > 0]
        return float(np.mean(vals)) if vals else 0.0

    # Weighted average tract length across connected fronto-parietal edges
    fp_lengths = []
    fp_weights = []
    for r in lf_names:
        for c in lp_names:
            w = weights[idx_map[r], idx_map[c]]
            L = lengths[idx_map[r], idx_map[c]]
            if w > 0 and L > 0:
                fp_lengths.append(L)
                fp_weights.append(w)

    fp_lengths = np.array(fp_lengths)
    fp_weights = np.array(fp_weights)
    w_mean_L_fp = float(np.sum(fp_lengths * fp_weights) / np.sum(fp_weights))
    u_mean_L_fp = float(np.mean(fp_lengths))

    # Whole-brain summary
    upper = np.triu_indices(68, k=1)
    nz = weights[upper] > 0
    summary = {
        "n_regions": len(regions),
        "edge_density": float(np.mean(nz)),
        "mean_tract_length_mm": float(np.mean(lengths[upper][nz])),
        "weighted_mean_tract_length_mm": float(np.sum(lengths[upper][nz] * weights[upper][nz]) / np.sum(weights[upper][nz])),
        "lf_lp_mean_length_mm": u_mean_L_fp,
        "lf_lp_weighted_length_mm": w_mean_L_fp,
        "lf_lp_mean_weight": mean_submatrix(lf_names, lp_names, weights),
        "rf_rp_mean_weight": mean_submatrix(rf_names, rp_names, weights),
        "lf_hipp_mean_length_mm": mean_submatrix(lf_names, hipp_names[:2], lengths),
        "lp_hipp_mean_length_mm": mean_submatrix(lp_names, hipp_names[:2], lengths),
    }
    return weights, lengths, centres, regions, summary


def decode_mat_trials(raw_bytes):
    """
    Decode trial-level arrays from a RAW_TOJ.zip .mat file.
    Extracts numeric columns stored in __function_workspace__ of the MATLAB table
    (verified against A_VM.m and SubjectInfo_and_BehavioralData.xlsx).
    """
    mat = scipy.io.loadmat(io.BytesIO(raw_bytes))
    acc_val = float(mat["accuracy"][0, 0])
    rt_val = float(mat["meanReactionTime"][0, 0])
    acc_arr = mat["accuracyArray"].flatten().astype(np.float64)
    rt_arr = mat["responseTimes"].flatten().astype(np.float64)
    rk_arr = mat["responseKeys"].flatten().astype(np.float64)
    fixed_order = mat["fixedOrder"].flatten().astype(int)
    item_pairs = mat["itemPairs"]
    # Extract pair indices (1..72) -> find positions in fixedOrder
    pos_map = {int(val): idx for idx, val in enumerate(fixed_order)}
    lags = np.zeros(len(acc_arr), dtype=float)
    for t in range(len(acc_arr)):
        i1 = int(item_pairs[t, 0].flat[0])
        i2 = int(item_pairs[t, 1].flat[0])
        if i1 in pos_map and i2 in pos_map:
            lags[t] = abs(pos_map[i1] - pos_map[i2])
        else:
            lags[t] = np.nan

    fws = mat["__function_workspace__"].tobytes()
    tag = struct.pack("<II", 9, 256)  # miDOUBLE, 32 * 8 bytes
    pos = 0
    arrays = []
    while True:
        idx = fws.find(tag, pos)
        if idx == -1:
            break
        arr = np.frombuffer(fws[idx + 8 : idx + 8 + 256], dtype="<f8")
        arrays.append(arr)
        pos = idx + 8

    # Verify exact match of accuracy and responseTimes inside table columns
    # arrays[3] == accuracyArray, arrays[4] == responseTimes, arrays[5] == confidenceRatings
    assert len(arrays) >= 6, f"Expected >=6 arrays in workspace, got {len(arrays)}"
    assert np.allclose(arrays[3], acc_arr, atol=1e-9), "Table accuracy mismatch"
    assert np.allclose(arrays[4], rt_arr, atol=1e-9), "Table RT mismatch"
    conf_arr = arrays[5].astype(int)
    return {
        "acc_val": acc_val,
        "rt_val": rt_val,
        "acc_arr": acc_arr,
        "rt_arr": rt_arr,
        "rk_arr": rk_arr,
        "conf_arr": conf_arr,
        "lags": lags,
    }


def compute_auroc2(acc_arr, conf_arr):
    """
    Compute non-parametric Type-2 AUROC (metacognitive sensitivity) from
    binary accuracy and ordinal confidence ratings (1=Sure/High, 2=Unsure, 3=Guessing).
    """
    # Invert scale so higher value = higher confidence (Sure=3, Unsure=2, Guessing=1)
    # Note: handle any rare key '4' (seen in 4-key handler in A_VM.m) as lowest confidence
    conf_score = np.where(conf_arr == 1, 3, np.where(conf_arr == 2, 2, 1))
    correct = acc_arr == 1
    incorrect = acc_arr == 0
    if np.sum(correct) == 0 or np.sum(incorrect) == 0:
        return np.nan
    n_c = np.sum(correct)
    n_i = np.sum(incorrect)
    levels = [1, 2, 3]
    far2 = [0.0]
    hr2 = [0.0]
    for lv in reversed(levels):
        hr2.append(np.sum(correct & (conf_score >= lv)) / n_c)
        far2.append(np.sum(incorrect & (conf_score >= lv)) / n_i)
    return float(np.trapezoid(hr2, far2))


def parse_empirical_dataset():
    xlsx_path = os.path.join(OSF_DIR, "SubjectInfo_and_BehavioralData.xlsx")
    zip_path = os.path.join(OSF_DIR, "RAW_TOJ.zip")

    df = pd.read_excel(xlsx_path, header=1)
    # Exclude subjects flagged in NOTES as dropped/excluded: 9, 19, 35, 45
    df42 = df[~df["Subject No"].isin([9, 19, 35, 45]) & df["Subject No"].notna()].copy()
    df42["Subject No"] = df42["Subject No"].astype(int)
    df42["Group"] = df42["Group"].astype(int)

    z = zipfile.ZipFile(zip_path, "r")
    namelist = set(z.namelist())

    session_specs = [
        ("inphase", "", "IP"),
        ("antiphase", ".1", "AP"),
        ("sham", ".2", "Sham"),
    ]

    session_rows = []
    trial_rows = []

    for _, row in df42.iterrows():
        sid = int(row["Subject No"])
        grp = int(row["Group"])
        grp_label = "ITF-1" if grp == 1 else "ITF+1"
        age = pd.to_numeric(row["Age"], errors="coerce")
        edu = pd.to_numeric(row["Edu (Year)"], errors="coerce")
        gender = pd.to_numeric(row["Gender"], errors="coerce")

        # Load all non-training .mat files for this subject
        mat_sessions = {}
        for s in range(1, 7):
            fn = f"t_task_{sid:03d}_session0{s}.mat"
            if fn in namelist:
                mat_sessions[fn] = decode_mat_trials(z.read(fn))

        used_mats = set()

        for sess_name, sfx, sess_short in session_specs:
            pre_itf = float(pd.to_numeric(row[f"pre_ITF (4-7 Hz){sfx}"], errors="coerce"))
            post_itf = float(pd.to_numeric(row[f"post_ITF (4-7 Hz){sfx}"], errors="coerce"))
            pre_itf_p = float(pd.to_numeric(row[f"pre_ITF_power (4-7 Hz){sfx}"], errors="coerce"))
            post_itf_p = float(pd.to_numeric(row[f"post_ITF_power (4-7 Hz){sfx}"], errors="coerce"))
            pre_th_p = float(pd.to_numeric(row[f"pre_theta_power (4-7 Hz){sfx}"], errors="coerce"))
            post_th_p = float(pd.to_numeric(row[f"post_theta_power (4-7 Hz){sfx}"], errors="coerce"))
            stim_freq = float(pd.to_numeric(row[f"Stim freq{sfx}"], errors="coerce"))
            stim_amp = float(pd.to_numeric(row[f"Stim Intensity{sfx}"], errors="coerce"))

            pre_fr = float(pd.to_numeric(row[f"Pre-Free Recall{sfx}"], errors="coerce"))
            post_fr = float(pd.to_numeric(row[f"Post-Free Recall{sfx}"], errors="coerce"))
            pre_acc = float(pd.to_numeric(row[f"Pre-Accuracy{sfx}"], errors="coerce"))
            post_acc = float(pd.to_numeric(row[f"Post-Accuracy{sfx}"], errors="coerce"))
            pre_rt = float(pd.to_numeric(row[f"Pre-MeanReactionTime{sfx}"], errors="coerce"))
            post_rt = float(pd.to_numeric(row[f"Post-MeanReactionTime{sfx}"], errors="coerce"))
            pre_rt_c = float(pd.to_numeric(row[f"Pre-MeanReactionTime - Correct response{sfx}"], errors="coerce"))
            post_rt_c = float(pd.to_numeric(row[f"Post-MeanReactionTime - Correct response{sfx}"], errors="coerce"))
            pre_rt_i = float(pd.to_numeric(row[f"Pre-MeanReactionTime - Incorrect response{sfx}"], errors="coerce"))
            post_rt_i = float(pd.to_numeric(row[f"Post-MeanReactionTime - Incorrect response{sfx}"], errors="coerce"))

            # Match Pre and Post .mat files
            meta_metrics = {}
            for phase_key, t_acc, t_rt in [("Pre", pre_acc, pre_rt), ("Post", post_acc, post_rt)]:
                best_fn = None
                best_diff = 1e9
                for fn, d in mat_sessions.items():
                    if fn in used_mats:
                        continue
                    diff = abs(d["acc_val"] - t_acc) + abs(d["rt_val"] - t_rt) * 10.0
                    if diff < best_diff:
                        best_diff = diff
                        best_fn = fn

                # Allow Subj 31 S3_Pre (exact accuracy 43.75, RT typo 1.967 vs 1.697)
                matched = False
                if best_fn is not None:
                    d_best = mat_sessions[best_fn]
                    if abs(d_best["acc_val"] - t_acc) < 0.05 and (abs(d_best["rt_val"] - t_rt) < 0.05 or (sid == 31 and sess_name == "sham" and phase_key == "Pre")):
                        matched = True
                        used_mats.add(best_fn)

                if matched:
                    d = mat_sessions[best_fn]
                    c_arr = d["conf_arr"]
                    a_arr = d["acc_arr"]
                    high_m = c_arr == 1
                    low_m = c_arr > 1
                    p_high = float(np.mean(high_m))
                    hca = float(np.mean(a_arr[high_m])) if np.any(high_m) else np.nan
                    lca = float(np.mean(a_arr[low_m])) if np.any(low_m) else np.nan
                    sep = hca - lca if (not np.isnan(hca) and not np.isnan(lca)) else np.nan
                    auroc2 = compute_auroc2(a_arr, c_arr)
                    meta_metrics[phase_key] = {
                        "pHigh": p_high,
                        "HCA": hca,
                        "LCA": lca,
                        "Sep": sep,
                        "AUROC2": auroc2,
                        "mat_file": best_fn,
                    }
                    for t_idx in range(len(a_arr)):
                        trial_rows.append(
                            {
                                "subj": sid,
                                "group": grp,
                                "group_label": grp_label,
                                "session": sess_name,
                                "phase": phase_key,
                                "trial": t_idx + 1,
                                "accuracy": int(a_arr[t_idx]),
                                "rt": float(d["rt_arr"][t_idx]),
                                "confidence": int(c_arr[t_idx]),
                                "high_conf": int(c_arr[t_idx] == 1),
                                "lag": float(d["lags"][t_idx]),
                                "pre_ITF": pre_itf,
                                "stim_freq": stim_freq,
                            }
                        )
                else:
                    meta_metrics[phase_key] = {
                        "pHigh": np.nan,
                        "HCA": np.nan,
                        "LCA": np.nan,
                        "Sep": np.nan,
                        "AUROC2": np.nan,
                        "mat_file": "MISSING",
                    }

            session_rows.append(
                {
                    "subj": sid,
                    "group": grp,
                    "group_label": grp_label,
                    "age": age,
                    "gender": gender,
                    "edu_years": edu,
                    "session": sess_name,
                    "session_short": sess_short,
                    "pre_ITF": pre_itf,
                    "post_ITF": post_itf,
                    "dITF": post_itf - pre_itf,
                    "pre_ITF_power": pre_itf_p,
                    "post_ITF_power": post_itf_p,
                    "dITF_power": post_itf_p - pre_itf_p,
                    "pre_theta_power": pre_th_p,
                    "post_theta_power": post_th_p,
                    "dTheta_power": post_th_p - pre_th_p,
                    "stim_freq": stim_freq,
                    "detuning_Hz": stim_freq - pre_itf,
                    "stim_amp_mA": stim_amp,
                    "pre_recall": pre_fr,
                    "post_recall": post_fr,
                    "dRecall": post_fr - pre_fr,
                    "pre_acc": pre_acc,
                    "post_acc": post_acc,
                    "dAcc": post_acc - pre_acc,
                    "pre_rt": pre_rt,
                    "post_rt": post_rt,
                    "dRT": post_rt - pre_rt,
                    "pre_rt_corr": pre_rt_c,
                    "post_rt_corr": post_rt_c,
                    "pre_rt_incorr": pre_rt_i,
                    "post_rt_incorr": post_rt_i,
                    "pre_rt_asym": pre_rt_i - pre_rt_c,
                    "post_rt_asym": post_rt_i - post_rt_c,
                    "dRT_asym": (post_rt_i - post_rt_c) - (pre_rt_i - pre_rt_c),
                    "pHigh_pre": meta_metrics["Pre"]["pHigh"],
                    "pHigh_post": meta_metrics["Post"]["pHigh"],
                    "dpHigh": meta_metrics["Post"]["pHigh"] - meta_metrics["Pre"]["pHigh"],
                    "HCA_pre": meta_metrics["Pre"]["HCA"],
                    "HCA_post": meta_metrics["Post"]["HCA"],
                    "LCA_pre": meta_metrics["Pre"]["LCA"],
                    "LCA_post": meta_metrics["Post"]["LCA"],
                    "Sep_pre": meta_metrics["Pre"]["Sep"],
                    "Sep_post": meta_metrics["Post"]["Sep"],
                    "dSep": meta_metrics["Post"]["Sep"] - meta_metrics["Pre"]["Sep"],
                    "AUROC2_pre": meta_metrics["Pre"]["AUROC2"],
                    "AUROC2_post": meta_metrics["Post"]["AUROC2"],
                    "dAUROC2": meta_metrics["Post"]["AUROC2"] - meta_metrics["Pre"]["AUROC2"],
                }
            )

    sess_df = pd.DataFrame(session_rows)
    trial_df = pd.DataFrame(trial_rows)
    return df42, sess_df, trial_df


def run_statistical_models(sess_df):
    """Run exact LMMs matching the OSF R scripts (change score LMM & ANCOVA LMM)."""
    stat_records = []

    # 1. TOJ Accuracy change: dAcc ~ C(session) * C(group_label) + (1 | subj)
    df_acc = sess_df.dropna(subset=["dAcc"]).copy()
    m_acc = smf.mixedlm("dAcc ~ C(session, Treatment('sham')) * C(group_label, Treatment('ITF-1'))", df_acc, groups=df_acc["subj"]).fit(reml=False)
    wt_acc = m_acc.wald_test_terms(scalar=True)
    for term, row in wt_acc.table.iterrows():
        stat_records.append({
            "outcome": "TOJ_dAcc",
            "term": term,
            "statistic": float(row["statistic"]),
            "df_num": float(row["df_constraint"]),
            "p_value": float(row["pvalue"]),
        })

    # 2. Free Recall change: dRecall ~ C(session) * C(group_label) + (1 | subj)
    df_fr = sess_df.dropna(subset=["dRecall"]).copy()
    m_fr = smf.mixedlm("dRecall ~ C(session, Treatment('sham')) * C(group_label, Treatment('ITF-1'))", df_fr, groups=df_fr["subj"]).fit(reml=False)
    wt_fr = m_fr.wald_test_terms(scalar=True)
    for term, row in wt_fr.table.iterrows():
        stat_records.append({
            "outcome": "FreeRecall_dRecall",
            "term": term,
            "statistic": float(row["statistic"]),
            "df_num": float(row["df_constraint"]),
            "p_value": float(row["pvalue"]),
        })

    # 3. Metacognitive Separation ANCOVA: Sep_post ~ Sep_pre + C(session) * C(group_label) + (1 | subj)
    df_sep = sess_df.dropna(subset=["Sep_pre", "Sep_post"]).copy()
    m_sep = smf.mixedlm("Sep_post ~ Sep_pre + C(session, Treatment('sham')) * C(group_label, Treatment('ITF-1'))", df_sep, groups=df_sep["subj"]).fit(reml=False)
    wt_sep = m_sep.wald_test_terms(scalar=True)
    for term, row in wt_sep.table.iterrows():
        stat_records.append({
            "outcome": "Metacog_Sep_ANCOVA",
            "term": term,
            "statistic": float(row["statistic"]),
            "df_num": float(row["df_constraint"]),
            "p_value": float(row["pvalue"]),
        })

    # 4. Confidence bias ANCOVA: pHigh_post ~ pHigh_pre + C(session) * C(group_label) + (1 | subj)
    df_ph = sess_df.dropna(subset=["pHigh_pre", "pHigh_post"]).copy()
    m_ph = smf.mixedlm("pHigh_post ~ pHigh_pre + C(session, Treatment('sham')) * C(group_label, Treatment('ITF-1'))", df_ph, groups=df_ph["subj"]).fit(reml=False)
    wt_ph = m_ph.wald_test_terms(scalar=True)
    for term, row in wt_ph.table.iterrows():
        stat_records.append({
            "outcome": "ConfidenceBias_pHigh_ANCOVA",
            "term": term,
            "statistic": float(row["statistic"]),
            "df_num": float(row["df_constraint"]),
            "p_value": float(row["pvalue"]),
        })

    # 5. Resting Theta Power change: dTheta_power ~ C(session) * C(group_label) + (1 | subj)
    df_th = sess_df.dropna(subset=["dTheta_power"]).copy()
    m_th = smf.mixedlm("dTheta_power ~ C(session, Treatment('sham')) * C(group_label, Treatment('ITF-1'))", df_th, groups=df_th["subj"]).fit(reml=False)
    wt_th = m_th.wald_test_terms(scalar=True)
    for term, row in wt_th.table.iterrows():
        stat_records.append({
            "outcome": "Resting_dTheta_power",
            "term": term,
            "statistic": float(row["statistic"]),
            "df_num": float(row["df_constraint"]),
            "p_value": float(row["pvalue"]),
        })

    # Specific planned contrasts (matching R scripts)
    contrasts = []
    # Between-group per session on dAcc
    for sess in ["inphase", "antiphase", "sham"]:
        g1 = df_acc[(df_acc["group_label"] == "ITF-1") & (df_acc["session"] == sess)]["dAcc"].values
        g2 = df_acc[(df_acc["group_label"] == "ITF+1") & (df_acc["session"] == sess)]["dAcc"].values
        t_val, p_val = stats.ttest_ind(g1, g2, equal_var=False)
        sp = np.sqrt(((len(g1) - 1) * np.var(g1, ddof=1) + (len(g2) - 1) * np.var(g2, ddof=1)) / (len(g1) + len(g2) - 2))
        d_val = (np.mean(g1) - np.mean(g2)) / sp
        contrasts.append({
            "family": "TOJ_dAcc_between_group",
            "contrast": f"{sess}: ITF-1 vs ITF+1",
            "n1": len(g1), "n2": len(g2),
            "mean1": float(np.mean(g1)), "mean2": float(np.mean(g2)),
            "diff": float(np.mean(g1) - np.mean(g2)),
            "t_stat": float(t_val), "p_raw": float(p_val), "effect_d": float(d_val),
        })

    # Within-group paired contrasts on Sep_post (ANCOVA adjusted and dSep)
    for grp in ["ITF-1", "ITF+1"]:
        sub = df_sep[df_sep["group_label"] == grp].pivot(index="subj", columns="session", values="Sep_post").dropna()
        sub_d = df_sep[df_sep["group_label"] == grp].pivot(index="subj", columns="session", values="dSep").dropna()
        for s1, s2 in [("inphase", "antiphase"), ("inphase", "sham"), ("antiphase", "sham")]:
            t_p, p_p = stats.ttest_rel(sub[s1], sub[s2])
            diff = sub[s1] - sub[s2]
            d_p = float(np.mean(diff) / np.std(diff, ddof=1))
            contrasts.append({
                "family": f"Metacog_SepPost_within_{grp}",
                "contrast": f"{s1} vs {s2}",
                "n1": len(sub), "n2": len(sub),
                "mean1": float(np.mean(sub[s1])), "mean2": float(np.mean(sub[s2])),
                "diff": float(np.mean(diff)),
                "t_stat": float(t_p), "p_raw": float(p_p), "effect_d": d_p,
            })
            t_pd, p_pd = stats.ttest_rel(sub_d[s1], sub_d[s2])
            diff_d = sub_d[s1] - sub_d[s2]
            contrasts.append({
                "family": f"Metacog_dSep_within_{grp}",
                "contrast": f"{s1} vs {s2}",
                "n1": len(sub_d), "n2": len(sub_d),
                "mean1": float(np.mean(sub_d[s1])), "mean2": float(np.mean(sub_d[s2])),
                "diff": float(np.mean(diff_d)),
                "t_stat": float(t_pd), "p_raw": float(p_pd), "effect_d": float(np.mean(diff_d) / np.std(diff_d, ddof=1)),
            })

    # Apply BH-FDR within each contrast family
    cont_df = pd.DataFrame(contrasts)
    cont_df["p_FDR"] = np.nan
    for fam, idx in cont_df.groupby("family").groups.items():
        _, qvals, _, _ = multipletests(cont_df.loc[idx, "p_raw"].values, method="fdr_bh")
        cont_df.loc[idx, "p_FDR"] = qvals

    # Compute ANCOVA adjusted Sep_post means at mean Sep_pre
    mean_sep_pre = df_sep["Sep_pre"].mean()
    adj_means = []
    for grp in ["ITF-1", "ITF+1"]:
        for sess in ["inphase", "antiphase", "sham"]:
            pred_row = pd.DataFrame({"Sep_pre": [mean_sep_pre], "session": [sess], "group_label": [grp]})
            pred = float(m_sep.predict(pred_row).iloc[0])
            adj_means.append({"group_label": grp, "session": sess, "adj_Sep_post": pred})

    return pd.DataFrame(stat_records), cont_df, pd.DataFrame(adj_means), m_acc, m_fr, m_sep, m_ph


def main():
    weights, lengths, centres, regions, dk_sum = load_dk68_connectome()
    print("=== DK68 Connectome Summary ===")
    for k, v in dk_sum.items():
        print(f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}")

    df42, sess_df, trial_df = parse_empirical_dataset()
    print(f"\n=== Empirical Sample: N={len(df42)} subjects, {len(sess_df)} sessions, {len(trial_df)} TOJ trials ===")
    print("Group counts:", df42["Group"].value_counts().to_dict())
    for grp, lbl in [(1, "ITF-1"), (2, "ITF+1")]:
        sub = df42[df42["Group"] == grp]
        age = pd.to_numeric(sub["Age"], errors="coerce")
        itf = pd.to_numeric(sub["pre_ITF (4-7 Hz)"], errors="coerce")
        print(f"  {lbl}: n={len(sub)}, Age={age.mean():.2f}±{age.std():.2f}, baseline ITF={itf.mean():.2f}±{itf.std():.2f} Hz")

    # Cell means table
    cell_cols = [
        "pre_ITF", "post_ITF", "dITF", "pre_ITF_power", "post_ITF_power", "dITF_power",
        "pre_theta_power", "post_theta_power", "dTheta_power", "stim_freq", "stim_amp_mA",
        "pre_recall", "post_recall", "dRecall", "pre_acc", "post_acc", "dAcc",
        "pre_rt", "post_rt", "pre_rt_asym", "post_rt_asym", "dRT_asym",
        "pHigh_pre", "pHigh_post", "dpHigh", "Sep_pre", "Sep_post", "dSep",
        "AUROC2_pre", "AUROC2_post", "dAUROC2"
    ]
    cell_summary = []
    for grp in ["ITF-1", "ITF+1"]:
        for sess in ["inphase", "antiphase", "sham"]:
            sub = sess_df[(sess_df["group_label"] == grp) & (sess_df["session"] == sess)]
            rec = {"group_label": grp, "session": sess, "n_sess": len(sub), "n_sep": int(sub["dSep"].notna().sum())}
            for c in cell_cols:
                vals = sub[c].dropna()
                rec[f"{c}_mean"] = float(vals.mean()) if len(vals) else np.nan
                rec[f"{c}_sd"] = float(vals.std(ddof=1)) if len(vals) > 1 else np.nan
                rec[f"{c}_se"] = float(vals.std(ddof=1) / np.sqrt(len(vals))) if len(vals) > 1 else np.nan
            cell_summary.append(rec)
    cell_df = pd.DataFrame(cell_summary)

    stat_df, cont_df, adj_sep_df, m_acc, m_fr, m_sep, m_ph = run_statistical_models(sess_df)

    # Save outputs
    sess_df.to_csv(os.path.join(RESULTS_DIR, "empirical_session_summary.csv"), index=False)
    trial_df.to_csv(os.path.join(RESULTS_DIR, "empirical_trial_level_toj.csv"), index=False)
    cell_df.to_csv(os.path.join(RESULTS_DIR, "empirical_cell_means.csv"), index=False)
    stat_df.to_csv(os.path.join(RESULTS_DIR, "empirical_lmm_omnibus.csv"), index=False)
    cont_df.to_csv(os.path.join(RESULTS_DIR, "empirical_contrasts.csv"), index=False)
    adj_sep_df.to_csv(os.path.join(RESULTS_DIR, "empirical_adj_sep_means.csv"), index=False)
    pd.DataFrame([dk_sum]).to_csv(os.path.join(RESULTS_DIR, "dk68_connectome_summary.csv"), index=False)

    print("\n=== Cell Means (Key Outcomes) ===")
    for _, r in cell_df.iterrows():
        print(
            f"  {r['group_label']:5s} | {r['session']:9s} | dAcc={r['dAcc_mean']:+6.2f}±{r['dAcc_se']:.2f}% | "
            f"dRecall={r['dRecall_mean']:+5.2f}±{r['dRecall_se']:.2f} | "
            f"Sep_pre={r['Sep_pre_mean']:+.3f} -> Sep_post={r['Sep_post_mean']:+.3f} (dSep={r['dSep_mean']:+.3f}) | "
            f"pHigh: {r['pHigh_pre_mean']*100:.1f}%->{r['pHigh_post_mean']*100:.1f}% | "
            f"dThetaP={r['dTheta_power_mean']:+.3f}"
        )

    print("\n=== LMM Omnibus Tests ===")
    print(stat_df.to_string(index=False))
    print("\n=== Key Contrasts (BH-FDR) ===")
    print(cont_df.to_string(index=False))
    print("\n=== ANCOVA Adjusted Post-Sep Means ===")
    print(adj_sep_df.to_string(index=False))


if __name__ == "__main__":
    main()
