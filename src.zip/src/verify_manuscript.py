#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_manuscript.py
====================
Automated verification of manuscript structure, word counts, and strict
sequential ordering of equations, tables, figures, and references across
Markdown and DOCX outputs.
"""

from __future__ import annotations
import os
import re
import sys
import json

BASE_DIR = r"C:\Users\CBM\.gemini\antigravity\scratch\algebraic-geometry-tacs-memory"
MS_DIR = os.path.join(BASE_DIR, "manuscript")


def check_sequential_order(items: list[int], label: str, expected_max: int):
    seen = []
    for x in items:
        if x not in seen:
            seen.append(x)
    expected = list(range(1, expected_max + 1))
    ok = (seen == expected)
    print(f"  [{ 'PASS' if ok else 'FAIL' }] {label} first-appearance order: {seen} (expected {expected})")
    return ok


def verify_markdown(md_path: str):
    with open(md_path, "r", encoding="utf-8") as f:
        text = f.read()

    print(f"=== Verifying {os.path.basename(md_path)} ===")
    all_ok = True

    # 1. Check required sections in exact order
    required_headings = [
        "Abstract",
        "Keywords",
        "Introduction",
        "Methodology",
        "Results",
        "Discussion",
        "Conclusions",
        "CRediT Authorship Contribution Statement",
        "Ethics Statement",
        "Funding",
        "Declaration of Competing Interest",
        "Data Availability Statement",
        "Declaration of Generative AI and AI-Assisted Technologies in the Writing Process",
        "References",
    ]
    positions = []
    for h in required_headings:
        m = re.search(rf"(?im)^(?:#+\s*|(?:\*\*))?{re.escape(h)}(?:\*\*)?\s*$", text)
        if not m and h == "Keywords":
            m = re.search(r"(?im)^\*\*Keywords:\*\*", text)
        if not m:
            print(f"  [FAIL] Missing required section: {h}")
            all_ok = False
        else:
            positions.append((m.start(), h))
    sorted_pos = [h for _, h in sorted(positions)]
    order_ok = (sorted_pos == required_headings)
    print(f"  [{ 'PASS' if order_ok else 'FAIL' }] Section order matches required sequence ({len(sorted_pos)}/{len(required_headings)})")
    if not order_ok:
        all_ok = False

    # 2. Abstract word count (200-250 words)
    abs_m = re.search(r"(?is)^#+\s*Abstract\s*\n+(.*?)\n+\*\*Keywords:", text, re.M)
    if abs_m:
        abs_words = len(re.findall(r"\S+", abs_m.group(1).strip()))
        abs_ok = (200 <= abs_words <= 250)
        print(f"  [{ 'PASS' if abs_ok else 'FAIL' }] Abstract word count: {abs_words} (target 200-250)")
        if not abs_ok:
            all_ok = False
    else:
        print("  [FAIL] Could not isolate Abstract body")
        all_ok = False

    # 3. Conclusions word count (100-200 words)
    conc_m = re.search(r"(?is)^#+\s*Conclusions\s*\n+(.*?)\n+#+\s*CRediT", text, re.M)
    if conc_m:
        conc_words = len(re.findall(r"\S+", conc_m.group(1).strip()))
        conc_ok = (100 <= conc_words <= 200)
        print(f"  [{ 'PASS' if conc_ok else 'FAIL' }] Conclusions word count: {conc_words} (target 100-200)")
        if not conc_ok:
            all_ok = False
    else:
        print("  [FAIL] Could not isolate Conclusions body")
        all_ok = False

    # 4. Equation display order (1)-(18)
    body_before_refs = text.split("## References")[0] if "## References" in text else text
    eq_disp = [int(x) for x in re.findall(r"(?m)^>\s+.*\s{2,}\((\d+)\)\s*$", body_before_refs)]
    if not check_sequential_order(eq_disp, "Display Equations", 18):
        all_ok = False

    eq_callouts = []
    for m in re.finditer(r"\bEq(?:s)?\.?\s*\((\d+)\)(?:\s*[\u2013\-]\s*\((\d+)\))?|\bEquation(?:s)?\s*\((\d+)\)(?:\s*[\u2013\-]\s*\((\d+)\))?", body_before_refs):
        a = m.group(1) or m.group(3)
        b = m.group(2) or m.group(4)
        if a and b:
            eq_callouts.extend(range(int(a), int(b) + 1))
        elif a:
            eq_callouts.append(int(a))
    if not check_sequential_order(eq_callouts, "Equation Text Callouts", 18):
        all_ok = False

    # 5. Table and Figure callout order
    tbl_callouts = [int(x) for x in re.findall(r"\bTable\s+(\d+)\b", body_before_refs)]
    if not check_sequential_order(tbl_callouts, "Table Text Callouts", 4):
        all_ok = False

    fig_callouts = [int(x) for x in re.findall(r"\bFigure\s+(\d+)\b", body_before_refs)]
    if not check_sequential_order(fig_callouts, "Figure Text Callouts", 6):
        all_ok = False

    # 6. Check placeholders / watermarks
    bad_patterns = [r"\[TITLE\]", r"\[AUTHOR\]", r"\[DATA\]", r"\[REFERENCE\]", r"TODO", r"TBD", r"FIXME"]
    for pat in bad_patterns:
        if re.search(pat, text):
            print(f"  [FAIL] Found forbidden placeholder pattern: {pat}")
            all_ok = False

    # 7. Reference sequential appearance (superscripts ^1^ or [1] or <sup>1</sup>)
    ref_nums = []
    for m in re.finditer(r"\^([0-9,\-\u2013]+)\^|<sup>([0-9,\-\u2013]+)</sup>", body_before_refs):
        grp = m.group(1) or m.group(2)
        for part in grp.split(","):
            part = part.strip()
            if "-" in part or "\u2013" in part:
                a, b = re.split(r"[-\u2013]", part)
                if a.isdigit() and b.isdigit():
                    ref_nums.extend(range(int(a), int(b) + 1))
            elif part.isdigit():
                ref_nums.append(int(part))
    max_ref = max(ref_nums) if ref_nums else 0
    if max_ref > 0:
        if not check_sequential_order(ref_nums, "Reference Citations", max_ref):
            all_ok = False
    else:
        print("  [FAIL] No superscript references detected")
        all_ok = False

    print(f"=== Overall Markdown Verification: {'PASSED' if all_ok else 'FAILED'} ===")
    return all_ok


if __name__ == "__main__":
    md_file = os.path.join(MS_DIR, "Manuscript.md")
    if os.path.exists(md_file):
        ok = verify_markdown(md_file)
        sys.exit(0 if ok else 1)
    else:
        print("Manuscript.md not yet created.")
