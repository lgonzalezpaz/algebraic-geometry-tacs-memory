#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_figures.py
===================
Generates publication-quality 600 DPI PNG and vector PDF figures (Figures 1-6 and
Supplementary Figures S1-S2) for the manuscript:
"Algebraic geometry of memory modulation: Newton polytopes and discriminant
singularities explain why anti-phase slow-theta stimulation enhances human
episodic sequence memory"

Uses a color-blind-safe Okabe-Ito palette with distinct markers/linestyles so
every figure remains legible in grayscale.
"""

from __future__ import annotations
import os
import sys
import numpy as np
import pandas as pd
import scipy.stats as stats
from scipy.spatial import ConvexHull
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.gridspec as gridspec

BASE_DIR = r"C:\Users\CBM\.gemini\antigravity\scratch\algebraic-geometry-tacs-memory"
SRC_DIR = os.path.join(BASE_DIR, "src")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
DK68_DIR = os.path.join(BASE_DIR, "data", "dk68")
FIG_DIR = os.path.join(BASE_DIR, "figures")
os.makedirs(FIG_DIR, exist_ok=True)

sys.path.insert(0, SRC_DIR)
import algebraic_kuramoto_memory as akm

# Okabe-Ito Color-blind-safe palette
COL_ITF_MINUS = "#D55E00"   # Vermilion / Orange-Red (ITF-1)
COL_ITF_PLUS  = "#0072B2"   # Deep Blue (ITF+1)
COL_AP        = "#009E73"   # Bluish Green (Anti-Phase)
COL_IP        = "#E69F00"   # Amber / Orange (In-Phase)
COL_SHAM      = "#666666"   # Neutral Gray (Sham)
COL_SIGMA     = "#CC79A7"   # Muted Magenta (Discriminant Sigma)
COL_HIPP      = "#56B4E9"   # Sky Blue (Hippocampal)

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
    "font.size": 8.5,
    "axes.titlesize": 9.5,
    "axes.labelsize": 8.5,
    "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5,
    "legend.fontsize": 7.5,
    "axes.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 150,
    "savefig.dpi": 600,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def add_panel_label(ax, label, x=-0.16, y=1.10, is_3d=False):
    if is_3d:
        ax.text2D(x, y, label, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top", ha="left")
    else:
        ax.text(x, y, label, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top", ha="left")


def save_fig(fig, name):
    fig.savefig(os.path.join(FIG_DIR, f"{name}.png"), dpi=600, bbox_inches="tight")
    fig.savefig(os.path.join(FIG_DIR, f"{name}.pdf"), bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {name}.png (600 DPI) & {name}.pdf")


# =============================================================================
# FIGURE 1: Connectome, Weierstrass Map, and 3D Discriminant Variety Sigma
# =============================================================================
def make_figure1():
    weights = np.loadtxt(os.path.join(DK68_DIR, "dk68_weights.txt"))
    lengths = np.loadtxt(os.path.join(DK68_DIR, "dk68_tract_lengths.txt"))
    centres = np.loadtxt(os.path.join(DK68_DIR, "dk68_centres.txt"), usecols=(1, 2, 3))
    with open(os.path.join(DK68_DIR, "dk68_regions.txt"), "r", encoding="utf-8") as f:
        regions = [line.strip() for line in f if line.strip()]

    lf_idx = [39, 40, 41, 42]
    lp_idx = [50, 51, 52, 53]
    hipp_idx = [59, 60]  # l_parahippocampal, l_entorhinal

    fig = plt.figure(figsize=(11.5, 3.8))
    gs = gridspec.GridSpec(1, 3, width_ratios=[1.1, 1.0, 1.25], wspace=0.28)

    # Panel a: Real dk68 sagittal/axial projection of fronto-parietal-hippocampal circuit
    ax1 = fig.add_subplot(gs[0])
    # Sagittal (y=AP, z=SI) view of left hemisphere nodes (34..67)
    lh_idx = list(range(34, 68))
    for i in lh_idx:
        for j in lh_idx:
            if i < j and weights[i, j] > 0.02:
                ax1.plot([centres[i, 1], centres[j, 1]], [centres[i, 2], centres[j, 2]],
                         color="#D0D4DA", lw=0.4, alpha=0.35, zorder=1)
    # Highlight LF-LP tracts
    for i in lf_idx:
        for j in lp_idx:
            if weights[i, j] > 0:
                ax1.plot([centres[i, 1], centres[j, 1]], [centres[i, 2], centres[j, 2]],
                         color=COL_AP, lw=1.6, alpha=0.85, zorder=2)
    # Highlight LF/LP-Hippocampal tracts
    for i in lf_idx + lp_idx:
        for j in hipp_idx:
            if weights[i, j] > 0:
                ax1.plot([centres[i, 1], centres[j, 1]], [centres[i, 2], centres[j, 2]],
                         color=COL_HIPP, lw=1.1, ls="--", alpha=0.8, zorder=2)

    ax1.scatter(centres[lh_idx, 1], centres[lh_idx, 2], s=18, color="#B8BFC9", edgecolor="none", alpha=0.7, zorder=3, label="Other LH nodes")
    ax1.scatter(centres[lf_idx, 1], centres[lf_idx, 2], s=58, color=COL_ITF_MINUS, edgecolor="k", lw=0.7, marker="o", zorder=4, label="Left Frontal (LF)")
    ax1.scatter(centres[lp_idx, 1], centres[lp_idx, 2], s=58, color=COL_ITF_PLUS, edgecolor="k", lw=0.7, marker="s", zorder=4, label="Left Parietal (LP)")
    ax1.scatter(centres[hipp_idx, 1], centres[hipp_idx, 2], s=65, color=COL_HIPP, edgecolor="k", lw=0.7, marker="^", zorder=5, label="Parahipp./Entorh.")
    ax1.annotate(r"$L_{\mathrm{FP}}=93.6$ mm" + "\n" + r"$\tau_{\mathrm{FP}}=13.4$ ms",
                 xy=(-15, 32), xytext=(-58, 52), fontsize=7.5,
                 bbox=dict(boxstyle="round,pad=0.25", fc="white", ec=COL_AP, lw=0.8),
                 arrowprops=dict(arrowstyle="->", color=COL_AP, lw=1.0))
    ax1.set_xlabel("Anterior–Posterior y (mm)")
    ax1.set_ylabel("Inferior–Superior z (mm)")
    ax1.set_title("Human DK68 Circuit & Delays")
    ax1.legend(loc="lower left", frameon=True, framealpha=0.9, fontsize=6.5, ncol=2)
    add_panel_label(ax1, "a")

    # Panel b: Stereographic Weierstrass map x = tan(psi / 2)
    ax2 = fig.add_subplot(gs[1])
    psi = np.linspace(-0.88 * np.pi, 0.88 * np.pi, 400)
    x_map = np.tan(psi / 2.0)
    ax2.plot(psi, x_map, color="#222222", lw=1.8, label=r"$x_i = \tan(\psi_i / 2)$")
    ax2.axhline(0, color="#999999", lw=0.6, ls=":")
    ax2.axvline(0, color="#999999", lw=0.6, ls=":")
    # Mark In-Phase umbilical root vs Anti-Phase chiral roots
    ax2.scatter([0.0], [0.0], s=80, color=COL_IP, edgecolor="k", zorder=5, label=r"In-phase umbilical ($u^* \approx 0$)")
    u_ap = 0.8985
    psi_ap = 2.0 * np.arctan(u_ap)
    ax2.scatter([psi_ap, -psi_ap], [u_ap, -u_ap], s=80, color=COL_AP, marker="D", edgecolor="k", zorder=5,
                label=r"Anti-phase chiral ($u_\pm^* = \pm 0.86$)")
    ax2.annotate(r"$A \prec B$ ($+\psi^*$)", xy=(psi_ap, u_ap), xytext=(0.45, 2.5),
                 fontsize=7.2, arrowprops=dict(arrowstyle="->", color=COL_AP, lw=0.9))
    ax2.annotate(r"$B \prec A$ ($-\psi^*$)", xy=(-psi_ap, -u_ap), xytext=(-2.6, -2.8),
                 fontsize=7.2, arrowprops=dict(arrowstyle="->", color=COL_AP, lw=0.9))
    ax2.set_xlim(-np.pi, np.pi)
    ax2.set_ylim(-4.2, 4.2)
    ax2.set_xticks([-np.pi, -np.pi / 2, 0, np.pi / 2, np.pi])
    ax2.set_xticklabels([r"$-\pi$", r"$-\pi/2$", "0", r"$\pi/2$", r"$\pi$"])
    ax2.set_xlabel(r"Relative phase $\Delta\psi$ (rad)")
    ax2.set_ylabel(r"Weierstrass coordinate $u = \tan(\Delta\psi/2)$")
    ax2.set_title("Stereographic Algebraization")
    ax2.legend(loc="upper left", frameon=True, framealpha=0.9, fontsize=6.6)
    add_panel_label(ax2, "b")

    # Panel c: 3D Cusp Discriminant Variety Sigma in (mu_2, mu_1, A_tACS) / control space
    ax3 = fig.add_subplot(gs[2], projection="3d")
    u_surf = np.linspace(-1.35, 1.35, 70)
    mu2_grid = np.linspace(-1.2, 1.2, 50)
    U, M2 = np.meshgrid(u_surf, mu2_grid)
    M1 = -(U ** 3 + M2 * U)
    # Mask extreme M1 for clean cusp fold display
    mask = np.abs(M1) <= 0.85
    M1_plot = np.where(mask, M1, np.nan)
    ax3.plot_surface(M2, M1_plot, U, cmap="coolwarm", alpha=0.58, edgecolor="none", antialiased=True)

    # Plot cusp locus projected on base plane u = -1.6
    m2_neg = np.linspace(-1.15, 0.0, 100)
    m1_cusp_pos = np.sqrt(-4.0 * (m2_neg ** 3) / 27.0)
    ax3.plot(m2_neg, m1_cusp_pos, zs=-1.55, color=COL_SIGMA, lw=2.2, label=r"Discriminant $\Sigma$: $4\mu_2^3+27\mu_1^2=0$")
    ax3.plot(m2_neg, -m1_cusp_pos, zs=-1.55, color=COL_SIGMA, lw=2.2)

    # Mark 6 experimental cells on base plane & equilibrium surface
    sim_df = pd.read_csv(os.path.join(RESULTS_DIR, "model_6condition_predictions.csv"))
    for _, r in sim_df.iterrows():
        if r["session"] == "sham":
            col, mk = COL_SHAM, "^"
        elif r["session"] == "inphase":
            col, mk = COL_IP, "o"
        else:
            col, mk = COL_AP, "D"
        edge = COL_ITF_MINUS if r["group_label"] == "ITF-1" else COL_ITF_PLUS
        ax3.scatter([r["mu_2"]], [r["mu_1"]], [r["u_plus"]], color=col, edgecolor=edge, s=55, marker=mk, lw=1.2, zorder=10)
        if r["bistable"]:
            ax3.scatter([r["mu_2"]], [r["mu_1"]], [r["u_minus"]], color=col, edgecolor=edge, s=55, marker=mk, lw=1.2, zorder=10)

    ax3.text(-0.95, -0.15, 1.25, "ITF-1 AP\n(Bistable chiral)", color=COL_AP, fontsize=7.0, fontweight="bold")
    ax3.text(0.45, 0.12, 0.30, "IP Umbilical\nCollapse", color=COL_ITF_MINUS, fontsize=7.0, fontweight="bold")
    ax3.set_xlim(-1.2, 1.55)
    ax3.set_ylim(-0.85, 0.85)
    ax3.set_zlim(-1.6, 1.45)
    ax3.set_xlabel(r"$\mu_2$ (Phase/Freq)", labelpad=4)
    ax3.set_ylabel(r"$\mu_1$ (Bias)", labelpad=4)
    ax3.set_zlabel(r"Equilibrium $u^*$", labelpad=3)
    ax3.set_title(r"Cusp Catastrophe Manifold & $\Sigma$")
    ax3.view_init(elev=22, azim=-52)
    add_panel_label(ax3, "c", x=-0.06, y=1.06, is_3d=True)

    save_fig(fig, "Figure1")


# =============================================================================
# FIGURE 2: Newton Polytopes, BKK Capacity (Omega^-1), and Effective Potentials
# =============================================================================
def make_figure2():
    fig = plt.figure(figsize=(12.2, 3.8))
    gs = gridspec.GridSpec(1, 3, width_ratios=[1.02, 1.18, 1.08], wspace=0.44)

    # Panel a: 3D Newton Polytope N_1 and Minkowski Sum for 3-node LF-LP-HIPP triad
    ax1 = fig.add_subplot(gs[0], projection="3d")
    adj3 = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
    supps = akm.get_weierstrass_newton_support(3, adj3)
    # N_1 spans [0,2]^3 (MV = 48); plot cube N_1 and highlight vertices
    pts = supps[0]
    hull = ConvexHull(pts)
    faces = [[pts[s_i] for s_i in simplex] for simplex in hull.simplices]
    poly = Poly3DCollection(faces, alpha=0.22, facecolor=COL_ITF_PLUS, edgecolor="#333333", lw=0.4)
    ax1.add_collection3d(poly)
    ax1.scatter(pts[:, 0], pts[:, 1], pts[:, 2], s=22, color=COL_ITF_MINUS, alpha=0.85)
    ax1.set_xlim(-0.2, 2.2)
    ax1.set_ylim(-0.2, 2.2)
    ax1.set_zlim(-0.2, 2.2)
    ax1.set_xticks([0, 1, 2]); ax1.set_yticks([0, 1, 2]); ax1.set_zticks([0, 1, 2])
    ax1.set_xlabel(r"$x_F$ exp."); ax1.set_ylabel(r"$x_P$ exp."); ax1.set_zlabel(r"$x_H$ exp.")
    ax1.set_title(r"Newton Polytope $\mathcal{N}_F$ (MV = 48)")
    ax1.text2D(0.06, 0.88, "2-node dimer: MV = 8\n3-node triad: MV = 48\n" + r"$N_{\mathrm{real}} \leq \mathrm{MV}(\mathcal{N}_1,\dots,\mathcal{N}_N)$",
               transform=ax1.transAxes, fontsize=7.0, bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#AAAAAA"))
    ax1.view_init(elev=24, azim=35)
    add_panel_label(ax1, "a", x=-0.05, y=1.06, is_3d=True)

    # Panel b: Temporal Sequence Polytope Volume V_seq(Omega, Delta phi)
    ax2 = fig.add_subplot(gs[1])
    dk = akm.load_dk68_frontoparietal_params()
    freq_grid = np.linspace(3.0, 8.0, 80)
    phi_grid = np.linspace(0.0, 2.0 * np.pi, 80)
    Z_vol = np.zeros((len(phi_grid), len(freq_grid)))
    omega_itf = 5.17
    for i, ph in enumerate(phi_grid):
        for j, fr in enumerate(freq_grid):
            res = akm.predict_observables_from_variety(omega_itf, fr, ph, 1.0, dk["tau_fp_s"])
            # Effective temporal sequence capacity: BKK * gamma slots * barrier indicator
            Z_vol[i, j] = 48.0 * res["n_gamma_slots"] * (1.0 if res["bistable"] else 0.0) * (0.5 + 5.0 * res["barrier"])

    im = ax2.contourf(freq_grid, np.degrees(phi_grid), Z_vol, levels=24, cmap="viridis")
    cbar = fig.colorbar(im, ax=ax2, pad=0.02, shrink=0.88)
    cbar.set_label(r"Sequence capacity $\mathcal{V}_{\mathrm{seq}}$", fontsize=7.5)
    # Mark experimental targets (ITF-1 AP, ITF-1 IP, ITF+1 AP, ITF+1 IP)
    ax2.scatter([4.17], [180], s=85, color=COL_AP, edgecolor="white", marker="D", lw=1.2, zorder=6, label="ITF-1 Anti-Phase")
    ax2.scatter([4.17], [0], s=85, color=COL_IP, edgecolor="white", marker="o", lw=1.2, zorder=6, label="ITF-1 In-Phase")
    ax2.scatter([5.94], [180], s=85, color=COL_ITF_PLUS, edgecolor="white", marker="s", lw=1.2, zorder=6, label="ITF+1 Anti-Phase")
    ax2.axvline(omega_itf, color="white", ls="--", lw=1.0, alpha=0.85)
    ax2.text(omega_itf - 0.12, 240, "ITF", color="white", fontsize=7.5, fontweight="bold", ha="right")
    ax2.set_xlabel(r"Stimulation frequency $\Omega$ (Hz)")
    ax2.set_ylabel(r"Phase offset $\Delta\phi$ (deg)")
    ax2.set_yticks([0, 90, 180, 270, 360])
    ax2.set_title(r"Temporal Polytope Volume ($\propto \Omega^{-1}$)")
    ax2.legend(loc="upper right", frameon=True, framealpha=0.88, fontsize=6.4)
    add_panel_label(ax2, "b")

    # Panel c: Chiral Potential Wells V_eff(u) across Sham, In-Phase, and Anti-Phase Slow-Theta
    ax3 = fig.add_subplot(gs[2])
    u_vec = np.linspace(-1.45, 1.45, 300)
    sim_df = pd.read_csv(os.path.join(RESULTS_DIR, "model_6condition_predictions.csv"))
    for sess, lbl, col, ls in [
        ("antiphase", r"ITF-1 Anti-Phase ($\Delta_{\mathrm{cusp}}=-1.62$)", COL_AP, "-"),
        ("inphase", r"ITF-1 In-Phase ($\Delta_{\mathrm{cusp}}=+0.93$)", COL_IP, "--"),
        ("sham", r"Sham Baseline ($\Delta_{\mathrm{cusp}}=+0.19$)", COL_SHAM, ":"),
    ]:
        row = sim_df[(sim_df["group_label"] == "ITF-1") & (sim_df["session"] == sess)].iloc[0]
        V = 0.25 * u_vec**4 + 0.5 * row["mu_2"] * u_vec**2 + row["mu_1"] * u_vec
        ax3.plot(u_vec, V, color=col, ls=ls, lw=2.0, label=lbl)
        if sess == "antiphase":
            v_p = 0.25 * row["u_plus"]**4 + 0.5 * row["mu_2"] * row["u_plus"]**2 + row["mu_1"] * row["u_plus"]
            v_m = 0.25 * row["u_minus"]**4 + 0.5 * row["mu_2"] * row["u_minus"]**2 + row["mu_1"] * row["u_minus"]
            ax3.scatter([row["u_plus"], row["u_minus"]], [v_p, v_m], color=COL_AP, s=55, edgecolor="k", zorder=6)
            ax3.annotate(r"$A \prec B$", xy=(row["u_plus"], v_p), xytext=(0.75, v_p + 0.15), fontsize=7.5, fontweight="bold", color=COL_AP)
            ax3.annotate(r"$B \prec A$", xy=(row["u_minus"], v_m), xytext=(-1.25, v_m + 0.15), fontsize=7.5, fontweight="bold", color=COL_AP)
        elif sess == "inphase":
            v_s = 0.25 * row["u_plus"]**4 + 0.5 * row["mu_2"] * row["u_plus"]**2 + row["mu_1"] * row["u_plus"]
            ax3.scatter([row["u_plus"]], [v_s], color=COL_IP, s=55, edgecolor="k", zorder=6)

    ax3.set_xlim(-1.45, 1.45)
    ax3.set_ylim(-0.22, 0.85)
    ax3.set_xlabel(r"Weierstrass sequence coordinate $u = \tan(\Delta\psi/2)$")
    ax3.set_ylabel(r"Effective potential $V_{\mathrm{eff}}(u)$")
    ax3.set_title("Umbilical Collapse vs. Chiral Bifurcation")
    ax3.legend(loc="upper center", frameon=True, framealpha=0.92, fontsize=6.4)
    add_panel_label(ax3, "c")

    save_fig(fig, "Figure2")


# =============================================================================
# FIGURE 3: Debiased wPLI Paradox Resolution & Empirical Theta Validation
# =============================================================================
def make_figure3():
    sim_df = pd.read_csv(os.path.join(RESULTS_DIR, "model_6condition_predictions.csv"))
    sess_emp = pd.read_csv(os.path.join(RESULTS_DIR, "empirical_session_summary.csv"))

    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.6), gridspec_kw={"wspace": 0.32})

    # Panel a: Theoretical wPLI_FP(u*) curve
    ax = axes[0]
    u_vals = np.linspace(-2.5, 2.5, 400)
    wpli_curve = (2.0 * np.abs(u_vals) / (1.0 + u_vals**2)) * np.exp(-0.45)
    ax.plot(u_vals, wpli_curve, color="#222222", lw=2.0, label=r"$\mathrm{wPLI}_{FP}(u^*) = \frac{2|u^*|}{1+(u^*)^2}e^{-\sigma_\psi^2}$")
    # Overlay ITF-1 IP vs AP
    r_ip = sim_df[(sim_df["group_label"] == "ITF-1") & (sim_df["session"] == "inphase")].iloc[0]
    r_ap = sim_df[(sim_df["group_label"] == "ITF-1") & (sim_df["session"] == "antiphase")].iloc[0]
    ax.scatter([r_ip["u_plus"]], [r_ip["wpli_post"]], s=80, color=COL_IP, edgecolor="k", marker="o", zorder=6,
               label=f"ITF-1 In-Phase ($u^*={r_ip['u_plus']:.2f}$)")
    ax.scatter([r_ap["u_plus"], r_ap["u_minus"]], [r_ap["wpli_post"], r_ap["wpli_post"]], s=80,
               color=COL_AP, edgecolor="k", marker="D", zorder=6, label=f"ITF-1 Anti-Phase ($u^*=\\pm{r_ap['u_plus']:.2f}$)")
    ax.axvline(0.0, color="#999999", ls=":", lw=0.8)
    ax.set_ylim(-0.04, 0.94)
    ax.set_xlabel(r"Equilibrium Weierstrass root $u^*$")
    ax.set_ylabel(r"Predicted fronto-parietal $\mathrm{wPLI}_{FP}$")
    ax.set_title("Zero-Lag Null vs. Chiral Maxima")
    ax.legend(loc="upper center", frameon=True, framealpha=0.95, fontsize=6.5)
    add_panel_label(ax, "a")

    # Panel b: Full DK68 connectome simulated dwPLI across 6 conditions
    ax = axes[1]
    sessions = ["inphase", "antiphase", "sham"]
    x = np.arange(len(sessions))
    w = 0.34
    for idx_g, (grp, col, off, hatch) in enumerate([("ITF-1", COL_ITF_MINUS, -w/2, ""), ("ITF+1", COL_ITF_PLUS, w/2, "//")]):
        means = [sim_df[(sim_df["group_label"] == grp) & (sim_df["session"] == s)]["dk68_sim_dwpli"].values[0] for s in sessions]
        sds = [sim_df[(sim_df["group_label"] == grp) & (sim_df["session"] == s)]["dk68_sim_dwpli_sd"].values[0] / np.sqrt(15) for s in sessions]
        ax.bar(x + off, means, width=w, yerr=sds, capsize=3, color=col, edgecolor="k", lw=0.7, hatch=hatch, alpha=0.88, label=grp)
    ax.axhline(0.0, color="k", lw=0.7)
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase\n" + r"($\Delta\phi=0$)", "Anti-Phase\n" + r"($\Delta\phi=\pi$)", "Sham\n" + r"($A=0$)"])
    ax.set_ylabel(r"Simulated $\Delta\mathrm{wPLI}_{FP}$ (Post $-$ Pre)")
    ax.set_title("DK68 Connectome Resting Connectivity")
    ax.legend(loc="upper right", frameon=True, framealpha=0.92)
    add_panel_label(ax, "b")

    # Panel c: Empirical resting theta power change & predicted dwPLI vs TOJ gain
    ax = axes[2]
    for grp, col, mk in [("ITF-1", COL_ITF_MINUS, "o"), ("ITF+1", COL_ITF_PLUS, "s")]:
        means_th, se_th = [], []
        for s in sessions:
            vals = sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["dTheta_power"].dropna()
            means_th.append(vals.mean())
            se_th.append(vals.std(ddof=1) / np.sqrt(len(vals)))
        ax.errorbar(x + (-0.08 if grp == "ITF-1" else 0.08), means_th, yerr=se_th,
                    marker=mk, ms=6.5, lw=1.8, capsize=3.5, color=col, label=f"{grp} Empirical $\\Delta P_\\theta$")
    ax.axhline(0.0, color="#777777", ls=":", lw=0.7)
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel(r"Empirical $\Delta$ Theta Power ($\mu\mathrm{V}^2$)")
    ax.set_title("Empirical Resting EEG Theta Power")
    ax.legend(loc="upper right", frameon=True, framealpha=0.92)
    add_panel_label(ax, "c")

    save_fig(fig, "Figure3")


# =============================================================================
# FIGURE 4: Empirical TOJ Accuracy, Free Recall, & Model Comparison (N=42)
# =============================================================================
def make_figure4():
    sess_emp = pd.read_csv(os.path.join(RESULTS_DIR, "empirical_session_summary.csv"))
    sim_df = pd.read_csv(os.path.join(RESULTS_DIR, "model_6condition_predictions.csv"))
    mc_df = pd.read_csv(os.path.join(RESULTS_DIR, "model_comparison_aic_cv.csv"))

    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.8), gridspec_kw={"wspace": 0.36})
    sessions = ["inphase", "antiphase", "sham"]
    x = np.arange(len(sessions))
    rng = np.random.default_rng(7)

    # Panel a: TOJ Accuracy Change (%) with individual trajectories + model overlay
    ax = axes[0]
    for grp, col, off, mk in [("ITF-1", COL_ITF_MINUS, -0.15, "o"), ("ITF+1", COL_ITF_PLUS, 0.15, "s")]:
        means, ses, preds = [], [], []
        for idx_s, s in enumerate(sessions):
            vals = sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["dAcc"].values
            jitter = rng.normal(0, 0.035, size=len(vals))
            ax.scatter(np.full_like(vals, idx_s + off) + jitter, vals, s=14, color=col, alpha=0.28, edgecolor="none")
            means.append(np.mean(vals))
            ses.append(np.std(vals, ddof=1) / np.sqrt(len(vals)))
            preds.append(sim_df[(sim_df["group_label"] == grp) & (sim_df["session"] == s)]["dAcc_pred"].values[0])
        ax.errorbar(x + off, means, yerr=ses, marker=mk, ms=6.5, lw=1.8, capsize=3.5, color=col,
                    markeredgecolor="k", markeredgewidth=0.6, label=f"{grp} Observed", zorder=5)
        ax.plot(x + off, preds, ls="--", lw=1.3, color=col, alpha=0.85, marker="*", ms=7, label=f"{grp} Model")

    ax.axhline(0, color="#666666", ls=":", lw=0.8)
    ax.annotate(r"$\Delta=+10.1\%$" + "\n" + r"$P_{\mathrm{raw}}=0.024, d=0.73$",
                xy=(1.0, 4.3), xytext=(0.45, 16.5), fontsize=7.0,
                bbox=dict(boxstyle="round,pad=0.22", fc="white", ec=COL_AP, lw=0.8),
                arrowprops=dict(arrowstyle="->", color=COL_AP, lw=0.9))
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel(r"TOJ accuracy change $\Delta\mathrm{Acc}$ (%)")
    ax.set_title(r"TOJ Sequence Memory ($P = 0.046$)")
    ax.legend(loc="lower left", frameon=True, framealpha=0.92, fontsize=6.4, ncol=2)
    add_panel_label(ax, "a")

    # Panel b: Free Recall Change (item count)
    ax = axes[1]
    for grp, col, off, mk in [("ITF-1", COL_ITF_MINUS, -0.15, "o"), ("ITF+1", COL_ITF_PLUS, 0.15, "s")]:
        means, ses = [], []
        for idx_s, s in enumerate(sessions):
            vals = sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["dRecall"].values
            jitter = rng.normal(0, 0.035, size=len(vals))
            ax.scatter(np.full_like(vals, idx_s + off) + jitter, vals, s=14, color=col, alpha=0.25, edgecolor="none")
            means.append(np.mean(vals))
            ses.append(np.std(vals, ddof=1) / np.sqrt(len(vals)))
        ax.errorbar(x + off, means, yerr=ses, marker=mk, ms=6.5, lw=1.8, capsize=3.5, color=col,
                    markeredgecolor="k", markeredgewidth=0.6, label=grp, zorder=5)
    ax.axhline(0, color="#666666", ls=":", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel(r"Free recall change $\Delta\mathrm{Recall}$ (items)")
    ax.set_title(r"Item Free Recall ($\mathrm{Interaction}\ P=0.145$)")
    ax.legend(loc="lower right", frameon=True, framealpha=0.92)
    add_panel_label(ax, "b")

    # Panel c: Model Comparison (Delta AIC across dAcc & Sep_post)
    ax = axes[2]
    models_lbl = ["Algebraic\nDiscriminant", "Detuning\nOnly Null", "More In-Phase\n(CTC Null)"]
    daic_acc = [
        mc_df[(mc_df["target"] == "dAcc_obs") & (mc_df["model"] == "Algebraic_Discriminant_Model")]["delta_AIC"].values[0],
        mc_df[(mc_df["target"] == "dAcc_obs") & (mc_df["model"] == "Null_2_Frequency_Detuning_Only")]["delta_AIC"].values[0],
        mc_df[(mc_df["target"] == "dAcc_obs") & (mc_df["model"] == "Null_1_More_InPhase_Synchrony")]["delta_AIC"].values[0],
    ]
    daic_sep = [
        mc_df[(mc_df["target"] == "Sep_post_obs") & (mc_df["model"] == "Algebraic_Morse_Curvature_Msep")]["delta_AIC"].values[0],
        mc_df[(mc_df["target"] == "Sep_post_obs") & (mc_df["model"] == "Null_2_Frequency_Detuning_Only")]["delta_AIC"].values[0],
        mc_df[(mc_df["target"] == "Sep_post_obs") & (mc_df["model"] == "Null_1_More_InPhase_Synchrony")]["delta_AIC"].values[0],
    ]
    xm = np.arange(3)
    ax.bar(xm - 0.18, daic_acc, width=0.34, color=COL_AP, edgecolor="k", lw=0.7, label=r"TOJ $\Delta\mathrm{Acc}$ ($n=126$)")
    ax.bar(xm + 0.18, daic_sep, width=0.34, color=COL_ITF_PLUS, edgecolor="k", lw=0.7, hatch="//", label=r"Metacog. $\mathrm{Sep}_{\mathrm{post}}$ ($n=120$)")
    ax.axhline(2.0, color="#666666", ls="--", lw=0.9, label=r"$\Delta\mathrm{AIC}=2$ threshold")
    ax.set_xticks(xm)
    ax.set_xticklabels(models_lbl)
    ax.set_ylabel(r"$\Delta\mathrm{AIC}$ relative to best model")
    ax.set_title("Prior-Predictive Model Comparison")
    ax.legend(loc="upper left", frameon=True, framealpha=0.92, fontsize=6.6)
    add_panel_label(ax, "c")

    save_fig(fig, "Figure4")


# =============================================================================
# FIGURE 5: Geometry of Metacognition (Hessian Curvature M_sep & 8,032 Trials)
# =============================================================================
def make_figure5():
    sess_emp = pd.read_csv(os.path.join(RESULTS_DIR, "empirical_session_summary.csv"))
    adj_sep = pd.read_csv(os.path.join(RESULTS_DIR, "empirical_adj_sep_means.csv"))
    sim_df = pd.read_csv(os.path.join(RESULTS_DIR, "model_6condition_predictions.csv"))

    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.8), gridspec_kw={"wspace": 0.36})
    sessions = ["inphase", "antiphase", "sham"]
    x = np.arange(len(sessions))

    # Panel a: Hessian Curvature V''(u) for target vs spurious branch & M_sep
    ax = axes[0]
    u_rng = np.linspace(-1.3, 1.3, 250)
    r_ap = sim_df[(sim_df["group_label"] == "ITF-1") & (sim_df["session"] == "antiphase")].iloc[0]
    r_ip = sim_df[(sim_df["group_label"] == "ITF-1") & (sim_df["session"] == "inphase")].iloc[0]
    curv_ap = 3.0 * u_rng**2 + r_ap["mu_2"]
    curv_ip = 3.0 * u_rng**2 + r_ip["mu_2"]
    ax.plot(u_rng, curv_ap, color=COL_AP, lw=2.0, label=r"ITF-1 Anti-Phase $V''(u)$")
    ax.plot(u_rng, curv_ip, color=COL_IP, lw=2.0, ls="--", label=r"ITF-1 In-Phase $V''(u)$")
    ax.scatter([r_ap["u_plus"], r_ap["u_minus"]], [r_ap["curv_target"], r_ap["curv_spurious"]],
               color=COL_AP, edgecolor="k", s=65, marker="D", zorder=6)
    ax.scatter([r_ip["u_plus"]], [r_ip["curv_target"]], color=COL_IP, edgecolor="k", s=65, marker="o", zorder=6)
    ax.axhline(0, color="#666666", ls=":", lw=0.8)
    ax.annotate(r"Asymmetric gap $\mathcal{M}_{\mathrm{sep}}>0$",
                xy=(r_ap["u_plus"], r_ap["curv_target"]), xytext=(0.15, 3.2), fontsize=7.0,
                arrowprops=dict(arrowstyle="->", color=COL_AP, lw=0.9))
    ax.annotate("Degenerate\numbilical well", xy=(r_ip["u_plus"], r_ip["curv_target"]),
                xytext=(-0.35, 1.55), fontsize=7.0,
                arrowprops=dict(arrowstyle="->", color=COL_IP, lw=0.9))
    ax.set_xlabel(r"Weierstrass coordinate $u$")
    ax.set_ylabel(r"Hessian curvature $\partial^2 V_{\mathrm{eff}}/\partial u^2$")
    ax.set_title("Hessian Curvature Gap & Metacognition")
    ax.legend(loc="upper center", frameon=True, framealpha=0.92, fontsize=6.6)
    add_panel_label(ax, "a")

    # Panel b: Empirical ANCOVA-adjusted Post-Sep & Raw Sep across 6 conditions
    ax = axes[1]
    for grp, col, off, mk in [("ITF-1", COL_ITF_MINUS, -0.14, "o"), ("ITF+1", COL_ITF_PLUS, 0.14, "s")]:
        adj_vals, se_vals = [], []
        for s in sessions:
            adj_vals.append(adj_sep[(adj_sep["group_label"] == grp) & (adj_sep["session"] == s)]["adj_Sep_post"].values[0])
            raw_v = sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["Sep_post"].dropna()
            se_vals.append(raw_v.std(ddof=1) / np.sqrt(len(raw_v)))
        ax.errorbar(x + off, adj_vals, yerr=se_vals, marker=mk, ms=6.8, lw=1.9, capsize=3.5, color=col,
                    markeredgecolor="k", markeredgewidth=0.6, label=f"{grp} Adj. Post-Sep", zorder=5)
    # Mark exact paired FDR contrast in ITF-1 (inphase vs antiphase)
    ax.annotate(r"ITF-1 IP vs. AP:" + "\n" + r"$P_{\mathrm{FDR}}=0.0051, d=-0.82$",
                xy=(-0.14, 0.042), xytext=(0.45, 0.045), fontsize=6.8,
                bbox=dict(boxstyle="round,pad=0.22", fc="white", ec=COL_ITF_MINUS, lw=0.8),
                arrowprops=dict(arrowstyle="->", color=COL_ITF_MINUS, lw=0.9))
    ax.axhline(0, color="#666666", ls=":", lw=0.8)
    ax.set_ylim(-0.04, 0.32)
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel(r"Metacognitive separation ($\mathrm{HCA}-\mathrm{LCA}$)")
    ax.set_title(r"Empirical $\mathrm{Sep}_{\mathrm{post}}$ ($8,032$ trials)")
    ax.legend(loc="upper right", frameon=True, framealpha=0.92, fontsize=6.6)
    add_panel_label(ax, "b")

    # Panel c: Confidence Bias (pHigh) & Morse Index M_sep correlation
    ax = axes[2]
    for grp, col, off, mk in [("ITF-1", COL_ITF_MINUS, -0.14, "o"), ("ITF+1", COL_ITF_PLUS, 0.14, "s")]:
        ph_means, ph_ses = [], []
        for s in sessions:
            vals = sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["pHigh_post"].dropna() * 100.0
            ph_means.append(vals.mean())
            ph_ses.append(vals.std(ddof=1) / np.sqrt(len(vals)))
        ax.errorbar(x + off, ph_means, yerr=ph_ses, marker=mk, ms=6.5, lw=1.8, capsize=3.5, color=col,
                    markeredgecolor="k", markeredgewidth=0.6, label=f"{grp} High Conf. (%)")
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel('Post-tACS "Sure" rate $p_{\\mathrm{High}}$ (%)')
    ax.set_title(r"Confidence Bias ($P = 0.048$)")
    ax.legend(loc="lower right", frameon=True, framealpha=0.92, fontsize=6.6)
    add_panel_label(ax, "c")

    save_fig(fig, "Figure5")


# =============================================================================
# FIGURE 6: Inverse Control Law & Polynomial Homotopy Continuation
# =============================================================================
def make_figure6():
    hom_df = pd.read_csv(os.path.join(RESULTS_DIR, "homotopy_continuation_path.csv"))
    val_df = pd.read_csv(os.path.join(RESULTS_DIR, "participant_model_validation.csv"))
    dk = akm.load_dk68_frontoparietal_params()

    fig, axes = plt.subplots(1, 3, figsize=(12.4, 3.8), gridspec_kw={"wspace": 0.48})

    # Panel a: Polynomial Homotopy Continuation Path s in [0, 1]
    ax = axes[0]
    ax.plot(hom_df["s"], hom_df["x0"], color=COL_ITF_MINUS, lw=2.0, label=r"$x_F(s)$ (Left Frontal)")
    ax.plot(hom_df["s"], hom_df["x1"], color=COL_ITF_PLUS, lw=2.0, ls="--", label=r"$x_P(s)$ (Left Parietal)")
    ax.plot(hom_df["s"], hom_df["x2"], color=COL_AP, lw=2.0, ls="-.", label=r"$x_H(s)$ (Hippocampal)")
    ax_twin = ax.twinx()
    ax_twin.plot(hom_df["s"], np.abs(hom_df["det_J"]), color=COL_SIGMA, lw=1.3, ls=":", label=r"$|\det J(s)|$")
    ax_twin.set_ylabel(r"$|\det J(s)|$ (non-singular)", color=COL_SIGMA)
    ax_twin.tick_params(axis="y", colors=COL_SIGMA)
    ax_twin.spines["top"].set_visible(False)
    ax.set_xlabel("Homotopy continuation parameter $s$")
    ax.set_ylabel("Weierstrass equilibrium $x_i(s)$")
    ax.set_title(r"Homotopy Path (Residual $<4\times 10^{-15}$)")
    ax.legend(loc="lower left", frameon=True, framealpha=0.92, fontsize=6.4)
    add_panel_label(ax, "a")

    # Panel b: Individualized optimal phase & frequency across N=42 participants
    ax = axes[1]
    subj_df = val_df.drop_duplicates("subj")
    itf_grid = np.linspace(3.8, 7.5, 60)
    opt_grid = [akm.inverse_discriminant_control_law(f, dk["tau_fp_s"]) for f in itf_grid]
    ax.plot(itf_grid, [o["Omega_opt_Hz"] for o in opt_grid], color=COL_AP, lw=2.0, label=r"Optimal $\Omega_k^*$ (Hz)")
    ax.plot(itf_grid, itf_grid - 1.0, color=COL_ITF_MINUS, lw=1.2, ls="--", label=r"Fixed $\mathrm{ITF}-1\ \mathrm{Hz}$")
    ax.plot(itf_grid, itf_grid + 1.0, color=COL_ITF_PLUS, lw=1.2, ls=":", label=r"Fixed $\mathrm{ITF}+1\ \mathrm{Hz}$")
    ax.scatter(subj_df["pre_ITF"], subj_df["Omega_opt_Hz"], s=36, color=COL_AP, edgecolor="k", alpha=0.85, zorder=5)
    ax.set_xlabel(r"Baseline $\mathrm{ITF}_{\mathrm{pre}}$ (Hz)")
    ax.set_ylabel(r"Predicted optimal frequency $\Omega_k^*$ (Hz)")
    ax.set_title(r"Personalized Control Law ($N=42$)")
    ax.legend(loc="upper left", frameon=True, framealpha=0.92, fontsize=6.5)
    add_panel_label(ax, "b")

    # Panel c: Responder stratification by distance to individualized optimum
    ax = axes[2]
    act = val_df[val_df["session"] != "sham"].copy()
    act["opt_tertile"] = pd.qcut(act["dist_to_opt"], 3, labels=["Near\nOptimum", "Inter-\nmediate", "Far from\nOptimum"])
    tertiles = ["Near\nOptimum", "Inter-\nmediate", "Far from\nOptimum"]
    t_means = [act[act["opt_tertile"] == t]["dAcc_obs"].mean() for t in tertiles]
    t_ses = [act[act["opt_tertile"] == t]["dAcc_obs"].std(ddof=1) / np.sqrt((act["opt_tertile"] == t).sum()) for t in tertiles]
    cols_t = [COL_AP, COL_IP, COL_SHAM]
    ax.bar(np.arange(3), t_means, yerr=t_ses, capsize=4, color=cols_t, edgecolor="k", lw=0.8, width=0.58)
    ax.axhline(0, color="k", lw=0.7)
    r_val, p_val = stats.pearsonr(act["dist_to_opt"], act["dAcc_obs"])
    ax.text(0.50, 0.92, f"Active sessions ($n=84$):\n$r = {r_val:+.3f},\\ P = {p_val:.3f}$",
            transform=ax.transAxes, ha="center", va="top", fontsize=7.2,
            bbox=dict(boxstyle="round,pad=0.22", fc="white", ec=COL_AP, lw=0.8))
    ax.set_xticks(np.arange(3))
    ax.set_xticklabels(tertiles)
    ax.set_ylabel(r"Observed TOJ gain $\Delta\mathrm{Acc}$ (%)")
    ax.set_title("Control-Distance Responder Stratification")
    add_panel_label(ax, "c")

    save_fig(fig, "Figure6")


# =============================================================================
# SUPPLEMENTARY FIGURES S1 & S2
# =============================================================================
def make_supplementary_figures():
    sens_df = pd.read_csv(os.path.join(RESULTS_DIR, "sensitivity_sweep_25pct.csv"))
    sess_emp = pd.read_csv(os.path.join(RESULTS_DIR, "empirical_session_summary.csv"))

    # Figure S1: +/-25% Parameter Sensitivity + HCA vs LCA Breakdown
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.8), gridspec_kw={"wspace": 0.34})

    ax = axes[0]
    params = sens_df["parameter"].unique()
    y = np.arange(len(params))
    m25 = [sens_df[(sens_df["parameter"] == p) & (sens_df["perturbation"] == "-25%")]["AP_minus_IP_dAcc"].values[0] for p in params]
    p25 = [sens_df[(sens_df["parameter"] == p) & (sens_df["perturbation"] == "+25%")]["AP_minus_IP_dAcc"].values[0] for p in params]
    ax.barh(y - 0.17, m25, height=0.32, color=COL_ITF_PLUS, edgecolor="k", lw=0.6, label=r"$-25\%$ perturbation")
    ax.barh(y + 0.17, p25, height=0.32, color=COL_AP, edgecolor="k", lw=0.6, hatch="//", label=r"$+25\%$ perturbation")
    ax.axvline(0, color="k", lw=0.8)
    ax.set_xlim(0, 8.6)
    ax.set_ylim(-0.6, 6.4)
    ax.set_yticks(y)
    ax.set_yticklabels([r"$v_{\mathrm{cond}}$", r"$\kappa_0$", r"$\kappa_1$", r"$\eta_0$", r"$\eta_1$", r"$\sigma_\xi$"])
    ax.set_xlabel(r"Predicted advantage $\Delta\mathrm{Acc}_{\mathrm{AP}} - \Delta\mathrm{Acc}_{\mathrm{IP}}$ (%)")
    ax.set_title(r"Sensitivity Sweep ($\pm 25\%$; 12/12 Sign Preserved)")
    ax.legend(loc="upper right", frameon=True, framealpha=0.95, fontsize=7.0, ncol=2)
    add_panel_label(ax, "a")

    ax = axes[1]
    sessions = ["inphase", "antiphase", "sham"]
    x = np.arange(len(sessions))
    for grp, ls, col in [("ITF-1", "-", COL_ITF_MINUS), ("ITF+1", "--", COL_ITF_PLUS)]:
        hca = [sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["HCA_post"].mean() * 100 for s in sessions]
        lca = [sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["LCA_post"].mean() * 100 for s in sessions]
        ax.plot(x, hca, marker="o", ms=6, lw=1.8, ls=ls, color=col, label=f"{grp} HCA")
        ax.plot(x, lca, marker="v", ms=6, lw=1.4, ls=":", color=col, label=f"{grp} LCA")
    ax.set_ylim(41, 81)
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel("Post-tACS TOJ accuracy (%)")
    ax.set_title("Confidence-Stratified Accuracy (HCA vs. LCA)")
    ax.legend(loc="lower center", frameon=True, framealpha=0.94, fontsize=6.6, ncol=2)
    add_panel_label(ax, "b")

    save_fig(fig, "FigureS1")

    # Figure S2: Resting Pre/Post ITF & Reaction Time Asymmetry across 6 cells
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.8), gridspec_kw={"wspace": 0.34})
    ax = axes[0]
    for grp, col, off, mk in [("ITF-1", COL_ITF_MINUS, -0.14, "o"), ("ITF+1", COL_ITF_PLUS, 0.14, "s")]:
        pre_m = [sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["pre_ITF"].mean() for s in sessions]
        post_m = [sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["post_ITF"].mean() for s in sessions]
        ax.plot(x + off, pre_m, marker=mk, ms=6, lw=1.5, ls="--", color=col, alpha=0.65, label=f"{grp} Pre-ITF")
        ax.plot(x + off, post_m, marker=mk, ms=6.5, lw=1.9, ls="-", color=col, label=f"{grp} Post-ITF")
    ax.set_ylim(4.82, 5.48)
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel("Individual Theta Frequency (Hz)")
    ax.set_title("Resting-State ITF Stability Pre/Post tACS")
    ax.legend(loc="upper left", frameon=True, framealpha=0.94, fontsize=6.6, ncol=1)
    add_panel_label(ax, "a")

    ax = axes[1]
    for grp, col, off, mk in [("ITF-1", COL_ITF_MINUS, -0.14, "o"), ("ITF+1", COL_ITF_PLUS, 0.14, "s")]:
        rt_m = [sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["post_rt_asym"].mean() for s in sessions]
        rt_se = [sess_emp[(sess_emp["group_label"] == grp) & (sess_emp["session"] == s)]["post_rt_asym"].std(ddof=1) / np.sqrt(21) for s in sessions]
        ax.errorbar(x + off, rt_m, yerr=rt_se, marker=mk, ms=6.5, lw=1.8, capsize=3.5, color=col, label=grp)
    ax.axhline(0, color="#666666", ls=":", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(["In-Phase", "Anti-Phase", "Sham"])
    ax.set_ylabel(r"Post-tACS $\mathrm{RT}_{\mathrm{incorrect}} - \mathrm{RT}_{\mathrm{correct}}$ (s)")
    ax.set_title("Post-Stimulation Error-Monitoring RT Asymmetry")
    ax.legend(loc="upper right", frameon=True, framealpha=0.9)
    add_panel_label(ax, "b")

    save_fig(fig, "FigureS2")


if __name__ == "__main__":
    make_figure1()
    make_figure2()
    make_figure3()
    make_figure4()
    make_figure5()
    make_figure6()
    make_supplementary_figures()
