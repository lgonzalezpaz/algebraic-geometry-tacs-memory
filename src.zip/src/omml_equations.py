#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
omml_equations.py
=================
Constructs native Microsoft Word Office Math Markup Language (OMML, `<m:oMathPara>`)
elements for all mathematical equations (1)-(18) and (S1)-(S6) in the manuscript and
Supplementary Material.

Features physics/mathematics journal typography (Physical Review / Nature Physics style):
- Cambria Math 12 pt display equations
- True stacked fractions (`<m:f>`)
- True N-ary summations (`∑`), products (`∏`), and expectations (`E`)
- Stretchy delimiters `( ... )`, `[ ... ]`, `| ... |`, `⟨ ... ⟩`, `⌊ ... ⌋` (`<m:d>`)
- Upright roman operators and multi-letter subscripts (`d`, `sin`, `cos`, `tan`, `det`, `Im`, `MV`, `Vol`, `conv`, `supp`, `sgn`, `tACS`, `ITF`, `FP`, `wPLI`, `TOJ`, `sep`, `eff`, `cusp`, `seq`, `real`, `complex`, `barrier`, `meta`, `pred`, `opt`)
- Italic single-letter variables and Greek symbols
"""

from __future__ import annotations
from lxml import etree

M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NSMAP = {"m": M_NS, "w": W_NS}


def _m(tag: str, **kwargs) -> etree._Element:
    el = etree.Element(f"{{{M_NS}}}{tag}", nsmap=NSMAP)
    for k, v in kwargs.items():
        el.set(f"{{{M_NS}}}{k}", v)
    return el


def _w(tag: str, **kwargs) -> etree._Element:
    el = etree.Element(f"{{{W_NS}}}{tag}", nsmap=NSMAP)
    for k, v in kwargs.items():
        el.set(f"{{{W_NS}}}{k}", v)
    return el


def m_run(text: str, upright: bool = False, bold: bool = False, size_half_pt: int = 24) -> etree._Element:
    """Create an OMML math run `<m:r>` with Cambria Math font."""
    r = _m("r")
    mrPr = _m("rPr")
    if upright and bold:
        mrPr.append(_m("sty", val="b"))
    elif upright:
        mrPr.append(_m("nor"))
        mrPr.append(_m("sty", val="p"))
    elif bold:
        mrPr.append(_m("sty", val="bi"))
    r.append(mrPr)

    wrPr = _w("rPr")
    rFonts = _w("rFonts")
    rFonts.set(f"{{{W_NS}}}ascii", "Cambria Math")
    rFonts.set(f"{{{W_NS}}}hAnsi", "Cambria Math")
    rFonts.set(f"{{{W_NS}}}cs", "Cambria Math")
    wrPr.append(rFonts)
    sz = _w("sz")
    sz.set(f"{{{W_NS}}}val", str(size_half_pt))
    szCs = _w("szCs")
    szCs.set(f"{{{W_NS}}}val", str(size_half_pt))
    wrPr.append(sz)
    wrPr.append(szCs)
    if bold:
        wrPr.append(_w("b"))
    r.append(wrPr)

    t = _m("t")
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    t.text = text
    r.append(t)
    return r


def _append_items(container: etree._Element, items):
    if isinstance(items, (list, tuple)):
        for it in items:
            container.append(it)
    else:
        container.append(items)


def m_sub(base, sub) -> etree._Element:
    sSub = _m("sSub")
    e = _m("e")
    _append_items(e, base)
    s = _m("sub")
    _append_items(s, sub)
    sSub.append(e)
    sSub.append(s)
    return sSub


def m_sup(base, sup) -> etree._Element:
    sSup = _m("sSup")
    e = _m("e")
    _append_items(e, base)
    s = _m("sup")
    _append_items(s, sup)
    sSup.append(e)
    sSup.append(s)
    return sSup


def m_subsup(base, sub, sup) -> etree._Element:
    sSubSup = _m("sSubSup")
    e = _m("e")
    _append_items(e, base)
    sb = _m("sub")
    _append_items(sb, sub)
    sp = _m("sup")
    _append_items(sp, sup)
    sSubSup.append(e)
    sSubSup.append(sb)
    sSubSup.append(sp)
    return sSubSup


def m_frac(num, den, bar_type: str = "bar") -> etree._Element:
    f = _m("f")
    fPr = _m("fPr")
    fPr.append(_m("type", val=bar_type))
    f.append(fPr)
    n = _m("num")
    _append_items(n, num)
    d = _m("den")
    _append_items(d, den)
    f.append(n)
    f.append(d)
    return f


def m_delim(inner, beg: str = "(", end: str = ")") -> etree._Element:
    d = _m("d")
    dPr = _m("dPr")
    dPr.append(_m("begChr", val=beg))
    dPr.append(_m("endChr", val=end))
    d.append(dPr)
    e = _m("e")
    _append_items(e, inner)
    d.append(e)
    return d


def m_nary(symbol: str, sub, sup, body, lim_loc: str = "undOvr") -> etree._Element:
    nary = _m("nary")
    naryPr = _m("naryPr")
    naryPr.append(_m("chr", val=symbol))
    naryPr.append(_m("limLoc", val=lim_loc))
    if sub is None:
        naryPr.append(_m("subHide", val="1"))
    if sup is None:
        naryPr.append(_m("supHide", val="1"))
    nary.append(naryPr)
    sb = _m("sub")
    if sub is not None:
        _append_items(sb, sub)
    sp = _m("sup")
    if sup is not None:
        _append_items(sp, sup)
    e = _m("e")
    _append_items(e, body)
    nary.append(sb)
    nary.append(sp)
    nary.append(e)
    return nary


def m_acc(base, chr_val: str = "\u0304") -> etree._Element:
    acc = _m("acc")
    accPr = _m("accPr")
    accPr.append(_m("chr", val=chr_val))
    acc.append(accPr)
    e = _m("e")
    _append_items(e, base)
    acc.append(e)
    return acc


def wrap_omath_para(elements: list[etree._Element]) -> etree._Element:
    oMathPara = _m("oMathPara")
    oMathParaPr = _m("oMathParaPr")
    oMathParaPr.append(_m("jc", val="center"))
    oMathPara.append(oMathParaPr)
    oMath = _m("oMath")
    for el in elements:
        oMath.append(el)
    oMathPara.append(oMath)
    return oMathPara


def build_equation_omml(eq_num: str) -> etree._Element | None:
    """Return an `<m:oMathPara>` element for equation '(1)'..'(18)' or '(S1)'..'(S6)'."""
    key = eq_num.strip()

    if key == "(1)":
        # dθ_i/dt = ω_i + Σ_{j=1}^N K_{ij} sin(θ_j - θ_i - α_{ij}) + A_i sin(Ωt + ϕ_i - θ_i) + ξ_i(t)
        summand = [
            m_sub(m_run("K"), m_run("ij")),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim([m_sub(m_run("θ"), m_run("j")), m_run(" − "), m_sub(m_run("θ"), m_run("i")), m_run(" − "), m_sub(m_run("α"), m_run("ij"))], "(", ")"),
        ]
        return wrap_omath_para([
            m_frac([m_run("d", upright=True), m_sub(m_run("θ"), m_run("i"))], [m_run("d", upright=True), m_run("t")]),
            m_run(" = "),
            m_sub(m_run("ω"), m_run("i")),
            m_run(" + "),
            m_nary("∑", [m_run("j"), m_run("=", upright=True), m_run("1", upright=True)], m_run("N"), summand),
            m_run(" + "),
            m_sub(m_run("A"), m_run("i")),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim([m_run("Ωt + "), m_sub(m_run("ϕ"), m_run("i")), m_run(" − "), m_sub(m_run("θ"), m_run("i"))], "(", ")"),
            m_run(" + "),
            m_sub(m_run("ξ"), m_run("i")),
            m_delim(m_run("t"), "(", ")"),
        ])

    if key == "(2)":
        # dψ_i/dt = ΔΩ_i + Σ_{j=1}^N K_{ij} sin(ψ_j - ψ_i - α_{ij}) - A_i sin(ψ_i - ϕ_i)
        summand = [
            m_sub(m_run("K"), m_run("ij")),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim([m_sub(m_run("ψ"), m_run("j")), m_run(" − "), m_sub(m_run("ψ"), m_run("i")), m_run(" − "), m_sub(m_run("α"), m_run("ij"))], "(", ")"),
        ]
        return wrap_omath_para([
            m_frac([m_run("d", upright=True), m_sub(m_run("ψ"), m_run("i"))], [m_run("d", upright=True), m_run("t")]),
            m_run(" = Δ"),
            m_sub(m_run("Ω"), m_run("i")),
            m_run(" + "),
            m_nary("∑", [m_run("j"), m_run("=", upright=True), m_run("1", upright=True)], m_run("N"), summand),
            m_run(" − "),
            m_sub(m_run("A"), m_run("i")),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim([m_sub(m_run("ψ"), m_run("i")), m_run(" − "), m_sub(m_run("ϕ"), m_run("i"))], "(", ")"),
        ])

    if key == "(3)":
        # d(Δψ)/dt = Δω_{FP} - 2 K_{FP} cos(α_{FP}) sin(Δψ) - 2 A_{tACS} sin((Δψ - Δϕ)/2) cos(ψ̄ - ϕ̄)
        return wrap_omath_para([
            m_frac([m_run("d", upright=True), m_delim(m_run("Δψ"), "(", ")")], [m_run("d", upright=True), m_run("t")]),
            m_run(" = Δ"),
            m_sub(m_run("ω"), m_run("FP", upright=True)),
            m_run(" − 2"),
            m_sub(m_run("K"), m_run("FP", upright=True)),
            m_run(" "),
            m_run("cos", upright=True),
            m_delim(m_sub(m_run("α"), m_run("FP", upright=True)), "(", ")"),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim(m_run("Δψ"), "(", ")"),
            m_run(" − 2"),
            m_sub(m_run("A"), m_run("tACS", upright=True)),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim(m_frac([m_run("Δψ − Δϕ")], m_run("2", upright=True)), "(", ")"),
            m_run(" "),
            m_run("cos", upright=True),
            m_delim([m_acc(m_run("ψ")), m_run(" − "), m_acc(m_run("ϕ"))], "(", ")"),
        ])

    if key == "(4)":
        # sin(ψ_i) = 2x_i / (1 + x_i^2), cos(ψ_i) = (1 - x_i^2) / (1 + x_i^2)
        return wrap_omath_para([
            m_run("sin", upright=True),
            m_delim(m_sub(m_run("ψ"), m_run("i")), "(", ")"),
            m_run(" = "),
            m_frac([m_run("2", upright=True), m_sub(m_run("x"), m_run("i"))], [m_run("1", upright=True), m_run(" + "), m_subsup(m_run("x"), m_run("i"), m_run("2", upright=True))]),
            m_run(",   "),
            m_run("cos", upright=True),
            m_delim(m_sub(m_run("ψ"), m_run("i")), "(", ")"),
            m_run(" = "),
            m_frac([m_run("1", upright=True), m_run(" − "), m_subsup(m_run("x"), m_run("i"), m_run("2", upright=True))], [m_run("1", upright=True), m_run(" + "), m_subsup(m_run("x"), m_run("i"), m_run("2", upright=True))]),
        ])

    if key == "(5)":
        # I = ⟨ f_1(x_1,...,x_N), ..., f_N(x_1,...,x_N) ⟩ ⊂ ℝ[x_1,...,x_N]
        return wrap_omath_para([
            m_run("I"),
            m_run(" = "),
            m_delim([
                m_sub(m_run("f"), m_run("1", upright=True)),
                m_delim([m_sub(m_run("x"), m_run("1", upright=True)), m_run(", …, "), m_sub(m_run("x"), m_run("N"))], "(", ")"),
                m_run(", …, "),
                m_sub(m_run("f"), m_run("N")),
                m_delim([m_sub(m_run("x"), m_run("1", upright=True)), m_run(", …, "), m_sub(m_run("x"), m_run("N"))], "(", ")"),
            ], "⟨", "⟩"),
            m_run(" ⊂ ℝ"),
            m_delim([m_sub(m_run("x"), m_run("1", upright=True)), m_run(", …, "), m_sub(m_run("x"), m_run("N"))], "[", "]"),
        ])

    if key == "(6)":
        # f_i(x) = ΔΩ_i ∏_k (1 + x_k^2) + Σ_j K_{ij} P_{ij}(x_i,x_j;α_{ij}) ∏_{k≠i,j} (1 + x_k^2) - A_i Q_i(x_i;ϕ_i) ∏_{k≠i} (1 + x_k^2) = 0
        fac = m_delim([m_run("1", upright=True), m_run(" + "), m_subsup(m_run("x"), m_run("k"), m_run("2", upright=True))], "(", ")")
        return wrap_omath_para([
            m_sub(m_run("f"), m_run("i")),
            m_delim(m_run("x", bold=True), "(", ")"),
            m_run(" = Δ"),
            m_sub(m_run("Ω"), m_run("i")),
            m_run(" "),
            m_nary("∏", [m_run("k"), m_run("=", upright=True), m_run("1", upright=True)], m_run("N"), fac),
            m_run(" + "),
            m_nary("∑", [m_run("j"), m_run("≠", upright=True), m_run("i")], None, [
                m_sub(m_run("K"), m_run("ij")),
                m_sub(m_run("P"), m_run("ij")),
                m_delim([m_sub(m_run("x"), m_run("i")), m_run(", "), m_sub(m_run("x"), m_run("j")), m_run("; "), m_sub(m_run("α"), m_run("ij"))], "(", ")"),
                m_nary("∏", [m_run("k≠i,j")], None, m_delim([m_run("1", upright=True), m_run(" + "), m_subsup(m_run("x"), m_run("k"), m_run("2", upright=True))], "(", ")")),
            ]),
            m_run(" − "),
            m_sub(m_run("A"), m_run("i")),
            m_sub(m_run("Q"), m_run("i")),
            m_delim([m_sub(m_run("x"), m_run("i")), m_run("; "), m_sub(m_run("ϕ"), m_run("i"))], "(", ")"),
            m_nary("∏", [m_run("k≠i")], None, m_delim([m_run("1", upright=True), m_run(" + "), m_subsup(m_run("x"), m_run("k"), m_run("2", upright=True))], "(", ")")),
            m_run(" = 0", upright=True),
        ])

    if key == "(7)":
        # Σ = { p ∈ P | ∃ x ∈ V(I) : f(x;p) = 0 and det J(x;p) = 0 }
        return wrap_omath_para([
            m_run("Σ = "),
            m_delim([
                m_run("p", bold=True),
                m_run(" ∈ "),
                m_run("P"),
                m_run("  |  ∃ "),
                m_run("x", bold=True),
                m_run(" ∈ "),
                m_run("V"),
                m_delim(m_run("I"), "(", ")"),
                m_run(" : "),
                m_run("f", bold=True),
                m_delim([m_run("x", bold=True), m_run("; "), m_run("p", bold=True)], "(", ")"),
                m_run(" = "),
                m_run("0", upright=True, bold=True),
                m_run("  and  "),
                m_run("det", upright=True),
                m_run(" "),
                m_run("J"),
                m_delim([m_run("x", bold=True), m_run("; "), m_run("p", bold=True)], "(", ")"),
                m_run(" = 0", upright=True),
            ], "{", "}"),
        ])

    if key == "(8)":
        # V_eff(u; μ_1, μ_2) = (1/4) u^4 + (μ_2/2) u^2 + μ_1 u
        return wrap_omath_para([
            m_sub(m_run("V"), m_run("eff", upright=True)),
            m_delim([m_run("u; "), m_sub(m_run("μ"), m_run("1", upright=True)), m_run(", "), m_sub(m_run("μ"), m_run("2", upright=True))], "(", ")"),
            m_run(" = "),
            m_frac(m_run("1", upright=True), m_run("4", upright=True)),
            m_sup(m_run("u"), m_run("4", upright=True)),
            m_run(" + "),
            m_frac(m_sub(m_run("μ"), m_run("2", upright=True)), m_run("2", upright=True)),
            m_sup(m_run("u"), m_run("2", upright=True)),
            m_run(" + "),
            m_sub(m_run("μ"), m_run("1", upright=True)),
            m_run("u"),
        ])

    if key == "(9)":
        # μ_2 = κ_0 + κ_freq Δf_eff + κ_1 A_norm cos(Δϕ),  μ_1 = 0.25 η_0 sin(α_FP) - 0.18 η_1 A_norm sin(Δϕ/2) sgn(-Δf_eff)
        return wrap_omath_para([
            m_sub(m_run("μ"), m_run("2", upright=True)),
            m_run(" = "),
            m_sub(m_run("κ"), m_run("0", upright=True)),
            m_run(" + "),
            m_sub(m_run("κ"), m_run("freq", upright=True)),
            m_run(" Δ"),
            m_sub(m_run("f"), m_run("eff", upright=True)),
            m_run(" + "),
            m_sub(m_run("κ"), m_run("1", upright=True)),
            m_sub(m_run("A"), m_run("norm", upright=True)),
            m_run(" "),
            m_run("cos", upright=True),
            m_delim(m_run("Δϕ"), "(", ")"),
            m_run(",   "),
            m_sub(m_run("μ"), m_run("1", upright=True)),
            m_run(" = 0.25"),
            m_sub(m_run("η"), m_run("0", upright=True)),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim(m_sub(m_run("α"), m_run("FP", upright=True)), "(", ")"),
            m_run(" − 0.18"),
            m_sub(m_run("η"), m_run("1", upright=True)),
            m_sub(m_run("A"), m_run("norm", upright=True)),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim(m_frac(m_run("Δϕ"), m_run("2", upright=True)), "(", ")"),
            m_run(" "),
            m_run("sgn", upright=True),
            m_delim([m_run("−Δ"), m_sub(m_run("f"), m_run("eff", upright=True))], "(", ")"),
        ])

    if key == "(10)":
        # Δ_cusp(ΔΩ, Δϕ, A_tACS) = 4 μ_2^3 + 27 μ_1^2 = 0
        return wrap_omath_para([
            m_sub(m_run("Δ"), m_run("cusp", upright=True)),
            m_delim([m_run("ΔΩ, Δϕ, "), m_sub(m_run("A"), m_run("tACS", upright=True))], "(", ")"),
            m_run(" = 4"),
            m_subsup(m_run("μ"), m_run("2", upright=True), m_run("3", upright=True)),
            m_run(" + 27"),
            m_subsup(m_run("μ"), m_run("1", upright=True), m_run("2", upright=True)),
            m_run(" = 0", upright=True),
        ])

    if key == "(11)":
        # N_real(I) ≤ N_complex^trig(I) ≤ MV(N_1,...,N_N) = Σ (-1)^{N-|S|} Vol_N(Σ N_i) = N! 2^N
        return wrap_omath_para([
            m_sub(m_run("N"), m_run("real", upright=True)),
            m_delim(m_run("I"), "(", ")"),
            m_run(" ≤ "),
            m_subsup(m_run("N"), m_run("complex", upright=True), m_run("trig", upright=True)),
            m_delim(m_run("I"), "(", ")"),
            m_run(" ≤ "),
            m_run("MV", upright=True),
            m_delim([m_sub(m_run("N"), m_run("1", upright=True)), m_run(", …, "), m_sub(m_run("N"), m_run("N"))], "(", ")"),
            m_run(" = "),
            m_nary("∑", [m_run("S⊆{1,…,N}")], None, [
                m_sup(m_delim(m_run("−1", upright=True), "(", ")"), [m_run("N−"), m_delim(m_run("S"), "|", "|")]),
                m_sub(m_run("Vol", upright=True), m_run("N")),
                m_delim(m_nary("∑", m_run("i∈S"), None, m_sub(m_run("N"), m_run("i"))), "(", ")"),
            ]),
            m_run(" = "),
            m_run("N! "),
            m_sup(m_run("2", upright=True), m_run("N")),
        ])

    if key == "(12)":
        # V_seq(Ω, Δϕ) = MV(N_1,...,N_N) · ⌊(2π/Ω - 2τ_FP) / T_γ⌋ · Θ(-Δ_cusp(Ω, Δϕ)) ∝ Ω^{-1}
        return wrap_omath_para([
            m_sub(m_run("V"), m_run("seq", upright=True)),
            m_delim(m_run("Ω, Δϕ"), "(", ")"),
            m_run(" = "),
            m_run("MV", upright=True),
            m_delim([m_sub(m_run("N"), m_run("1", upright=True)), m_run(", …, "), m_sub(m_run("N"), m_run("N"))], "(", ")"),
            m_run(" · "),
            m_delim(m_frac([m_frac(m_run("2π"), m_run("Ω")), m_run(" − 2"), m_sub(m_run("τ"), m_run("FP", upright=True))], m_sub(m_run("T"), m_run("γ"))), "⌊", "⌋"),
            m_run(" · Θ"),
            m_delim([m_run("−"), m_sub(m_run("Δ"), m_run("cusp", upright=True)), m_delim(m_run("Ω, Δϕ"), "(", ")")], "(", ")"),
            m_run(" ∝ "),
            m_sup(m_run("Ω"), m_run("−1", upright=True)),
        ])

    if key == "(13)":
        # ΔAcc_pred = ΔAcc_0 + I_AP- β_seq ΔV_barrier (f_ITF/f_stim) - I_AP+ β_slip (1 + 0.35|Δf|)(f_stim/f_ITF) - I_IP β_umb K_target
        return wrap_omath_para([
            m_run("Δ"),
            m_sub(m_run("Acc", upright=True), m_run("pred", upright=True)),
            m_run(" = Δ"),
            m_sub(m_run("Acc", upright=True), m_run("0", upright=True)),
            m_run(" + "),
            m_sub(m_run("I", bold=True), m_run("AP−", upright=True)),
            m_sub(m_run("β"), m_run("seq", upright=True)),
            m_run("Δ"),
            m_sub(m_run("V"), m_run("barrier", upright=True)),
            m_delim(m_frac(m_sub(m_run("f"), m_run("ITF", upright=True)), m_sub(m_run("f"), m_run("stim", upright=True))), "(", ")"),
            m_run(" − "),
            m_sub(m_run("I", bold=True), m_run("AP+", upright=True)),
            m_sub(m_run("β"), m_run("slip", upright=True)),
            m_delim([m_run("1", upright=True), m_run(" + 0.35"), m_delim(m_run("Δf"), "|", "|")], "(", ")"),
            m_delim(m_frac(m_sub(m_run("f"), m_run("stim", upright=True)), m_sub(m_run("f"), m_run("ITF", upright=True))), "(", ")"),
            m_run(" − "),
            m_sub(m_run("I", bold=True), m_run("IP", upright=True)),
            m_sub(m_run("β"), m_run("umb", upright=True)),
            m_sub(m_run("K"), m_run("target", upright=True)),
        ])

    if key == "(14)":
        # wPLI_eff(u*) = (2|u*| / (1 + (u*)^2)) exp(-σ_ψ^2 / 2)
        return wrap_omath_para([
            m_sub(m_run("wPLI", upright=True), m_run("eff", upright=True)),
            m_delim(m_sup(m_run("u"), m_run("*")), "(", ")"),
            m_run(" = "),
            m_frac(
                [m_run("2", upright=True), m_delim(m_sup(m_run("u"), m_run("*")), "|", "|")],
                [m_run("1", upright=True), m_run(" + "), m_sup(m_delim(m_sup(m_run("u"), m_run("*")), "(", ")"), m_run("2", upright=True))],
            ),
            m_run(" "),
            m_run("exp", upright=True),
            m_delim([m_run("−"), m_frac(m_subsup(m_run("σ"), m_run("ψ"), m_run("2", upright=True)), m_run("2", upright=True))], "(", ")"),
        ])

    if key == "(15)":
        # ΔwPLI_FP(Δϕ) = wPLI_FP(u*(Δϕ, A_tACS)) - wPLI_FP(u*(0)) > 0 ⟺ |u*(Δϕ)| ∈ (|u_0*|, |u_0*|^{-1})
        return wrap_omath_para([
            m_run("Δ"),
            m_sub(m_run("wPLI", upright=True), m_run("FP", upright=True)),
            m_delim(m_run("Δϕ"), "(", ")"),
            m_run(" = "),
            m_sub(m_run("wPLI", upright=True), m_run("FP", upright=True)),
            m_delim([m_sup(m_run("u"), m_run("*")), m_delim([m_run("Δϕ, "), m_sub(m_run("A"), m_run("tACS", upright=True))], "(", ")")], "(", ")"),
            m_run(" − "),
            m_sub(m_run("wPLI", upright=True), m_run("FP", upright=True)),
            m_delim([m_sup(m_run("u"), m_run("*")), m_delim(m_run("0", upright=True), "(", ")")], "(", ")"),
            m_run(" > 0  ⟺  "),
            m_delim([m_sup(m_run("u"), m_run("*")), m_delim(m_run("Δϕ"), "(", ")")], "|", "|"),
            m_run(" ∈ "),
            m_delim([m_delim(m_subsup(m_run("u"), m_run("0", upright=True), m_run("*")), "|", "|"), m_run(", "), m_sup(m_delim(m_subsup(m_run("u"), m_run("0", upright=True), m_run("*")), "|", "|"), m_run("−1", upright=True))], "(", ")"),
        ])

    if key == "(16)":
        # M_sep = I_AP- [ (K_+ - K_-)/(K_+ + K_- + σ_ξ^2) + 0.40 ΔV_barrier (f_ITF/f_stim) ] + I_IP [ -0.55 μ_2/(1+|μ_2|) W_res + 0.05(1 - W_res) ] + I_AP+ 0.06 (f_ITF/f_stim)
        lam_p = m_sub(m_run("K"), m_run("+"))
        lam_m = m_sub(m_run("K"), m_run("−"))
        return wrap_omath_para([
            m_sub(m_run("M"), m_run("sep", upright=True)),
            m_run(" = "),
            m_sub(m_run("I", bold=True), m_run("AP−", upright=True)),
            m_delim([
                m_frac([lam_p, m_run(" − "), lam_m], [lam_p, m_run(" + "), lam_m, m_run(" + "), m_subsup(m_run("σ"), m_run("ξ"), m_run("2", upright=True))]),
                m_run(" + 0.40Δ"),
                m_sub(m_run("V"), m_run("barrier", upright=True)),
                m_frac(m_sub(m_run("f"), m_run("ITF", upright=True)), m_sub(m_run("f"), m_run("stim", upright=True))),
            ], "[", "]"),
            m_run(" + "),
            m_sub(m_run("I", bold=True), m_run("IP", upright=True)),
            m_delim([
                m_run("−0.55"),
                m_frac(m_sub(m_run("μ"), m_run("2", upright=True)), [m_run("1", upright=True), m_run(" + "), m_delim(m_sub(m_run("μ"), m_run("2", upright=True)), "|", "|")]),
                m_sub(m_run("W"), m_run("res", upright=True)),
                m_run(" + 0.05"),
                m_delim([m_run("1", upright=True), m_run(" − "), m_sub(m_run("W"), m_run("res", upright=True))], "(", ")"),
            ], "[", "]"),
            m_run(" + 0.06"),
            m_sub(m_run("I", bold=True), m_run("AP+", upright=True)),
            m_frac(m_sub(m_run("f"), m_run("ITF", upright=True)), m_sub(m_run("f"), m_run("stim", upright=True))),
        ])

    if key == "(17)":
        # Sep_pred(Ω, Δϕ, A_tACS) = Sep_0 + γ_meta M_sep(Ω, Δϕ, A_tACS)
        return wrap_omath_para([
            m_sub(m_run("Sep", upright=True), m_run("pred", upright=True)),
            m_delim([m_run("Ω, Δϕ, "), m_sub(m_run("A"), m_run("tACS", upright=True))], "(", ")"),
            m_run(" = "),
            m_sub(m_run("Sep", upright=True), m_run("0", upright=True)),
            m_run(" + "),
            m_sub(m_run("γ"), m_run("meta", upright=True)),
            m_run(" "),
            m_sub(m_run("M"), m_run("sep", upright=True)),
            m_delim([m_run("Ω, Δϕ, "), m_sub(m_run("A"), m_run("tACS", upright=True))], "(", ")"),
        ])

    if key == "(18)":
        # f_k* = f_{ITF,k} (1 - c_f / (2 Q_k)),  Δϕ_k* = π - α_{FP,k},  A_k* = clip_{[1.2,2.2]}[ γ_A (2 K_{FP,k} cos(α_{FP,k}) / κ_1)(1 + (3/4)(η_0 sin(α_{FP,k})/K_{FP,k})^{2/3}) ]
        return wrap_omath_para([
            m_subsup(m_run("f"), m_run("k"), m_run("*")),
            m_run(" = "),
            m_sub(m_run("f"), m_run("ITF,k", upright=True)),
            m_delim([m_run("1", upright=True), m_run(" − "), m_frac(m_sub(m_run("c"), m_run("f")), [m_run("2", upright=True), m_sub(m_run("Q"), m_run("k"))])], "(", ")"),
            m_run(",   Δ"),
            m_subsup(m_run("ϕ"), m_run("k"), m_run("*")),
            m_run(" = π − "),
            m_sub(m_run("α"), m_run("FP,k", upright=True)),
            m_run(",   "),
            m_subsup(m_run("A"), m_run("k"), m_run("*")),
            m_run(" = "),
            m_sub(m_run("γ"), m_run("A")),
            m_frac([m_run("2", upright=True), m_sub(m_run("K"), m_run("FP,k", upright=True)), m_run(" "), m_run("cos", upright=True), m_delim(m_sub(m_run("α"), m_run("FP,k", upright=True)), "(", ")")], m_sub(m_run("κ"), m_run("1", upright=True))),
            m_delim([
                m_run("1", upright=True),
                m_run(" + "),
                m_frac(m_run("3", upright=True), m_run("4", upright=True)),
                m_sup(m_delim(m_frac([m_sub(m_run("η"), m_run("0", upright=True)), m_run(" "), m_run("sin", upright=True), m_delim(m_sub(m_run("α"), m_run("FP,k", upright=True)), "(", ")")], m_sub(m_run("K"), m_run("FP,k", upright=True))), "(", ")"), m_frac(m_run("2", upright=True), m_run("3", upright=True), "lin")),
            ], "(", ")"),
        ])

    # Supplementary Equations (S1) - (S6)
    if key == "(S1)":
        # P_{ij}(x_i, x_j; α_{ij}) = cos(α_{ij}) [2x_j(1-x_i^2) - 2x_i(1-x_j^2)] - sin(α_{ij}) [(1-x_i^2)(1-x_j^2) + 4x_i x_j]
        return wrap_omath_para([
            m_sub(m_run("P"), m_run("ij")),
            m_delim([m_sub(m_run("x"), m_run("i")), m_run(", "), m_sub(m_run("x"), m_run("j")), m_run("; "), m_sub(m_run("α"), m_run("ij"))], "(", ")"),
            m_run(" = "),
            m_run("cos", upright=True),
            m_delim(m_sub(m_run("α"), m_run("ij")), "(", ")"),
            m_delim([
                m_run("2", upright=True), m_sub(m_run("x"), m_run("j")), m_delim([m_run("1", upright=True), m_run(" − "), m_subsup(m_run("x"), m_run("i"), m_run("2", upright=True))], "(", ")"),
                m_run(" − 2"), m_sub(m_run("x"), m_run("i")), m_delim([m_run("1", upright=True), m_run(" − "), m_subsup(m_run("x"), m_run("j"), m_run("2", upright=True))], "(", ")"),
            ], "[", "]"),
            m_run(" − "),
            m_run("sin", upright=True),
            m_delim(m_sub(m_run("α"), m_run("ij")), "(", ")"),
            m_delim([
                m_delim([m_run("1", upright=True), m_run(" − "), m_subsup(m_run("x"), m_run("i"), m_run("2", upright=True))], "(", ")"),
                m_delim([m_run("1", upright=True), m_run(" − "), m_subsup(m_run("x"), m_run("j"), m_run("2", upright=True))], "(", ")"),
                m_run(" + 4"), m_sub(m_run("x"), m_run("i")), m_sub(m_run("x"), m_run("j")),
            ], "[", "]"),
        ])

    if key == "(S2)":
        # Q_i(x_i; ϕ_i) = 2 x_i cos(ϕ_i) - (1 - x_i^2) sin(ϕ_i)
        return wrap_omath_para([
            m_sub(m_run("Q"), m_run("i")),
            m_delim([m_sub(m_run("x"), m_run("i")), m_run("; "), m_sub(m_run("ϕ"), m_run("i"))], "(", ")"),
            m_run(" = 2"),
            m_sub(m_run("x"), m_run("i")),
            m_run(" "),
            m_run("cos", upright=True),
            m_delim(m_sub(m_run("ϕ"), m_run("i")), "(", ")"),
            m_run(" − "),
            m_delim([m_run("1", upright=True), m_run(" − "), m_subsup(m_run("x"), m_run("i"), m_run("2", upright=True))], "(", ")"),
            m_run(" "),
            m_run("sin", upright=True),
            m_delim(m_sub(m_run("ϕ"), m_run("i")), "(", ")"),
        ])

    if key == "(S3)":
        # d^2 V_eff / du^2 |_{u*} = 3 (u*)^2 + μ_2 > 0
        return wrap_omath_para([
            m_frac([m_sup(m_run("d", upright=True), m_run("2", upright=True)), m_sub(m_run("V"), m_run("eff", upright=True))], [m_run("d", upright=True), m_sup(m_run("u"), m_run("2", upright=True))]),
            m_sub(m_run(" "), m_sup(m_run("u"), m_run("*"))),
            m_run(" = 3"),
            m_sup(m_delim(m_sup(m_run("u"), m_run("*")), "(", ")"), m_run("2", upright=True)),
            m_run(" + "),
            m_sub(m_run("μ"), m_run("2", upright=True)),
            m_run(" > 0", upright=True),
        ])

    if key == "(S4)":
        # K_Gauss(x*) = det H_V(x*) = ∏_{m=1}^N λ_m(H_V(x*))
        return wrap_omath_para([
            m_sub(m_run("K"), m_run("Gauss", upright=True)),
            m_delim(m_sup(m_run("x", bold=True), m_run("*")), "(", ")"),
            m_run(" = "),
            m_run("det", upright=True),
            m_run(" "),
            m_sub(m_run("H"), m_run("V")),
            m_delim(m_sup(m_run("x", bold=True), m_run("*")), "(", ")"),
            m_run(" = "),
            m_nary("∏", [m_run("m"), m_run("=", upright=True), m_run("1", upright=True)], m_run("N"), [
                m_sub(m_run("λ"), m_run("m")),
                m_delim([m_sub(m_run("H"), m_run("V")), m_delim(m_sup(m_run("x", bold=True), m_run("*")), "(", ")")], "(", ")"),
            ]),
        ])

    if key == "(S5)":
        # H(x, s) = F(x; s p_target) = 0, s ∈ [0, 1]
        return wrap_omath_para([
            m_run("H", bold=True),
            m_delim([m_run("x", bold=True), m_run(", s")], "(", ")"),
            m_run(" = "),
            m_run("F", bold=True),
            m_delim([m_run("x", bold=True), m_run("; s "), m_sub(m_run("p", bold=True), m_run("target", upright=True))], "(", ")"),
            m_run(" = "),
            m_run("0", upright=True, bold=True),
            m_run(",   s ∈ "),
            m_delim(m_run("0, 1", upright=True), "[", "]"),
        ])

    if key == "(S6)":
        # wPLI_debiased = ( (Σ Im_e)^2 - Σ Im_e^2 ) / ( (Σ |Im_e|)^2 - Σ Im_e^2 )
        ime = m_sub(m_run("Im", upright=True), m_run("e"))
        return wrap_omath_para([
            m_sub(m_run("wPLI", upright=True), m_run("debiased", upright=True)),
            m_run(" = "),
            m_frac(
                [m_sup(m_delim(m_nary("∑", m_run("e"), None, ime), "(", ")"), m_run("2", upright=True)), m_run(" − "), m_nary("∑", m_run("e"), None, m_subsup(m_run("Im", upright=True), m_run("e"), m_run("2", upright=True)))],
                [m_sup(m_delim(m_nary("∑", m_run("e"), None, m_delim(ime, "|", "|")), "(", ")"), m_run("2", upright=True)), m_run(" − "), m_nary("∑", m_run("e"), None, m_subsup(m_run("Im", upright=True), m_run("e"), m_run("2", upright=True)))],
            ),
        ])

    return None
