% by TA 10.2024, Maastricht
% In this script recognition part will be ignored. 
% Use only for encoding and temporal order task.

% Clear the workspace 
clear;
close all;
clc;


% Reset all Screen preferences to their default values
Screen('Preference', 'VisualDebugLevel', 3); 
Screen('Preference', 'SuppressAllWarnings', 0); 
Screen('Preference', 'Verbosity', 4); 

eegConnected = true;

if eegConnected
    ioObj = io64;
    status = io64(ioObj);
    if status ~= 0
        error('IO64 installation failed');
    end
    port2Address = hex2dec('4FF8'); % Use the correct address for your parallel port
end

% Prompt for subject name, session number, and task type
prompt = {'Enter subject ID:', 'Enter session number:', 'Enter task type (e for encoding, r for recognition, t for temporal order):'};
dlgtitle = 'Input';
dims = [1 50];
definput = {'', '', ''};
answer = inputdlg(prompt, dlgtitle, dims, definput);

% Check if the user canceled the input dialog
if isempty(answer)
    disp('Experiment canceled by user.');
    return;
end

% Extract subject name, session number, and task type
subjectName = answer{1};
sessionNumber = answer{2};
taskType = answer{3};

% Generate a filename for saving the workspace
saveFilename = sprintf('%s_task_%s_session%s.mat', taskType, subjectName, sessionNumber);

% Define or load the fixed order and ISI values
if strcmp(taskType, 'e')
    % Load the pre-generated image Order
    load('fixedOrder.mat', 'fixedOrder');
    disp('Order values loaded from fixedOrder.mat');
    % Load the pre-generated ISI values
    load('fixedISI.mat', 'fixedISI');
    disp('ISI values loaded from fixedISI.mat');
    % Save the fixedOrder and fixedISI for later use
    save(sprintf('workspace_%s_session%s.mat', subjectName, sessionNumber), 'fixedOrder', 'fixedISI');
elseif strcmp(taskType, 'r') || strcmp(taskType, 't')
    % Load the necessary data for the recognition or temporal order task
    load(sprintf('workspace_%s_session%s.mat', subjectName, sessionNumber), 'fixedOrder', 'fixedISI');
    
    % Extend ISI to 120 by repeating the fixed ISI values if necessary
    if strcmp(taskType, 'r')
        fixedISI = repmat(fixedISI, 1, 2);
    end
else
    error('Invalid task type. Please enter "e" for encoding, "r" for recognition, or "t" for temporal order.');
end

try
    % Unify key names across operating systems
    KbName('UnifyKeyNames');
    
    % Set the file path for the images
    imagePath = 'PATH\objectSetA'; % Update with your path
    novelImagePath = 'PATH\objectSetA'; % Update with your path
    imageFiles = dir(fullfile(imagePath, '*.jpg')); % Assuming the images are in .jpg format
    novelImageFiles = dir(fullfile(novelImagePath, '*.jpg'));
    numImages = length(imageFiles);
    numNovelImages = length(novelImageFiles);

    % Check if there are enough images
    if strcmp(taskType, 'r') && (numImages < 72 || numNovelImages < 72)
        error('There are less than 72 images in one of the specified directories.');
    end

    % Set up Psychtoolbox with additional settings to aid synchronization
    Screen('Preference', 'ConserveVRAM', 4096); % Try to reduce VRAM usage

    % Check if the screen ID is available
    screens = Screen('Screens');
    screenId = screens(1); % Change this index to select a different screen

    % Try to open the window on the specified screen
    [win, rect] = Screen('OpenWindow', screenId, [0, 0, 0]); % Black background

    if strcmp(taskType, 'e') 
        % --- Encoding Task ---
        % Display the introduction message for the encoding task
        Screen('TextSize', win, 40);
        DrawFormattedText(win, ['You will see a series of images.Please pay attention to each one\n' .... 
            'and try to memorize both the images and their positions in the sequence.\n\n' ...
            'Visualizing each object interacting with the one before or after it may help you recall\n' ...
            'their positions. Try using this strategy.\n\n' ...
            'When you are ready, press any key to start.'], 'center', 'center', [255, 255, 255]);
        Screen('Flip', win);
    
        % Wait for a key press
        KbWait;
        
        Screen('FillRect', win, [0, 0, 0]); % Fill the screen with black
        Screen('Flip', win);
        WaitSecs(2); % 2 second black screen

        % Load the images and create textures for old images
        textures = zeros(1, numImages);
        for i = 1:numImages
            img = imread(fullfile(imagePath, imageFiles(i).name));
            textures(i) = Screen('MakeTexture', win, img);
        end
    
        % Define the fixed presentation size
        fixedWidth = 307.2;
        fixedHeight = 307.2;
    
        % Determine the size of the screen
        [screenXpixels, screenYpixels] = Screen('WindowSize', win);
    
        % Create a destination rectangle of the fixed size and center it on the screen
        dstRect = CenterRectOnPointd([0 0 fixedWidth fixedHeight], screenXpixels / 2, screenYpixels / 2);
    
        % Create arrays to store the image filenames, markers, and likability responses
        encodingImageOrder = cell(1, 72);
        encodingMarkers = cell(1, 72); % Store markers for each stimulus
        likabilityResponses = zeros(1, 72);
    
        % Start the timer for the encoding task
        tic;
    
        % Present each image in the encoding task
        for i = 1:72
            % Draw the stimulus and flip the window
            Screen('DrawTexture', win, textures(fixedOrder(i)), [], dstRect);
            Screen('Flip', win);
    
            % Store the filename in order
            encodingImageOrder{i} = imageFiles(fixedOrder(i)).name;
    
            % **Send unique marker for each encoding image** (Marker 10+i)
            marker = 10 + i; % Unique marker for each image
            encodingMarkers{i} = marker; % Save the marker value
            if eegConnected
                io64(ioObj, port2Address, marker); % Send marker
                WaitSecs(0.001); % Short delay to ensure trigger is registered
                io64(ioObj, port2Address, 0); % Reset the marker
            end
    
            % Wait for the presentation time
            WaitSecs(2);
    
            % Clear the screen
            Screen('FillRect', win, [0, 0, 0]); % Fill the screen with black
            Screen('Flip', win);
            WaitSecs(1);

            % **Send marker for the likability question screen** (Marker 10)
            if eegConnected
                io64(ioObj, port2Address, 10); % Marker for likability question
                WaitSecs(0.001);
                io64(ioObj, port2Address, 0);
            end
          

            % Display the likability question
            Screen('TextSize', win, 40);
            % Text with line breaks for options, setting the maximum width for consistent left alignment
            likabilityQuestion = ['How likable is this item?\n\n' ...
                '1 = Not at all likable\n' ...
                '2 = Neutral\n' ...
                '3 = Likable\n'];
            % Set a fixed starting x position for left-aligned options within a centered text block
            textXPosition = screenXpixels * 0.4; % This sets an x position to align left (adjust as needed)
            
            % Draw the text block with left-aligned options but centered overall
            DrawFormattedText(win, likabilityQuestion, textXPosition, 'center', [255, 255, 255]);            
            Screen('Flip', win);

            % Wait for a likability response
            while 1
                [keyIsDown, ~, keyCode] = KbCheck;
                if keyIsDown
                    if keyCode(KbName('1!')) % Likability 1
                        likabilityResponses(i) = 1;
                        if eegConnected
                            io64(ioObj, port2Address, 1); % Send marker for likability 1
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    elseif keyCode(KbName('2@')) % Likability 2
                        likabilityResponses(i) = 2;
                        if eegConnected
                            io64(ioObj, port2Address, 2); % Send marker for likability 2
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    elseif keyCode(KbName('3#')) % Likability 3
                        likabilityResponses(i) = 3;
                        if eegConnected
                            io64(ioObj, port2Address, 3); % Send marker for likability 3
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    elseif keyCode(KbName('4$')) % Likability 4
                        likabilityResponses(i) = 4;
                        if eegConnected
                            io64(ioObj, port2Address, 4); % Send marker for likability 4
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    end
                end
            end
    
            % Clear the screen
            Screen('FillRect', win, [0, 0, 0]); % Fill the screen with black
            Screen('Flip', win);
    
            % Wait for the inter-stimulus interval
            WaitSecs(fixedISI(i));
        end
    
        % Display the ending message for the encoding task
        Screen('TextSize', win, 40);
        DrawFormattedText(win, 'Thank you for participating! This task is now finished. You can relax.', 'center', 'center', [255, 255, 255]);
        Screen('Flip', win);
        WaitSecs(5);
    
        % Stop the timer for the encoding task
        totalTime = toc;
    
        % Create a table to store the order, filename, markers, and likability responses
        encodingImageOrderTable = table((1:72)', fixedOrder', encodingImageOrder', encodingMarkers', likabilityResponses', ...
            'VariableNames', {'PresentationOrder', 'ImageOrder', 'Filename', 'Marker', 'LikabilityResponse'});


    elseif strcmp(taskType, 'r')
        % --- Recognition Task ---
        % Display the introduction message for the recognition task
        Screen('TextSize', win, 40);
        DrawFormattedText(win, ['You will now see a series of images. Some of them you have seen before and some are new.\n' ...
            '\n' ...
            'Press "y" if you have seen the image before and "n" if it is new.\n' ...
            '\n' ...
            'When you are ready, press any key to start.'], 'center', 'center', [255, 255, 255]);
        Screen('Flip', win);

        % Wait for a key press
        KbWait;
        
        Screen('FillRect', win, [0, 0, 0]); % Fill the screen with black
        Screen('Flip', win);
        WaitSecs(2); % 1 second black screen

        % Load the images and create textures for old images
        textures = zeros(1, numImages);
        for i = 1:numImages
            img = imread(fullfile(imagePath, imageFiles(i).name));
            textures(i) = Screen('MakeTexture', win, img);
        end

        % Load the novel images and create textures
        novelTextures = zeros(1, numNovelImages);
        for i = 1:numNovelImages
            img = imread(fullfile(novelImagePath, novelImageFiles(i).name));
            novelTextures(i) = Screen('MakeTexture', win, img);
        end

        % Combine old and novel images and randomize their order
        combinedTextures = [textures(fixedOrder(1:60)), novelTextures(1:60)]; % Ensure only 60 old and 60 novel images are used
        combinedOrder = randperm(120); % Randomize the order of both old and new images combined

        % Create arrays to store the image filenames, markers, and response data
        recognitionImageOrder = cell(1, 120);
        stimulusMarkers = zeros(1, 120);  % Stimulus markers
        responseMarkers = zeros(1, 120);  % Response markers
        correctResponsesColumn = zeros(1, 120); % Correct response column

        % Initialize response data
        responseKeys = zeros(1, 120);
        responseTimes = zeros(1, 120);

        % Define the fixed presentation size
        fixedWidth = 307.2;
        fixedHeight = 307.2;

        % Determine the size of the screen
        [screenXpixels, screenYpixels] = Screen('WindowSize', win);

        % Create a destination rectangle of the fixed size and center it on the screen
        dstRect = CenterRectOnPointd([0 0 fixedWidth fixedHeight], screenXpixels / 2, screenYpixels / 2);

        % Start the timer for the recognition task
        tic;

        % Present each image in the recognition task
        for i = 1:120
            % Determine if the image is old or novel
            textureIndex = combinedOrder(i);
            if textureIndex <= 60
                % Old image
                currentTexture = combinedTextures(textureIndex);
                recognitionImageOrder{i} = imageFiles(fixedOrder(textureIndex)).name;
                % **Send marker for old images** (Marker 2)
                stimulusMarkers(i) = 2;
                correctAnswer = 'y';
            else
                % Novel image
                currentTexture = combinedTextures(textureIndex);
                recognitionImageOrder{i} = novelImageFiles(textureIndex - 60).name;
                % **Send marker for novel images** (Marker 3)
                stimulusMarkers(i) = 3;
                correctAnswer = 'n';
            end

            % Draw the stimulus and flip the window
            Screen('DrawTexture', win, currentTexture, [], dstRect);
            Screen('Flip', win);

            % Send the stimulus marker
            if eegConnected
                io64(ioObj, port2Address, stimulusMarkers(i));
                WaitSecs(0.001); % Short delay to ensure trigger is registered
                io64(ioObj, port2Address, 0); % Reset the marker
            end

            % Wait for the presentation time
            WaitSecs(1.0);

            % Clear the screen
            Screen('FillRect', win, [0, 0, 0]);
            Screen('Flip', win);

            % Fixed delay before the question screen
            WaitSecs(1); % 1 second delay

            % **Send marker for the question screen** (Marker 4)
            if eegConnected
                io64(ioObj, port2Address, 4);
                WaitSecs(0.001);
                io64(ioObj, port2Address, 0); % Reset marker after showing question
            end

            % Display the question screen
            Screen('TextSize', win, 40);
            DrawFormattedText(win, 'Have you seen this image before?\n\nPress "y" for Yes and "n" for No.', 'center', 'center', [255, 255, 255]);
            Screen('Flip', win);

            % Start the response timer
            startTime = GetSecs;

            % Wait for a response
            while 1
                [keyIsDown, responseTime, keyCode] = KbCheck;
                if keyIsDown
                    if keyCode(KbName('y')) % **Send marker for "Yes" response** (Marker 20)
                        responseMarkers(i) = 20;  % Response marker for Yes
                        if eegConnected
                            io64(ioObj, port2Address, 20); % Send marker
                            WaitSecs(0.001); % Short delay
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        responseKeys(i) = KbName('y');
                        responseTimes(i) = responseTime - startTime;
                        participantResponse = 'y';
                        break;
                    elseif keyCode(KbName('n')) % **Send marker for "No" response** (Marker 21)
                        responseMarkers(i) = 21;  % Response marker for No
                        if eegConnected
                            io64(ioObj, port2Address, 21); % Send marker
                            WaitSecs(0.001); % Short delay
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        responseKeys(i) = KbName('n');
                        responseTimes(i) = responseTime - startTime;
                        participantResponse = 'n';
                        break;
                    end
                end
            end

            % Determine if the response is correct
            if strcmp(participantResponse, correctAnswer)
                correctResponsesColumn(i) = 1;
            else
                correctResponsesColumn(i) = 0;
            end

            % Clear the screen
            Screen('FillRect', win, [0, 0, 0]); % Fill the screen with black
            Screen('Flip', win);

            % Wait for the inter-stimulus interval
            WaitSecs(fixedISI(mod(i-1, length(fixedISI))+1));
        end

        % Calculate the accuracy
        accuracy = sum(correctResponsesColumn) / 120 * 100;

        % Calculate d-prime
        hits = sum(correctResponsesColumn(stimulusMarkers == 2)); % Hits: Correctly identified old images
        misses = sum(stimulusMarkers == 2) - hits; % Misses: Old images not identified
        falseAlarms = sum(correctResponsesColumn(stimulusMarkers == 3) == 0); % False alarms: New images identified as old
        correctRejections = sum(stimulusMarkers == 3) - falseAlarms; % Correct rejections: Correctly identified new images

        % Apply the log-linear adjustment
        adjustedHits = hits + 0.5;
        adjustedMisses = misses + 0.5;
        adjustedFalseAlarms = falseAlarms + 0.5;
        adjustedCorrectRejections = correctRejections + 0.5;

        % Calculate the adjusted hit rate and false alarm rate
        adjustedHitRate = adjustedHits / (hits + misses + 1);
        adjustedFalseAlarmRate = adjustedFalseAlarms / (falseAlarms + correctRejections + 1);

        % Calculate d-prime using the adjusted rates
        dPrime = norminv(adjustedHitRate) - norminv(adjustedFalseAlarmRate);

        % Calculate mean reaction times
        meanReactionTime = mean(responseTimes);  % Mean reaction time overall
        meanCorrectReactionTime = mean(responseTimes(correctResponsesColumn == 1)); % Mean reaction time for correct responses
        meanIncorrectReactionTime = mean(responseTimes(correctResponsesColumn == 0)); % Mean reaction time for incorrect responses

        % Create a table to store the order, filename, markers, and correctness
        recognitionImageOrderTable = table((1:120)', combinedOrder', recognitionImageOrder', stimulusMarkers', responseMarkers', correctResponsesColumn', responseTimes', ...
            'VariableNames', {'PresentationOrder', 'TextureIndex', 'Filename', 'StimulusMarker', 'ResponseMarker', 'CorrectResponse', 'ResponseTime'});

        % Display the ending message for the recognition task
        Screen('TextSize', win, 40);
        DrawFormattedText(win, 'Thank you for participating! This task is now finished. You can relax.', 'center', 'center', [255, 255, 255]);
        Screen('Flip', win);
        WaitSecs(5);

        % Stop the timer for the recognition task
        totalTime = toc;

    elseif strcmp(taskType, 't') 
        % --- Temporal Order Task ---
        % Display the introduction message for the temporal order task
        Screen('TextSize', win, 40);
        DrawFormattedText(win, ['In this task, you will see pairs of images that you viewed earlier.\n' ...
            'For each pair, please indicate which image you saw first during the initial viewing.\n\n' ...
            'Press the LEFT arrow key if the left image came first.\n' ...
            'Press the RIGHT arrow key if the right image came first.\n\n' ...
            'When you are ready, press any key to start.'], 'center', 'center', [255, 255, 255], [], [], [], 1.5);
        Screen('Flip', win);
    
        % Wait for a key press
        KbWait;
       
        Screen('FillRect', win, [0, 0, 0]); % Fill the screen with black
        Screen('Flip', win);
        WaitSecs(2); % 2 second black screen

        % Load the images and create textures for the images
        textures = zeros(1, numImages);
        for i = 1:numImages
            img = imread(fullfile(imagePath, imageFiles(i).name));
            textures(i) = Screen('MakeTexture', win, img);
        end
    
        % Ensure that the textures were created successfully
        if any(textures == 0)
            error('One or more textures failed to load properly.');
        end
    
        % Define the fixed presentation size
        fixedWidth = 307.2;
        fixedHeight = 307.2;
        
        % Determine the size of the screen
        [screenXpixels, screenYpixels] = Screen('WindowSize', win);
        
        % Create rectangles for left and right images
        leftRect = CenterRectOnPointd([0 0 fixedWidth fixedHeight], screenXpixels * 0.3, screenYpixels / 2);
        rightRect = CenterRectOnPointd([0 0 fixedWidth fixedHeight], screenXpixels * 0.7, screenYpixels / 2);
    
        % Load the predetermined pairs from the Excel file
        [~, ~, rawPairs] = xlsread('predetermined_pairs.xlsx');
        rawPairs = rawPairs(2:end, :); % Skip the header row
        
        % Define the number of pairs to use
        maxPairs = size(rawPairs, 1);
        itemPairs = cell(maxPairs, 2); % Pre-allocate for maxPairs pairs
        fileNames = cell(maxPairs, 2); % File names for each pair
        
        % Assign the predetermined pairs to the itemPairs array
        for i = 1:maxPairs
            idx1 = rawPairs{i, 1};
            idx2 = rawPairs{i, 2};
            
            % Assign the pair to the itemPairs array
            itemPairs{i, 1} = fixedOrder(idx1);
            itemPairs{i, 2} = fixedOrder(idx2);
            fileNames{i, 1} = imageFiles(fixedOrder(idx1)).name;
            fileNames{i, 2} = imageFiles(fixedOrder(idx2)).name;
        
        end
        
        % Randomize the presentation of the created pairs (pseudorandomization)
        rng('shuffle'); % Set a random seed for reproducibility
                
        % Start the timer for the temporal order task
        tic;
        
        % Initialize response data
        responseKeys = zeros(1, maxPairs);
        responseTimes = zeros(1, maxPairs);
        accuracyArray = zeros(1, maxPairs);
        confidenceRatings = zeros(1, maxPairs); % Confidence ratings
        stimulusMarkers = zeros(1, maxPairs);  % Stimulus markers
        responseMarkers = zeros(1, maxPairs);  % Response markers
        
        % Initialize a new array to store the randomized correct responses
        randomizedCorrectResponses = zeros(1, maxPairs);
        
        % Set up variables to track counts and enforce conditions
        maxConsecutiveSameSide = 3; % Maximum number of consecutive same-side presentations
        consecutiveLeftCounter = 0;
        consecutiveRightCounter = 0;
        leftCount = 0; % Tracks how often ImageIdx1 is on the left
        rightCount = 0; % Tracks how often ImageIdx2 is on the left
        targetCount = maxPairs / 2; % Target count for each side for equal distribution
        
        % Initialize new arrays to store the left and right image details 
        leftImageIdx = zeros(1, maxPairs);
        rightImageIdx = zeros(1, maxPairs);
        leftFileNames = cell(maxPairs, 1);
        rightFileNames = cell(maxPairs, 1);
        
        % Present the pairs
        for i = 1:maxPairs
            % Get the indices of the images in the pair
            idx1 = itemPairs{i, 1};
            idx2 = itemPairs{i, 2};
        
            % Decide which image goes on the left and which goes on the right
            % while respecting both consecutive and equal distribution conditions
            if (consecutiveLeftCounter >= maxConsecutiveSameSide || leftCount >= targetCount) && ...
               (consecutiveRightCounter < maxConsecutiveSameSide && rightCount < targetCount)
                % Place ImageIdx2 on the left
                leftIdx = idx2;
                rightIdx = idx1;
                randomizedCorrectResponses(i) = 2; % Since ImageIdx1 is now on the right
        
                % Update counters
                consecutiveLeftCounter = 0;
                consecutiveRightCounter = consecutiveRightCounter + 1;
                rightCount = rightCount + 1;
            elseif (consecutiveRightCounter >= maxConsecutiveSameSide || rightCount >= targetCount) && ...
                   (consecutiveLeftCounter < maxConsecutiveSameSide && leftCount < targetCount)
                % Place ImageIdx1 on the left
                leftIdx = idx1;
                rightIdx = idx2;
                randomizedCorrectResponses(i) = 1; % Since ImageIdx1 is on the left
        
                % Update counters
                consecutiveRightCounter = 0;
                consecutiveLeftCounter = consecutiveLeftCounter + 1;
                leftCount = leftCount + 1;
            else
                % Randomly decide which image goes on the left, but make sure counts are balanced
                if rand() > 0.5 && leftCount < targetCount
                    leftIdx = idx1;
                    rightIdx = idx2;
                    randomizedCorrectResponses(i) = 1; % Since ImageIdx1 is on the left
                    consecutiveLeftCounter = consecutiveLeftCounter + 1;
                    consecutiveRightCounter = 0;
                    leftCount = leftCount + 1;
                else
                    leftIdx = idx2;
                    rightIdx = idx1;
                    randomizedCorrectResponses(i) = 2; % Since ImageIdx1 is now on the right
                    consecutiveRightCounter = consecutiveRightCounter + 1;
                    consecutiveLeftCounter = 0;
                    rightCount = rightCount + 1;
                end
            end
        
            % Store the actual presentation sides
            leftImageIdx(i) = leftIdx;
            rightImageIdx(i) = rightIdx;
            leftFileNames{i} = imageFiles(leftIdx).name;
            rightFileNames{i} = imageFiles(rightIdx).name;
        
            % Draw the two images, ensuring proper texture usage
            Screen('DrawTexture', win, textures(leftIdx), [], leftRect);
            Screen('DrawTexture', win, textures(rightIdx), [], rightRect);
            Screen('Flip', win);
        
            % **Send marker for temporal order stimulus** (Marker 6)
            stimulusMarkers(i) = 6;
            if eegConnected
                io64(ioObj, port2Address, 6);
                WaitSecs(0.001);
                io64(ioObj, port2Address, 0);
            end
        
            % Wait for the presentation time
            WaitSecs(2);
        
            % Clear the screen
            Screen('FillRect', win, [0, 0, 0]);
            Screen('Flip', win);
            WaitSecs(1); % 1 second delay
        
            % **Send marker for the question screen** (Marker 7)
            if eegConnected
                io64(ioObj, port2Address, 7); % Marker for "Which image came first?" question
                WaitSecs(0.001);
                io64(ioObj, port2Address, 0);
            end
        
            % Display the question screen
            Screen('TextSize', win, 40);
            DrawFormattedText(win, 'Which image came first?\n\nPress LEFT or RIGHT arrow key.', 'center', 'center', [255, 255, 255]);
            Screen('Flip', win);
        
            % Start the response timer
            startTime = GetSecs;
        
            % Wait for a response
            while 1
                [keyIsDown, responseTime, keyCode] = KbCheck;
                if keyIsDown
                    if keyCode(KbName('LeftArrow')) % Left response
                        responseMarkers(i) = 31;  % Response marker for Left
                        if eegConnected
                            io64(ioObj, port2Address, 31); % Send marker
                            WaitSecs(0.001); % Short delay
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        responseKeys(i) = 1; % 1 for Left
                        responseTimes(i) = responseTime - startTime;
                        break;
                    elseif keyCode(KbName('RightArrow')) % Right response
                        responseMarkers(i) = 32;  % Response marker for Right
                        if eegConnected
                            io64(ioObj, port2Address, 32); % Send marker
                            WaitSecs(0.001); % Short delay
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        responseKeys(i) = 2; % 2 for Right
                        responseTimes(i) = responseTime - startTime;
                        break;
                    end
                end
            end
        
            % Determine if the response is correct
            if responseKeys(i) == randomizedCorrectResponses(i)
                accuracyArray(i) = 1; % Correct
            else
                accuracyArray(i) = 0; % Incorrect
            end
        
            % Clear the screen
            Screen('FillRect', win, [0, 0, 0]);
            Screen('Flip', win);
            WaitSecs(1); % 1 second delay
        
            % **Send marker for the confidence screen** (Marker 8)
            if eegConnected
                io64(ioObj, port2Address, 8); % Marker for confidence rating screen
                WaitSecs(0.001);
                io64(ioObj, port2Address, 0);
            end

        
            % Confidence rating screen
            Screen('TextSize', win, 40);
            % Text with options, centered but aligned at the same left edge
            confidenceText = ['How confident are you in your response?\n\n' ...
                              '1 = Sure\n' ...
                              '2 = Unsure\n' ...
                              '3 = Guessing\n'];
            
            % Set a fixed starting x position for left-aligned options within a centered text block
            textXPosition = screenXpixels * 0.35; % Adjust this value as needed
            
            % Draw the text block with left-aligned options but centered overall
            DrawFormattedText(win, confidenceText, textXPosition, 'center', [255, 255, 255]);      
        
            Screen('Flip', win);
        
            % Wait for a confidence rating
            while 1
                [keyIsDown, ~, keyCode] = KbCheck;
                if keyIsDown
                    if keyCode(KbName('1!')) % Confidence 1
                        confidenceRatings(i) = 1;
                        if eegConnected
                            io64(ioObj, port2Address, 1); % Send marker for confidence 1
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    elseif keyCode(KbName('2@')) % Confidence 2
                        confidenceRatings(i) = 2;
                        if eegConnected
                            io64(ioObj, port2Address, 2); % Send marker for confidence 2
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    elseif keyCode(KbName('3#')) % Confidence 3
                        confidenceRatings(i) = 3;
                        if eegConnected
                            io64(ioObj, port2Address, 3); % Send marker for confidence 3
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    elseif keyCode(KbName('4$')) % Confidence 4
                        confidenceRatings(i) = 4;
                        if eegConnected
                            io64(ioObj, port2Address, 4); % Send marker for confidence 4
                            WaitSecs(0.001);
                            io64(ioObj, port2Address, 0); % Reset marker after response
                        end
                        break;
                    end
                end
            end
        
            % Clear the screen and wait for the inter-stimulus interval
            Screen('FillRect', win, [0, 0, 0]);
            Screen('Flip', win);
            WaitSecs(fixedISI(mod(i-1, length(fixedISI))+1)); % Use ISI values cyclically if necessary
        end
    
        % Behavioral data calculation (accuracy, reaction time, d-prime, etc.)
        hits = sum(responseKeys == randomizedCorrectResponses); % Number of correct responses
        falseAlarms = sum(responseKeys ~= randomizedCorrectResponses); % Number of incorrect responses
        
        % Adjusted counts to prevent zero rates
        adjustedHits = hits + 0.5;
        adjustedFalseAlarms = falseAlarms + 0.5;
        
        % Calculate adjusted rates
        adjustedHitRate = adjustedHits / (hits + falseAlarms + 1);
        adjustedFalseAlarmRate = adjustedFalseAlarms / (hits + falseAlarms + 1);
        
        
        % Calculate accuracy as a percentage
        accuracy = sum(accuracyArray) / maxPairs * 100;
        
        % Calculate reaction times
        meanReactionTime = mean(responseTimes);
        meanCorrectReactionTime = mean(responseTimes(accuracyArray == 1));
        meanIncorrectReactionTime = mean(responseTimes(accuracyArray == 0));

        % Save the data
        % Create the temporalOrderTable with additional columns for presentation details
        temporalOrderTable = table((1:maxPairs)', itemPairs(:,1), itemPairs(:,2), fileNames(:,1), fileNames(:,2), randomizedCorrectResponses', responseKeys', accuracyArray', responseTimes', confidenceRatings', ...
            leftImageIdx', rightImageIdx', leftFileNames, rightFileNames, ...
            'VariableNames', {'Trial', 'ImageIdx1', 'ImageIdx2', 'FileName1', 'FileName2', 'CorrectResponse', 'ParticipantResponse', 'Accuracy', 'ResponseTime', 'ConfidenceRating', ...
            'LeftImageIdx', 'RightImageIdx', 'LeftFileName', 'RightFileName'});


        % Display the ending message for the temporal order task
        Screen('TextSize', win, 40);
        DrawFormattedText(win, 'Thank you for participating! This task is now finished. You can relax.', 'center', 'center', [255, 255, 255]);
        Screen('Flip', win);
        WaitSecs(5);
    
        % Stop the timer for the temporal order task
        totalTime = toc;
    
    else
        error('Invalid task type. Please enter "e" for encoding, "r" for recognition, or "t" for temporal order.');
    end
    
    % Close the window
    Screen('CloseAll');
    sca;

catch ME
    % Display the error message
    Screen('CloseAll');
    disp('Error:');
    disp(ME.message);
    for k = 1:length(ME.stack)
        fprintf('In %s at line %d\n', ME.stack(k).file, ME.stack(k).line);
    end
end

% Save the workspace with the responses
if strcmp(taskType, 'e')
    save(saveFilename, 'fixedOrder', 'fixedISI', 'totalTime', 'imageFiles', 'imagePath', 'encodingImageOrderTable');
elseif strcmp(taskType, 'r')
    save(saveFilename, 'combinedOrder', 'combinedTextures', 'responseKeys', 'responseTimes', 'correctResponsesColumn', 'totalTime', 'accuracy', ...
        'hits', 'misses', 'falseAlarms', 'correctRejections', 'dPrime', 'meanReactionTime', 'meanCorrectReactionTime', 'meanIncorrectReactionTime', ...
        'adjustedHits', 'adjustedMisses', 'adjustedFalseAlarms', 'adjustedCorrectRejections', 'adjustedHitRate', 'adjustedFalseAlarmRate', ...
        'fixedISI', 'fixedOrder', 'imageFiles', 'imagePath', 'novelImageFiles', 'novelImagePath', 'novelTextures', 'recognitionImageOrderTable');
elseif strcmp(taskType, 't')
    save(saveFilename, 'itemPairs', 'responseKeys', 'responseTimes', 'accuracyArray', 'totalTime', 'accuracy', 'dPrime', ...
        'hits', 'falseAlarms', 'meanReactionTime', 'meanCorrectReactionTime', 'meanIncorrectReactionTime', ...
        'adjustedHits', 'adjustedFalseAlarms', 'adjustedHitRate', 'adjustedFalseAlarmRate', ...
        'fixedISI', 'fixedOrder', 'imageFiles', 'imagePath', 'temporalOrderTable');
end
disp(['Workspace saved to ' saveFilename]);
