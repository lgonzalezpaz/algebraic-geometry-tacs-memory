
library(readxl)
library(tidyr)
library(lme4)
library(lmerTest)
library(emmeans)
library(performance)

dat <- read_excel("...")

dat$session <- factor(dat$session, levels = c("inphase","antiphase","sham"))

# Define proportions
dat$pHigh_pre  <- dat$pctHigh_pre  / 100
dat$pHigh_post <- dat$pctHigh_post / 100

# Fit ANCOVA LMM
m_ancova <- lmer(pHigh_post ~ pHigh_pre + session * group + (1 | subject_id), data = dat)

summary(m_ancova)
anova(m_ancova)
effectsize::eta_squared(m_ancova, partial = TRUE)


# 3) Recompute emmeans (adjusted post means)

emm_post <- emmeans(m_ancova, ~ session | group, cov.reduce = mean)
emm_df <- as.data.frame(summary(emm_post, type = "response"))

# Pick the correct estimate column (emmean for LMMs)
est_col <- if ("estimate" %in% names(emm_df)) "estimate" else "emmean"
emm_df$estimate_pct <- emm_df[[est_col]] * 100
emm_df$lower_pct    <- emm_df$lower.CL * 100
emm_df$upper_pct    <- emm_df$upper.CL * 100

# 4) Print the adjusted post means table clearly
emm_df[order(emm_df$group, emm_df$session), 
       c("group","session","estimate_pct","lower_pct","upper_pct")]

# 5) contrasts:
# pairwise contrasts within each group
contrast(emm_post, method = "pairwise", by = "group", adjust = "fdr")

pairs_g <- contrast(
  emm_post,
  method = "revpairwise",
  by = "session",
  adjust = "none"
)

pairs_g_df <- as.data.frame(pairs_g)

pairs_g_df$p_FDR <- p.adjust(
  pairs_g_df$p.value,
  method = "BH"
)

pairs_g_df


# Set session order
dat$session <- factor(dat$session, levels = c("inphase", "antiphase", "sham"))
emm_df$session <- factor(emm_df$session, levels = c("inphase", "antiphase", "sham"))

# Plot
library(ggplot2)

# Convert group to factor everywhere
dat$group    <- as.factor(dat$group)
emm_df$group <- as.factor(emm_df$group)

# Back-transform post proportions to % for raw dots
dat$pHigh_post_pct <- dat$pHigh_post * 100

# Pick colors for groups
group_colors <- c("1" = "#ff7f0e",   # Group 1 (ITF???1)
                  "2" = "#1f77b4")   # Group 2 (ITF+1)

ggplot() +
  # Individual subject dots (observed post %High)
  geom_jitter(data = dat, aes(x = session, y = pHigh_post_pct, colour = group),
              width = 0.15, alpha = 0.5, size = 2, shape = 16) +
  # Adjusted post means with CIs
  geom_point(data = emm_df, aes(x = session, y = estimate_pct, colour = group, group = group),
             position = position_dodge(width = 0.4), size = 3) +
  geom_errorbar(data = emm_df,
                aes(x = session, y = estimate_pct,
                    ymin = lower_pct, ymax = upper_pct,
                    colour = group, group = group),
                width = 0.15,
                position = position_dodge(width = 0.4)) +
  geom_line(data = emm_df,
            aes(x = session, y = estimate_pct, colour = group, group = group),
            position = position_dodge(width = 0.4)) +
  scale_colour_manual(values = group_colors,
                      labels = c("ITF-1", "ITF+1")) +
  labs(y = "%High confidence (adjusted post means)",
       x = "Session",
       colour = "Group") +
  theme_minimal(base_size = 14)