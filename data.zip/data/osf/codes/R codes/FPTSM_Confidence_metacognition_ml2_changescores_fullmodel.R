
library(readxl)
library(lme4); 
library(lmerTest)
library(emmeans); 
library(performance)
library(ggplot2)

dat <- read_excel("...")

# Factors
dat$session <- factor(dat$session, levels = c("inphase","antiphase","sham"))
dat$group   <- as.factor(dat$group)

# Keep rows with both Sep measures
dat_sep <- subset(dat, !is.na(Sep_pre) & !is.na(Sep_post))

# --- Model
m_sep <- lmer(Sep_post ~ Sep_pre + session * group + (1 | subject_id), data = dat_sep)
summary(m_sep)
anova(m_sep)          # Type III table
#check_model(m_sep)    # quick diagnostics

effectsize::eta_squared(m_sep, partial = TRUE)


# --- Adjusted post means
emm_sep <- emmeans(m_sep, ~ session | group, cov.reduce = mean)
emm_sep_df <- as.data.frame(summary(emm_sep, type = "response"))
est_col <- if ("estimate" %in% names(emm_sep_df)) "estimate" else "emmean"
names(emm_sep_df)[names(emm_sep_df) == est_col] <- "estimate_val"

# Tidy table
emm_sep_df[order(emm_sep_df$group, emm_sep_df$session),
           c("group","session","estimate_val","lower.CL","upper.CL")]

# --- Contrasts
# (1) Within-group pairwise (sham???inphase, sham???antiphase, inphase???antiphase)
contrast(emm_sep, method = "pairwise", by = "group", adjust = "fdr")

# (2) Between-group comparisons within each session
pairs_g_sep <- contrast(
  emm_sep,
  method = "revpairwise",
  by = "session",
  adjust = "none"
)

pairs_g_sep_df <- as.data.frame(pairs_g_sep)

# Apply BH-FDR across the three session-specific group comparisons
pairs_g_sep_df$p_FDR <- p.adjust(
  pairs_g_sep_df$p.value,
  method = "BH"
)

pairs_g_sep_df


# Set session order
dat_sep$session <- factor(dat_sep$session, levels = c("inphase", "antiphase", "sham"))
emm_sep_df$session <- factor(emm_sep_df$session, levels = c("inphase", "antiphase", "sham"))


# --- Plot: individual Sep_post + adjusted means
emm_sep_df$group <- as.factor(emm_sep_df$group)
group_colors <- c("1" = "#93C4DE", "2" = "#084A92")

ggplot() +
  geom_jitter(data = dat_sep,
              aes(x = session, y = Sep_post, colour = group),
              width = 0.15, alpha = 0.5, size = 2) +
  geom_point(data = emm_sep_df,
             aes(x = session, y = estimate_val, colour = group, group = group),
             position = position_dodge(width = 0.4), size = 3) +
  geom_errorbar(data = emm_sep_df,
                aes(x = session, y = estimate_val, ymin = lower.CL, ymax = upper.CL,
                    colour = group, group = group),
                width = 0.15, position = position_dodge(width = 0.4)) +
  geom_line(data = emm_sep_df,
            aes(x = session, y = estimate_val, colour = group, group = group),
            position = position_dodge(width = 0.4)) +
  scale_colour_manual(values = group_colors,
                      labels = c("ITF-1", "ITF+1")) +
  labs(y = "Metacognitive separation (adjusted post means)",
       x = "Session", colour = "Group") +
  theme_minimal(base_size = 14)