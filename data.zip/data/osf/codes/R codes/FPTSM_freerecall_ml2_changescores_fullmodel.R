install.packages("readxl")      
install.packages("emmeans")     
install.packages("sjstats")     
install.packages("lme4")       
install.packages("lmerTest")   
install.packages("MuMIn")       
install.packages("Matrix", dependencies = TRUE)
install.packages("pbkrtest")


library(tidyr)
library(dplyr)
library(lme4)
library(readxl)
library(emmeans)
library(sjstats)
library(lmerTest)
library(MuMIn)
library(performance) # normality checks


df <- read_excel("...")



## --- reshape keeping group ---
df_long <- df %>%
  pivot_longer(
    cols = -c(subj, group),          # keep group
    names_to = "session_time",
    values_to = "recall"
  ) %>%
  mutate(
    session = substr(session_time, 1, 1),
    time    = ifelse(grepl("Pre", session_time), "Pre", "Post")
  ) %>%
  select(subj, group, session, time, recall)

df_wide <- df_long %>%
  pivot_wider(names_from = time, values_from = recall) %>%
  mutate(change = Post - Pre)

## factors (order session as you had; group is between-subject)
df_wide$session <- factor(df_wide$session, levels = c("3","1","2"))
df_wide$group   <- factor(df_wide$group)   # 1/2 -> factor

## --- LMM with group and interaction ---
model_change <- lmer(change ~ session * group + (1 | subj),
                     REML = FALSE, data = df_wide)

summary(model_change)
anova(model_change) # F-tests incl. session:group (from lmerTest)

## Effect sizes & R2
effectsize::eta_squared(model_change, partial = TRUE)
r.squaredGLMM(model_change)

## --- Diagnostics (unchanged) ---
# diag_plots <- check_model(model_change)
# norm_check  <- check_normality(model_change)
# shapiro_res <- shapiro.test(residuals(model_change))
# qqnorm(resid(model_change)); qqline(resid(model_change))

## --- Estimated marginal means & interaction probes ---
# EMMs for each session ?? group cell
emm <- emmeans(model_change, ~ session * group)

# Simple effects: sessions within each group
pairs(emmeans(model_change, ~ session | group), adjust = "FDR")

# Simple effects: groups within each session
pairs_g <- pairs(
  emmeans(model_change, ~ group | session),
  adjust = "none"
)

pairs_g_df <- as.data.frame(pairs_g)

# BH-FDR correction across the three session-specific group comparisons
pairs_g_df$p_FDR <- p.adjust(
  pairs_g_df$p.value,
  method = "BH"
)

print(pairs_g_df)

##for the effect size:

library(effectsize)   # for eta_squared
library(emmeans)      # for posthocs + eff_size
library(dplyr)

## --- (A) Omnibus tests + partial eta squared ---
anova_tab <- anova(model_change)
eta_tab   <- eta_squared(model_change, partial = TRUE, ci = 0.95)


## --- (B) Post-hoc comparisons + Cohen's d ---
# 1. Pairwise comparisons across all session ?? group cells
posthoc_res <- pairs(
  emmeans(model_change, ~ session * group),
  adjust = "fdr",             
  infer  = c(TRUE, TRUE)       # request CI + p-values
)
posthoc_df <- as.data.frame(posthoc_res)

# 2. Build emmGrid treating session ?? group as single factor
marginal <- emmeans(model_change, specs = ~ session:group)

# 3. Compute Cohen???s d for all pairwise comparisons
ES <- eff_size(
  marginal,
  sigma    = sigma(model_change),      # residual SD from model
  edf      = df.residual(model_change),# residual df
  contrast = "pairwise"
)

# 4. Summarize and save as data frame
ES_summary <- summary(ES, infer = c(TRUE, TRUE))
ES_df <- as.data.frame(ES_summary)

# 5. Merge posthoc + effect sizes into one final table
final_df <- left_join(posthoc_df, ES_df, by = "contrast")



library(ggplot2)
library(dplyr)

# Factors
df_wide$session <- factor(df_wide$session, levels = c("3", "1", "2"))
df_wide$group   <- as.factor(df_wide$group)

df_wide$session_label <- factor(
  df_wide$session,
  levels = c("1", "2", "3"),
  labels = c("inphase", "antiphase", "sham")
)


# Summary values: raw mean ?? SE of change scores
summary_df <- df_wide %>%
  group_by(session_label, group) %>%
  summarise(
    mean_change = mean(change, na.rm = TRUE),
    se_change   = sd(change, na.rm = TRUE) / sqrt(sum(!is.na(change))),
    lower       = mean_change - se_change,
    upper       = mean_change + se_change,
    .groups = "drop"
  )

# Pick colors for groups
group_colors <- c(
  "1" = "#ff7f0e",   # Group 1: ITF-1
  "2" = "#1f77b4"    # Group 2: ITF+1
)

ggplot() +
  # Individual subject dots: observed recall change scores
  geom_jitter(
    data = df_wide,
    aes(x = session_label, y = change, colour = group),
    width = 0.15, alpha = 0.5, size = 2, shape = 16
  ) +
  
  # Raw means with SE bars
  geom_point(
    data = summary_df,
    aes(x = session_label, y = mean_change, colour = group, group = group),
    position = position_dodge(width = 0.4), size = 3
  ) +
  geom_errorbar(
    data = summary_df,
    aes(
      x = session_label, y = mean_change,
      ymin = lower, ymax = upper,
      colour = group, group = group
    ),
    width = 0.15,
    position = position_dodge(width = 0.4)
  ) +
  geom_line(
    data = summary_df,
    aes(x = session_label, y = mean_change, colour = group, group = group),
    position = position_dodge(width = 0.4)
  ) +
  
  scale_colour_manual(
    values = group_colors,
    labels = c("ITF-1", "ITF+1")
  ) +
  labs(
    title = "Recall",
    y = "Free recall change score",
    x = "Session",
    colour = "Group"
  ) +
  theme_minimal(base_size = 14)