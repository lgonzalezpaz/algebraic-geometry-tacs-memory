% ============================================================
%  Preprocessing with ICA and interactive component preview
%  
%  ------------------------------------------------------------
%  Set these ONCE:
clear; 
clc;

SUBJ = '048';              % e.g., '034'
TAG  = 'cpre';             % e.g., 'apre'/'apost'/'bpre'/'bpost'/'cpre'/'cpost'
TASK = 'vmt';              % e.g., 'vmt'/'vme'

% Paths
rawRoot   = '<RAW_DATA_ROOT>';   % BrainVision files live here under \SUBJ\EEG
procRoot  = '<PROJECT_ROOT>\...';

% Filenames
vhdrName  = sprintf('t%s%s_%s.vhdr', SUBJ, TAG, TASK);
setBefore = sprintf('t% s% s_% s_beforeICAremoval.set', SUBJ, TAG, TASK); setBefore = erase(setBefore,' '); % safe sprintf
setAfter  = sprintf('t% s% s_% s_afterICAremoval.set',  SUBJ, TAG, TASK);  setAfter  = erase(setAfter,' ');
% ============================================================

% EEGLAB
[ALLEEG, EEG, CURRENTSET, ALLCOM] = eeglab;

% Parameters (unchanged)
parameters = struct();
parameters.bandpass_filter = [0.5, 60];     % Hz
parameters.notch_filter    = [49, 51];      % Hz
parameters.ASR             = [0.8, 10];     % Channel corr, Burst criterion
parameters.EOG_channels    = {'LHEOG','LVEOG'};
parameters.chanloc_file    = '<EEGLAB_ROOT>\plugins\dipfit\standard_BEM\elec\standard_1005.elc';

% ---------- Load raw ----------
rawFolder = fullfile(rawRoot, SUBJ, 'EEG');
EEG = pop_loadbv(rawFolder, vhdrName);            % e.g., 't034cpre_vmt.vhdr'
[ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, 0);

% ---------- Resample ----------
EEG = pop_resample(EEG, 256);
[ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, CURRENTSET);

% ---------- Channel locations ----------
EEG = pop_chanedit(EEG, 'lookup', parameters.chanloc_file);

% ---------- Filtering (unchanged) ----------
EEG = pop_eegfiltnew(EEG, parameters.bandpass_filter(1), parameters.bandpass_filter(2), [], 0, [], 0);  % bandpass
EEG = pop_eegfiltnew(EEG, parameters.notch_filter(1), parameters.notch_filter(2), [], 1, [], 0);        % notch 50 Hz

% Keep a copy for interpolation reference
originalEEG = EEG;

% ---------- ASR: only non-EOG ----------
eogChanLabels = parameters.EOG_channels;
eogInds = find(ismember({EEG.chanlocs.labels}, eogChanLabels));
eegInds = setdiff(1:EEG.nbchan, eogInds);

EEG_eegOnly = pop_select(EEG, 'channel', eegInds);
EEG_eogOnly = pop_select(EEG, 'channel', eogChanLabels);

EEG_eegOnly = pop_clean_rawdata(EEG_eegOnly, ...
    'FlatlineCriterion', 'off', ...
    'ChannelCriterion', parameters.ASR(1), ...
    'LineNoiseCriterion', 'off', ...
    'Highpass', 'off', ...
    'BurstCriterion', parameters.ASR(2), ...
    'WindowCriterion', 'off', ...
    'BurstRejection', 'off', ...
    'Distance', 'Euclidian', ...
    'WindowCriterionTolerances', [-Inf 7]);

% Merge EOG back
EEG.data      = [EEG_eegOnly.data; EEG_eogOnly.data];
EEG.nbchan    = size(EEG.data,1);
EEG.chanlocs  = [EEG_eegOnly.chanlocs EEG_eogOnly.chanlocs];
EEG.urchanlocs= [EEG_eegOnly.urchanlocs EEG_eogOnly.urchanlocs];
EEG.chaninfo  = EEG_eegOnly.chaninfo;
EEG = eeg_checkset(EEG);

% ---------- Interpolate bad channels ----------
EEG = pop_interp(EEG, originalEEG.chanlocs, 'spherical');
EEG = eeg_checkset(EEG);
[ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, CURRENTSET);

% ---------- ICA  ----------
EEG = pop_runica(EEG, 'extended', 1, 'interupt', 'on');

% Save BEFORE-ICA-removal copy
EEG_beforeICAremoval = EEG;
[ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, CURRENTSET);
EEG = pop_saveset(EEG_beforeICAremoval, 'filename', setBefore, 'filepath', procRoot);

% ---------- INTERACTIVE ICA REMOVAL with PREVIEW ----------
done = false;
while ~done
    % 1) Open ICA component GUI and WAIT until you close it
    %    (mark bad comps there; close the window to continue)
    pop_selectcomps(EEG, 1:min(32, size(EEG.icaweights,1)));
    drawnow;

    icFigs = findall(0,'type','figure','-regexp','name','comp|IC|Component|scroll','-or','tag','EEGLAB'); 
    if ~isempty(icFigs)
        waitfor(icFigs(1));  % wait until you close that figure
    else
        pause(0.2);
    end

    % 2) Collect marked components (
    if isfield(EEG.reject,'gcompreject') && ~isempty(EEG.reject.gcompreject)
        rejComps = find(EEG.reject.gcompreject);
    else
        rejComps = [];
    end

    % 3) Build PREVIEW copy
    EEG_preview = pop_subcomp(EEG, rejComps, 0);
    
    set(0,'DefaultFigureWindowStyle','normal');
    
    % ---- BEFORE window  ----
    hbFig = figure('Name','EEG BEFORE ICA', 'NumberTitle','off', ...
                   'Position',[50 100 1400 450], 'Visible','on');
    try
        eegplot(EEG.data, 'srate', EEG.srate, 'winlength', 6, ...
                'dispchans', min(32, EEG.nbchan), ...
                'title', sprintf('BEFORE ICA — t%s%s_%s (close when done)', SUBJ, TAG, TASK), ...
                'winhandle', hbFig);
    catch
        % Fallback: call eegplot, then grab current figure
        eegplot(EEG.data, 'srate', EEG.srate, 'winlength', 6, ...
                'dispchans', min(32, EEG.nbchan), ...
                'title', sprintf('BEFORE ICA — t%s%s_%s (close when done)', SUBJ, TAG, TASK));
        hbFig = gcf;
        set(hbFig, 'Name','EEG BEFORE ICA');
    end
    set(hbFig,'WindowStyle','normal');  
    try, movegui(hbFig,'onscreen'); end
    
    % ---- AFTER window ----
    haFig = figure('Name','EEG AFTER ICA PREVIEW', 'NumberTitle','off', ...
                   'Position',[50 600 1400 450], 'Visible','on');
    try
        eegplot(EEG_preview.data, 'srate', EEG_preview.srate, 'winlength', 6, ...
                'dispchans', min(32, EEG_preview.nbchan), ...
                'title', sprintf('PREVIEW AFTER ICA — comps: %s (close when done)', mat2str(rejComps)), ...
                'winhandle', haFig);
    catch
        eegplot(EEG_preview.data, 'srate', EEG_preview.srate, 'winlength', 6, ...
                'dispchans', min(32, EEG_preview.nbchan), ...
                'title', sprintf('PREVIEW AFTER ICA — comps: %s (close when done)', mat2str(rejComps)));
        haFig = gcf;
        set(haFig, 'Name','EEG AFTER ICA PREVIEW');
    end
    set(haFig,'WindowStyle','normal');
    try, movegui(haFig,'onscreen'); end
    
    drawnow; figure(haFig); 
    
    waitfor(haFig);   % close AFTER when done
    waitfor(hbFig);   % then close BEFORE
    
    choice = questdlg( ...
        sprintf('Apply removal of components %s ?', mat2str(rejComps)), ...
        'Confirm ICA removal', 'Apply','Adjust','Cancel','Apply');
    
    switch choice
        case 'Apply'
            EEG = EEG_preview; EEG = eeg_checkset(EEG); done = true;
        case 'Adjust'
            % loop again to re-open pop_selectcomps
        otherwise
            error('ICA removal cancelled by user.');
    end

end


% Save AFTER-ICA-removal file 
EEG = eeg_checkset(EEG);
[ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, CURRENTSET);
EEG = pop_saveset(EEG, 'filename', setAfter, 'filepath', procRoot);


disp('Preprocessing + ICA with interactive preview finished.');


function resumeWithDecision(hFig, decision)
    if ishandle(hFig)
        setappdata(hFig,'decision',decision);
        uiresume(hFig);
    end
end

