function task_connectivity_theta_pipeline()
% TASK_CONNECTIVITY_THETA_PIPELINE
% ------------------------------------------------------------
% Event-related connectivity in fixed theta band (3–8 Hz) 
%   - Phase-based: debiased wPLI
%   - Time window: 0.3–2.0 s relative to event onset
%
% Aggregates ROI->ROI:
%   LF={AF3,F5,F1,FC3}  LP={CP3,P5,P1,PO3}
%   RF={AF4,F6,F2,FC4}  RP={CP4,P6,P2,PO4}
%
% INPUTS (set in "USER SETTINGS"):
%   - Folder of *_vme_epoched.set (epoched remembered trials, -2..+3 s)
%       example filenames:
%         t001_a-pre_vme_epoched.set
%         t001_a-post_vme_epoched.set
%         t001_c-pre_vme_epoched.set
%   - Optional RestMeta/TaskMeta.xlsx with:
%       Subject, SessionLetter, SessionLabel, Group
%
% OUTPUT:
%   - long table
% ------------------------------------------------------------

%% -------------------- USER SETTINGS -----------------------
data_folder = '<PROJECT_ROOT>\...';

meta_table  = '...';  % or 'TaskMeta.xlsx'
outdir   = '<PROJECT_ROOT>\...';
if ~exist(outdir,'dir'), mkdir(outdir); end
out_csv     = fullfile(outdir,'...');


theta_band  = [3 8];       
tapsmofrq   = 1.0;         
min_trials  = 10;           
t_win       = [0.3 2];   

% ROIs
LF = {'AF3','F5','F1','FC3'};   LP = {'CP3','P5','P1','PO3'};
RF = {'AF4','F6','F2','FC4'};   RP = {'CP4','P6','P2','PO4'};
roiPairs = { {'LF','LP',LF,LP}, {'RF','RP',RF,RP} };

% connectivity metric
do_wpli = true;
%% ------------------- LIBS & FILES -------------------------
eeglab; %#ok<*NOPTS>
ft_defaults;

files = dir(fullfile(data_folder, '*_vme_epoched.set'));
if isempty(files), error('No *_vme_epoched.set files found in %s', data_folder); end


% Optional meta (same structure as for resting)
hasMeta = exist(fullfile(data_folder, meta_table),'file')==2 || exist(meta_table,'file')==2;
if hasMeta
    META = readtable(meta_table);
    needMeta = {'Subject','SessionLetter','SessionLabel','Group'};
    if ~all(ismember(needMeta, META.Properties.VariableNames))
        warning('Meta file found but missing some of: %s. Proceeding without meta.', strjoin(needMeta,', '));
        hasMeta = false;
    end
end

all_needed = unique([LF,LP,RF,RP]);

%% ----------------- CONNECTIVITY EXTRACTION ----------------
RES = table(); % Subject, SessionLetter, Condition, Hemisphere, Metric, Value, [SessionLabel, Group]

for iFile = 1:numel(files)
    fname = files(iFile).name;
    fpath = fullfile(files(iFile).folder, fname);

    % t(\d+)_([abc])-(pre|post)_vme_epoched.set   <-- c instead of v
    tok = regexp(fname, '^t(\d+)_([abc])-(pre|post)_vme_epoched\.set$', 'tokens','once');
    if isempty(tok)
        fprintf('Skip non-matching: %s\n', fname);
        continue;
    end
    subjStr = tok{1};
    sessLet = tok{2};
    condStr = lower(tok{3});
    if strcmp(condStr,'pre')
        Condition = "Pre";
    else
        Condition = "Post";
    end

    % ---------- load of EEGLAB dataset ----------
    fpath = fullfile(files(iFile).folder, fname);

    EEG = pop_loadset('filename', fname, ...
                      'filepath', files(iFile).folder);

    if iscell(EEG)
        EEG = EEG{1};
    end

    % DEBUG
    fprintf('DEBUG: %s -> class(EEG) = %s\n', fname, class(EEG));

   
    if ~isstruct(EEG)
        error('pop_loadset did NOT return a struct for %s (class=%s).', ...
              fname, class(EEG));
    end
    if ~isfield(EEG,'chanlocs') || ~isfield(EEG,'data')
        error('EEG from %s is missing chanlocs or data fields.', fname);
    end


    if ndims(EEG.data) < 3
        fprintf('Not epoched in %s. Skipping.\n', fname);
        continue;
    end
    nEp = size(EEG.data,3);
    if nEp < min_trials
        fprintf('Too few epochs (n=%d) in %s. Skipping.\n', nEp, fname);
        continue;
    end

    % --------- Get channel locations ----------
    if isfield(EEG, 'chanlocs') && ~isempty(EEG.chanlocs)
        chanlocs = EEG.chanlocs;
    elseif isfield(EEG, 'urchanlocs') && ~isempty(EEG.urchanlocs)
        chanlocs = EEG.urchanlocs;
    else
        error('No non-empty chanlocs or urchanlocs in %s.', fname);
    end

    labs = string({chanlocs.labels});

    [tf_keep, idx_keep] = ismember(all_needed, cellstr(labs));
    if ~all(tf_keep)
        miss = all_needed(~tf_keep);
        fprintf('Missing needed chans in %s: %s. Skipping.\n', ...
                fname, strjoin(miss,', '));
        continue;
    end



    % --------- Select encoding time window (0.3–2.0 s) ----------
    t_raw = EEG.times;

    if max(abs(t_raw)) > 20
        % Likely in milliseconds (e.g. -2000..3000)
        t_sec = t_raw / 1000;
    else
        % Likely already in seconds (e.g. -2..3)
        t_sec = t_raw;
    end

    t_mask = t_sec >= t_win(1) & t_sec <= t_win(2);

    if nnz(t_mask) < 10
        fprintf('Too few samples in encoding window for %s. Skipping.\n', fname);
        continue;
    end

    t_sel = t_sec(t_mask);
    t_sel = t_sel - t_sel(1);

    % --------- Build FT data structure (ROI channels, encoding window) ----------
    keepLabs = unique([LF,LP,RF,RP]);
    [tfK, idxK] = ismember(keepLabs, cellstr(labs));

    data = [];
    data.label   = keepLabs(:);
    data.fsample = EEG.srate;
    data.trial   = cell(1,nEp);
    data.time    = cell(1,nEp);

    for ep = 1:nEp
        x = double(EEG.data(idxK(tfK), t_mask, ep)); % chan x time (encoding only)
        data.trial{ep} = x;
        data.time{ep}  = t_sel;                     
    end

    % --------- Spectral estimation (Fourier per trial) ----------
    cfg = [];
    cfg.method     = 'mtmfft';
    cfg.taper      = 'dpss';
    cfg.tapsmofrq  = tapsmofrq;
    cfg.output     = 'fourier';
    cfg.keeptrials = 'yes';
    cfg.foilim     = theta_band;   % fixed 
    freq = ft_freqanalysis(cfg, data); % fourierspctrm: trials x chan x freq

    % --------- Connectivity metrics ----------
    metric_out = struct();

    if do_wpli
        cfgc = [];
        cfgc.method = 'wpli_debiased';
        C = ft_connectivityanalysis(cfgc, freq);
        [M, lab] = getConnMatrix(C);  % chan x chan x freq
        metric_out.wpli_debiased = struct('M',M,'label',{lab});
    end

    % --------- ROI→ROI aggregation (mean over edges & freqs) ----------
    roiMean = @(M,lab,roiA,roiB) mean( ...
        reshape( M(ismember(lab,roiA), ismember(lab,roiB), :), [], 1 ), ...
        'omitnan');

    metricNames = fieldnames(metric_out);
    for m = 1:numel(metricNames)
        X = metric_out.(metricNames{m});
        for p = 1:numel(roiPairs)
            hemiName = sprintf('%s2%s', roiPairs{p}{1}, roiPairs{p}{2}); % e.g., LF2LP
            roiA = roiPairs{p}{3};
            roiB = roiPairs{p}{4};
            val = roiMean(X.M, X.label, roiA, roiB);
            if isnan(val), continue; end

            newrow = table( ...
                string(subjStr), string(sessLet), string(Condition), ...
                string(hemiName), string(metricNames{m}), double(val), ...
                'VariableNames', {'Subject','SessionLetter','Condition','Hemisphere','Metric','Value'});

            RES = [RES; newrow]; %#ok<AGROW>
        end
    end
end

% ---------------- Attach SessionLabel/Group if available ---------------
if hasMeta
    RES = outerjoin(RES, META, ...
        'Keys',{'Subject','SessionLetter'}, ...
        'MergeKeys', true, ...
        'Type','left');
end

% ---------------- Save long table --------------------------------------
writetable(RES, out_csv);
fprintf('Saved task theta connectivity table (encoding): %s\n', out_csv);

end

%% ===================== HELPERS ============================
function [mat, labels] = getConnMatrix(C)

    if ~isstruct(C) || ~isfield(C,'label')
        error('Connectivity struct missing labels.');
    end
    labels = C.label;

    % 1) Try known field names first 
    known = {'wplispctrm','cohspctrm','plvspctrm','ppcspctrm','powcorrspctrm', ...
             'wpli_debiasedspctrm','wplidebiasedspctrm','corrspctrm','amplcorrspctrm'};
    valField = '';
    for k = 1:numel(known)
        if isfield(C, known{k}) && isnumeric(C.(known{k}))
            valField = known{k};
            break;
        end
    end

    % 2) If still not found, auto-detect any numeric "...spctrm" field
    if isempty(valField)
        fns = fieldnames(C);
        for k = 1:numel(fns)
            fn = fns{k};
            if endsWith(fn,'spctrm') && isnumeric(C.(fn))
                valField = fn;
                break;
            end
        end
    end

    if isempty(valField)
        error('Unknown connectivity output fields in struct. Fields were: %s', strjoin(fieldnames(C),', '));
    end

    X = C.(valField);

    % Handle label-pair (labelcmb) format by rebuilding a square matrix
    if isfield(C,'labelcmb') && ~isempty(C.labelcmb)
        nC = numel(labels);
        if ndims(X)==2
            % X: nPairs x nFreq
            nF = size(X,2);
            M = nan(nC,nC,nF);
            for r = 1:size(C.labelcmb,1)
                i = find(strcmp(labels, C.labelcmb{r,1}));
                j = find(strcmp(labels, C.labelcmb{r,2}));
                if ~isempty(i) && ~isempty(j)
                    M(i,j,:) = reshape(X(r,:),1,1,[]);
                    M(j,i,:) = reshape(X(r,:),1,1,[]);
                end
            end
            mat = M;
        else
            % If already 3-D in pair-space, squeeze to freq and rebuild similarly
            nF = size(X,3);
            M = nan(nC,nC,nF);
            for r = 1:size(C.labelcmb,1)
                i = find(strcmp(labels, C.labelcmb{r,1}));
                j = find(strcmp(labels, C.labelcmb{r,2}));
                if ~isempty(i) && ~isempty(j)
                    M(i,j,:) = squeeze(X(r,1,:));
                    M(j,i,:) = squeeze(X(r,1,:));
                end
            end
            mat = M;
        end
    else
        % Expect chan x chan x freq
        if ndims(X)==2
            mat = reshape(X, size(X,1), size(X,2), 1);
        else
            mat = X;
        end
    end
end
