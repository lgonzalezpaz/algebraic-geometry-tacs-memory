%% run_theta_power_permFDR_delta_topos.m
% Per-channel nonparametric permutation tests with BH-FDR for Theta_power.
% Designs:
%   (A) WITHIN  : Post vs Pre per Session×Group (paired sign-flip)
%   (B) BETWEEN : Δ(Post−Pre) ITF+1 vs ITF−1 per Session (label permutation)
%   (C) WITHIN-GROUP session-pair Δ comparisons: AP–IP, AP–Sham, IP–Sham (paired sign-flip)
%
% Saves CSVs (+q_FDR) and topoplots (effect map and t-map) with FDR-significant channels marked.
% the study's 16-channel montage and a sample .set are used for plotting.

clear; clc; rng(13,'twister');

%% ------------------ USER SETTINGS ------------------
excelFile = '<PROJECT_ROOT>\...';
metricCol = 'Theta_power';

sampleSet = '<PROJECT_ROOT>\...';

outdir = '<PROJECT_ROOT>\...';
if ~exist(outdir,'dir'), mkdir(outdir); end

sessions = {'IP','AP','Sham'};
groups   = {'ITF-1','ITF+1'};
chanlist = {'AF3','F5','F1','FC3','CP3','P5','P1','PO3', ...
            'AF4','F6','F2','FC4','CP4','P6','P2','PO4'};
nPerm = 50000;

% ---- Fixed color limits ----
CLIM = struct();
CLIM.delta = 1;   % for all Δ(Post−Pre) maps: maplimits [-1, +1]
CLIM.t     = 2;   % for all t-maps:         maplimits [-2, +2]

%% ------------------ LOAD DATA ------------------
T = readtable(excelFile);
req = {'Subject','Group','SessionLabel','Condition','Electrode',metricCol};
miss = setdiff(req, T.Properties.VariableNames);
assert(isempty(miss), 'Missing columns: %s', strjoin(miss, ', '));

T = T(ismember(T.Electrode, chanlist), :);
T.Subject      = string(T.Subject);
T.Group        = categorical(string(T.Group), groups, 'Ordinal', false);
T.SessionLabel = categorical(string(T.SessionLabel), sessions, 'Ordinal', true);
T.Condition    = categorical(string(T.Condition), {'Pre','Post'}, 'Ordinal', true);
T.Electrode    = categorical(T.Electrode, chanlist, 'Ordinal', true);

% sample chanlocs for plotting
EEG = [];
try S = load(sampleSet,'-mat'); if isfield(S,'EEG'), EEG=S.EEG; end; catch, end
if isempty(EEG), EEG = pop_loadset('filename', sampleSet); end
[tf_map, idx_map] = ismember(chanlist, {EEG.chanlocs.labels});
assert(all(tf_map), 'Missing labels in EEG.chanlocs: %s', strjoin(chanlist(~tf_map), ', '));
chanlocs16 = EEG.chanlocs(idx_map);

% Helper to build subj×chan matrices for a given cell slice
buildMat = @(sess,grp,cond) pivotToMat( ...
    T(T.SessionLabel==sess & T.Group==grp & T.Condition==cond, :), ...
    'Subject','Electrode', metricCol, chanlist);


% %% ------------------ (A) WITHIN: Post vs Pre ------------------
% for ig = 1:numel(groups)
%     grp = string(groups{ig});
%     for is = 1:numel(sessions)
%         sess = string(sessions{is});
% 
%         Pre  = buildMat(sess, grp, 'Pre');
%         Post = buildMat(sess, grp, 'Post');
%         if isempty(Pre) || isempty(Post), continue; end
% 
%         % Align subjects (rows)
%         [subsPre, ia]  = unique(T.Subject(T.SessionLabel==sess & T.Group==grp & T.Condition=='Pre'),'stable');
%         [subsPost, ib] = unique(T.Subject(T.SessionLabel==sess & T.Group==grp & T.Condition=='Post'),'stable');
%         [subs, ia2, ib2] = intersect(subsPre, subsPost, 'stable');
%         if numel(subs) < 3, continue; end
%         Pre  = Pre(ia(ia2),:);
%         Post = Post(ib(ib2),:);
% 
%         tvals  = nan(1,numel(chanlist));
%         p_perm = nan(1,numel(chanlist));
%         delta  = mean(Post - Pre, 1);
% 
%         for c = 1:numel(chanlist)
%             d = Post(:,c) - Pre(:,c);
%             d = d(~isnan(d));
%             if numel(d) < 3, continue; end
%             [t_obs, p] = perm_paired_signflip(d, nPerm);
%             tvals(c) = t_obs; p_perm(c) = p;
%         end
% 
%         q = mafdr(p_perm,'BHFDR','true');
%         W = table(chanlist(:), tvals(:), p_perm(:), q(:), delta(:), ...
%             'VariableNames', {'Channel','t_perm','p_perm','q_FDR','MeanDelta'});
%         W.Session = repmat(categorical(sess),height(W),1);
%         W.Group   = repmat(categorical(grp),height(W),1);
%         writetable(W, fullfile(outdir, sprintf('WITHIN_%s_%s_theta_permFDR.csv', sess, grp)));
% 
%         sig = q<0.05 & ~isnan(q);
%         topo_with_markers(delta, chanlocs16, sig, tvals, ...
%             fullfile(outdir, sprintf('WITHIN_%s_%s_effect.png', sess, grp)), ...
%             sprintf('%s %s — mean(Post−Pre) θ power (perm-FDR)', grp, sess), 'Δ Power (µV^2)');
%         topo_with_markers(tvals, chanlocs16, sig, tvals, ...
%             fullfile(outdir, sprintf('WITHIN_%s_%s_tmap.png', sess, grp)), ...
%             sprintf('%s %s — t-map (paired perm, q<.05)', grp, sess), 't (paired)');
%     end
% end

%% ------------------ (B) BETWEEN: Δ(Post−Pre) ITF+1 vs ITF−1 ------------------
for is = 1:numel(sessions)
    sess = string(sessions{is});
    DeltaMinus = makeDeltaForSession(T, chanlist, metricCol, sess, 'ITF-1');
    DeltaPlus  = makeDeltaForSession(T, chanlist, metricCol, sess, 'ITF+1');
    if isempty(DeltaMinus) || isempty(DeltaPlus), continue; end

    tvals  = nan(1,numel(chanlist));
    p_perm = nan(1,numel(chanlist));
    effect = mean(double(DeltaPlus),1) - mean(double(DeltaMinus),1);

    for c = 1:numel(chanlist)
        x = DeltaMinus(:,c); x = x(~isnan(x));
        y = DeltaPlus(:,c);  y = y(~isnan(y));
        if numel(x)<3 || numel(y)<3, continue; end
        [t_obs, p] = perm_indep_labels(x, y, nPerm);
        tvals(c) = t_obs; p_perm(c) = p;
    end

    q = mafdr(p_perm,'BHFDR','true');
    B = table(chanlist(:), tvals(:), p_perm(:), q(:), effect(:), ...
        'VariableNames', {'Channel','t_perm','p_perm','q_FDR','MeanDeltaPlusMinusMinus'});
    B.Session = repmat(categorical(sess),height(B),1);
    writetable(B, fullfile(outdir, sprintf('BETWEEN_%s_theta_permFDR.csv', sess)));

    % ---- NEW: Δ maps per group (no significance on these) ----
    meanMinus = mean(double(DeltaMinus),1);
    meanPlus  = mean(double(DeltaPlus),1);
    clim_delta = CLIM.delta;  % fixed [-1, 1] for Δ maps

    % filenames
    f_minus = sprintf('BETWEEN_%s_ITFminus_DeltaMap.png', sess);
    f_plus  = sprintf('BETWEEN_%s_ITFplus_DeltaMap.png',  sess);

    topo_with_markers( ...
        meanMinus, chanlocs16, false(size(meanMinus(:))), [], ...
        fullfile(outdir, f_minus), ...
        sprintf('%s — ITF−1: mean Δ(Post−Pre) θ power', sess), ...
        'Δ Power (µV^2)', clim_delta);

    topo_with_markers( ...
        meanPlus, chanlocs16, false(size(meanPlus(:))), [], ...
        fullfile(outdir, f_plus), ...
        sprintf('%s — ITF+1: mean Δ(Post−Pre) θ power', sess), ...
        'Δ Power (µV^2)', clim_delta);

    sig = q<0.05 & ~isnan(q);
    % Fixed, symmetric color scales for BETWEEN
    clim_t     = CLIM.t;      % fixed [-2, 2] for t-maps
    
    topo_with_markers(tvals, chanlocs16, sig, tvals, ...
        fullfile(outdir, sprintf('BETWEEN_%s_tmap.png', sess)), ...
        sprintf('Between Δ — %s: t-map (indep perm, q<.05)', sess), ...
        't (indep)', clim_t);
end


%% -------- (C) WITHIN-GROUP: Δ session pairs (AP–IP, AP–Sham, IP–Sham) -------
pairs = {'AP','IP'; 'AP','Sham'; 'IP','Sham'};

for ig = 1:numel(groups)
    grp = string(groups{ig});   % ensure string, not char

    for sp = 1:size(pairs,1)
        A = string(pairs{sp,1});
        B = string(pairs{sp,2});

        % Align subjects and build Δ(Post-Pre) per session (DA, DB), subj x chan
        [DA, DB] = alignBySubject(T, chanlist, metricCol, grp, A, B);
        if isempty(DA) || isempty(DB), continue; end

        % Per-channel paired sign-flip permutation (B - A)
        tvals  = nan(1, numel(chanlist));
        p_perm = nan(1, numel(chanlist));
        effect = mean(DB - DA, 1);  % mean ΔB−ΔA

        for c = 1:numel(chanlist)
            dA = DA(:,c); dB = DB(:,c);
            ok = ~isnan(dA) & ~isnan(dB);
            dA = dA(ok); dB = dB(ok);
            if numel(dA) < 3, continue; end
            d = dB - dA;                              % paired diffs
            [t_obs, p] = perm_paired_signflip(d, nPerm);
            tvals(c)   = t_obs;
            p_perm(c)  = p;
        end

        % --- Per-channel N and Cohen's dz (paired)
        Ns  = nan(1, numel(chanlist));
        dz  = nan(1, numel(chanlist));
        for c = 1:numel(chanlist)
            dA = DA(:,c); dB = DB(:,c);
            ok = ~isnan(dA) & ~isnan(dB);
            d  = dB(ok) - dA(ok);
            Ns(c) = numel(d);
            if Ns(c) >= 3
                dz(c) = mean(d) / (std(d) + eps);
            end
        end
   


        % FDR (Benjamini–Hochberg) over channels for this comparison
        p_for_fdr = p_perm;
        p_for_fdr(isnan(p_for_fdr)) = 1;              
        q = mafdr(p_for_fdr, 'BHFDR', 'true');

        Ctab = table( ...
            chanlist(:), ...
            tvals(:), ...
            p_perm(:), ...
            q(:), ...
            effect(:), ...
            Ns(:), ...
            dz(:), ...
            repmat(categorical(string(grp)), numel(chanlist), 1), ...
            repmat(categorical(string(A)),   numel(chanlist), 1), ...
            repmat(categorical(string(B)),   numel(chanlist), 1), ...
            'VariableNames', {'Channel','t_perm','p_perm','q_FDR','MeanDiff_BminusA','N','CohensDz','Group','SessionA','SessionB'} ...
        );


         % --- Consistent color scales for this comparison
        clim_eff = 1;  % effect maps: -1..1
        clim_t     = CLIM.t;      % fixed [-2, 2] for t-maps

        
        % Save per-channel CSV
        fname_csv = sprintf('WITHIN_GROUP_%s_%s_minus_%s_theta_permFDR.csv', ...
                            char(string(grp)), char(string(B)), char(string(A)));
        writetable(Ctab, fullfile(outdir, fname_csv));
        
        % Sig mask
        sig = (q < 0.05) & ~isnan(q);
        
        % ---- NEW: Δ maps per session (within the group) ----
        meanA = mean(DA, 1);   % mean Δ(Post−Pre) for SessionA
        meanB = mean(DB, 1);   % mean Δ(Post−Pre) for SessionB
        clim_delta = CLIM.delta;  % fixed [-1, 1] for Δ maps

        % filenames for Δ maps
        fA = sprintf('WITHIN_GROUP_%s_%s_DeltaMap.png', char(string(grp)), char(string(A)));
        fB = sprintf('WITHIN_GROUP_%s_%s_DeltaMap.png', char(string(grp)), char(string(B)));

        topo_with_markers( ...
            meanA, chanlocs16, false(size(meanA(:))), [], ...
            fullfile(outdir, fA), ...
            sprintf('%s — %s: mean Δ(Post−Pre) θ power', grp, A), ...
            'Δ Power (µV^2)', clim_delta);

        topo_with_markers( ...
            meanB, chanlocs16, false(size(meanB(:))), [], ...
            fullfile(outdir, fB), ...
            sprintf('%s — %s: mean Δ(Post−Pre) θ power', grp, B), ...
            'Δ Power (µV^2)', clim_delta);
        

        fname_t = sprintf('WITHIN_GROUP_%s_%s_minus_%s_tmap.png', ...
                  char(string(grp)), char(string(B)), char(string(A)));

        % t-stat topomap
        topo_with_markers( ...
            tvals, chanlocs16, sig, tvals, ...
            fullfile(outdir, fname_t), ...
            sprintf('%s: Δ %s − %s — t-map (paired perm, q<.05)', grp, B, A), ...
            't (paired)', clim_t ...
        );


    end
end

fprintf('\nAll permutation+FDR tables and topoplots saved in:\n%s\n', outdir);


%% -------- Helper ---------------------



% function clim = shared_clim(varargin)
% % shared symmetric maplimits across multiple vectors
%     allv = [];
%     for k=1:nargin
%         v = varargin{k};
%         if isempty(v), continue; end
%         allv = [allv, v(:)']; %#ok<AGROW>
%     end
%     clim = max(abs(allv));
%     if ~isfinite(clim) || clim==0, clim = 1; end
% end




function topo_with_markers(values, chanlocs16, sigMask, tvals, savePath, ttl, cbarLab, clim)
    if nargin < 8 || isempty(clim)
        clim = max(abs(values)); if clim==0, clim=1; end
    end
    mk = {};
    if any(sigMask)
        posIdx = find(sigMask & tvals(:) > 0);
        negIdx = find(sigMask & tvals(:) <= 0);
        if ~isempty(posIdx), mk(end+1,:) = { posIdx, '*', 'k', 18, 2 }; end
        if ~isempty(negIdx), mk(end+1,:) = { negIdx, 'o', 'k', 18, 2 }; end
    end

    figure('Color','w');
    if isempty(mk)
        topoplot(values, chanlocs16, 'maplimits', [-clim clim], 'electrodes','labels');
    else
        topoplot(values, chanlocs16, 'maplimits', [-clim clim], 'electrodes','on', 'emarker2', mk);
    end
    cb = colorbar; ylabel(cb, cbarLab);
    title(ttl);
    drawnow;
    saveas(gcf, savePath);
    close(gcf);
end

%% ===================== LOCAL FUNCTIONS =====================
function M = pivotToMat(Tsub, subjCol, chanCol, valCol, chanorder)
    subs = unique(string(Tsub.(subjCol)), 'stable');
    M = nan(numel(subs), numel(chanorder));
    for i = 1:numel(subs)
        rows = string(Tsub.(subjCol))==subs(i);
        t = Tsub(rows,:);
        [tf, idx] = ismember(cellstr(string(t.(chanCol))), chanorder);
        vec = nan(1,numel(chanorder));
        if any(tf), vec(idx(tf)) = t.(valCol)(tf); end
        M(i,:) = vec;
    end
end

function Delta = makeDeltaForSession(Tall, chanlist, metricCol, sess, grp)
    build = @(cond) pivotToMat( ...
        Tall(Tall.SessionLabel==sess & Tall.Condition==cond & Tall.Group==grp, :), ...
        'Subject','Electrode', metricCol, chanlist);
    Pre  = build('Pre');  Post = build('Post');
    if isempty(Pre) || isempty(Post), Delta = []; return; end
    S_pre  = unique(string(Tall.Subject(Tall.SessionLabel==sess & Tall.Condition=='Pre'  & Tall.Group==grp)), 'stable');
    S_post = unique(string(Tall.Subject(Tall.SessionLabel==sess & Tall.Condition=='Post' & Tall.Group==grp)), 'stable');
    [subs, ia, ib] = intersect(S_pre, S_post, 'stable');
    if isempty(subs), Delta = []; return; end
    Pre  = Pre(ia,:); Post = Post(ib,:);
    Delta = Post - Pre;
end

function [DA, DB] = alignBySubject(T, chanlist, metricCol, grp, A, B)
    build = @(sess,cond) pivotToMat(T(T.Group==grp & T.SessionLabel==sess & T.Condition==cond,:), ...
                                    'Subject','Electrode', metricCol, chanlist);
    PreA=build(A,'Pre'); PostA=build(A,'Post');
    PreB=build(B,'Pre'); PostB=build(B,'Post');
    if isempty(PreA) || isempty(PostA) || isempty(PreB) || isempty(PostB), DA=[]; DB=[]; return; end
    S_preA  = unique(string(T.Subject(T.Group==grp & T.SessionLabel==A & T.Condition=='Pre')), 'stable');
    S_postA = unique(string(T.Subject(T.Group==grp & T.SessionLabel==A & T.Condition=='Post')), 'stable');
    S_preB  = unique(string(T.Subject(T.Group==grp & T.SessionLabel==B & T.Condition=='Pre')), 'stable');
    S_postB = unique(string(T.Subject(T.Group==grp & T.SessionLabel==B & T.Condition=='Post')), 'stable');
    [subsA, ia1, ib1] = intersect(S_preA, S_postA, 'stable');
    [subsB, ia2, ib2] = intersect(S_preB, S_postB, 'stable');
    [subsAB, iA, iB] = intersect(subsA, subsB, 'stable');
    if isempty(subsAB), DA=[]; DB=[]; return; end
    DA = PostA(ib1(iA),:) - PreA(ia1(iA),:);
    DB = PostB(ib2(iB),:) - PreB(ia2(iB),:);
end

function [t_obs, p] = perm_paired_signflip(d, nPerm)
    d = d(:); n = numel(d);
    t_obs = mean(d)/(std(d)+eps)*sqrt(n);
    signs = sign(randn(n, nPerm));
    t_perm = zeros(nPerm,1);
    for k=1:nPerm
        d_perm = d .* signs(:,k);
        t_perm(k) = mean(d_perm)/(std(d_perm)+eps)*sqrt(n);
    end
    p = mean(abs(t_perm)>=abs(t_obs));
end

function [t_obs, p] = perm_indep_labels(x, y, nPerm)
    x = x(:); y = y(:);
    n1 = numel(x); n2 = numel(y);
    t_obs = (mean(y)-mean(x)) / sqrt(var(y)/n2 + var(x)/n1 + eps);
    allD = [y; x];
    t_perm = zeros(nPerm,1);
    for k=1:nPerm
        idx = randperm(n1+n2);
        idx2 = idx(1:n2); idx1 = idx(n2+1:end);
        mu2 = mean(allD(idx2)); mu1 = mean(allD(idx1));
        v2  = var(allD(idx2));  v1  = var(allD(idx1));
        t_perm(k) = (mu2 - mu1) / sqrt(v2/n2 + v1/n1 + eps);
    end
    p = mean(abs(t_perm)>=abs(t_obs));
end


function c = ascat(x)
    if isstring(x)
        c = categorical(x);
    elseif ischar(x)
        c = categorical(string(x));
    elseif iscellstr(x)
        c = categorical(string(x{1}));
    else
        c = categorical(string(x));
    end
end

