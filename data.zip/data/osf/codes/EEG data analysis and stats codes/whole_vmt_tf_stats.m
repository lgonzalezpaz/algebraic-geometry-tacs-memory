%% ============================================================
%  VMT — TFR (post-pre) cluster-based stats + save bundle
%  Requires FieldTrip (ft_defaults). 
%  Last update: 12.01.2025
%% 0) Paths & FT init
clear; clc;

% ---- EDIT THESE ----
rootTaskData = '<PROJECT_ROOT>\...';
elcPath    = '<EEGLAB_ROOT>\plugins\dipfit\standard_BEM\elec\standard_1005.elc';


% ---- Data locations ----
tfrOutDir    = fullfile(rootTaskData, '...');
statsOutDir  = fullfile(rootTaskData, '...');
if ~exist(statsOutDir,'dir'), mkdir(statsOutDir); end

% ---- Subjects from the session-order table ----
sessionOrderXLS = fullfile(rootTaskData, '...');
opts = detectImportOptions(sessionOrderXLS);
sessOrder = readtable(sessionOrderXLS, opts);
subs = string(sessOrder.subject_id);
subjects = string(arrayfun(@(s) sprintf('%03d', str2double(s)), subs, 'uni', 0));

S_ITFm1 = string([]);  % e.g., ["001","004","007"]
S_ITFp1 = string([]);  % e.g., ["002","005","008"]

rng('default');                
rng(13,'twister');              

%  TF window
statWin.frequency = [3 48];   
statWin.latency   = [0.3 1.0];
Nperm = 5000; twoSidedAlpha = 0.05; rng(13);

%% 1) Load Δ stacks (a,b,c) + align subjects
[Ga,Sa] = load_diff_stack(subjects,'a',tfrOutDir);
[Gb,Sb] = load_diff_stack(subjects,'b',tfrOutDir);
[Gc,Sc] = load_diff_stack(subjects,'c',tfrOutDir);

Scommon = intersect(intersect(Sa,Sb,'stable'),Sc,'stable');
if isempty(Scommon), error('No common subjects across a,b,c.'); end
Ga = subset_G_by_subjects(Ga, Sa, Scommon);
Gb = subset_G_by_subjects(Gb, Sb, Scommon);
Gc = subset_G_by_subjects(Gc, Sc, Scommon);
fprintf('Aligned subjects across a,b,c: N=%d\n', numel(Scommon));
writetable(table(Scommon(:),'VariableNames',{'SubjectID'}), fullfile(statsOutDir,'subjects_used_common.csv'));

nums = str2double(Scommon);
S_ITFm1 = Scommon(nums >= 1  & nums <= 23);   % ITF-1
S_ITFp1 = Scommon(nums >= 26 & nums <= 48);   % ITF+1

fprintf('ITF-1 group N = %d | ITF+1 group N = %d\n', numel(S_ITFm1), numel(S_ITFp1));

%% 2) Neighbours + layout (robust for the 16-channel montage)

[layout, ~] = prep_layout_and_neigh(Ga, elcPath);
vme_quick_layout_qc(layout);

[layout, neigh] = prep_layout_and_neigh(Ga, '<FIELDTRIP_ROOT>\template\electrode\standard_1005.elc');
save(fullfile(statsOutDir,'neighbours.mat'),'neigh'); save(fullfile(statsOutDir,'layout.mat'),'layout');


%% 4) Paired within-subject contrasts
% 4a) Paired contrasts within ITF-1 group
if numel(S_ITFm1) >= 2
    Ga_m1 = subset_G_by_subjects(Ga, Scommon, S_ITFm1);
    Gb_m1 = subset_G_by_subjects(Gb, Scommon, S_ITFm1);
    Gc_m1 = subset_G_by_subjects(Gc, Scommon, S_ITFm1);

    stat_b_vs_a_ITFm1 = run_paired(Ga_m1, Gb_m1, neigh, statWin, Nperm, twoSidedAlpha);
    stat_c_vs_a_ITFm1 = run_paired(Ga_m1, Gc_m1, neigh, statWin, Nperm, twoSidedAlpha);
    stat_c_vs_b_ITFm1 = run_paired(Gb_m1, Gc_m1, neigh, statWin, Nperm, twoSidedAlpha);

    print_cluster_summary('ITF-1: Δ_b − Δ_a', stat_b_vs_a_ITFm1);
    print_cluster_summary('ITF-1: Δ_c − Δ_a', stat_c_vs_a_ITFm1);
    print_cluster_summary('ITF-1: Δ_c − Δ_b', stat_c_vs_b_ITFm1);

    save_stat_bundle('b_vs_a_ITFm1', stat_b_vs_a_ITFm1, layout, neigh, statsOutDir);
    save_stat_bundle('c_vs_a_ITFm1', stat_c_vs_a_ITFm1, layout, neigh, statsOutDir);
    save_stat_bundle('c_vs_b_ITFm1', stat_c_vs_b_ITFm1, layout, neigh, statsOutDir);
else
    fprintf('ITF-1 group too small for paired stats (N=%d).\n', numel(S_ITFm1));
end


% 4b) Paired contrasts within ITF+1 group
if numel(S_ITFp1) >= 2
    Ga_p1 = subset_G_by_subjects(Ga, Scommon, S_ITFp1);
    Gb_p1 = subset_G_by_subjects(Gb, Scommon, S_ITFp1);
    Gc_p1 = subset_G_by_subjects(Gc, Scommon, S_ITFp1);

    stat_b_vs_a_ITFp1 = run_paired(Ga_p1, Gb_p1, neigh, statWin, Nperm, twoSidedAlpha);
    stat_c_vs_a_ITFp1 = run_paired(Ga_p1, Gc_p1, neigh, statWin, Nperm, twoSidedAlpha);
    stat_c_vs_b_ITFp1 = run_paired(Gb_p1, Gc_p1, neigh, statWin, Nperm, twoSidedAlpha);

    print_cluster_summary('ITF+1: Δ_b − Δ_a', stat_b_vs_a_ITFp1);
    print_cluster_summary('ITF+1: Δ_c − Δ_a', stat_c_vs_a_ITFp1);
    print_cluster_summary('ITF+1: Δ_c − Δ_b', stat_c_vs_b_ITFp1);

    save_stat_bundle('b_vs_a_ITFp1', stat_b_vs_a_ITFp1, layout, neigh, statsOutDir);
    save_stat_bundle('c_vs_a_ITFp1', stat_c_vs_a_ITFp1, layout, neigh, statsOutDir);
    save_stat_bundle('c_vs_b_ITFp1', stat_c_vs_b_ITFp1, layout, neigh, statsOutDir);
else
    fprintf('ITF+1 group too small for paired stats (N=%d).\n', numel(S_ITFp1));
end

%% 5) Between-group

if ~isempty(S_ITFm1) && ~isempty(S_ITFp1)
    % Load Δ_a stacks for each group
    [Gm1,~] = load_diff_stack(S_ITFm1, 'a', tfrOutDir);
    [Gp1,~] = load_diff_stack(S_ITFp1, 'a', tfrOutDir);

    [layoutG, neighG] = prep_layout_and_neigh(Gm1, elcPath);

    % Independent-samples cluster test (ITF-1 vs ITF+1) for condition a
    stat_group_a = run_between_groups(Gm1, Gp1, neighG, statWin, Nperm, twoSidedAlpha);
    print_cluster_summary('ITF−1 vs ITF+1 (Δ_a)', stat_group_a);
    save_stat_bundle('group_a', stat_group_a, layoutG, neighG, statsOutDir);
else
    fprintf('[Between-group skipped] No subjects found in one or both groups.\n');
end

if ~isempty(S_ITFm1) && ~isempty(S_ITFp1)
    % Load Δ_c stacks for each group
    [Gm1,~] = load_diff_stack(S_ITFm1, 'b', tfrOutDir);
    [Gp1,~] = load_diff_stack(S_ITFp1, 'b', tfrOutDir);

    [layoutG, neighG] = prep_layout_and_neigh(Gm1, elcPath);

    % Independent-samples cluster test (ITF-1 vs ITF+1) for condition b
    stat_group_b = run_between_groups(Gm1, Gp1, neighG, statWin, Nperm, twoSidedAlpha);
    print_cluster_summary('ITF−1 vs ITF+1 (Δ_b)', stat_group_b);
    save_stat_bundle('group_b', stat_group_b, layoutG, neighG, statsOutDir);
else
    fprintf('[Between-group skipped] No subjects found in one or both groups.\n');
end


if ~isempty(S_ITFm1) && ~isempty(S_ITFp1)
    % Load Δ_c stacks for each group
    [Gm1,~] = load_diff_stack(S_ITFm1, 'c', tfrOutDir);
    [Gp1,~] = load_diff_stack(S_ITFp1, 'c', tfrOutDir);

    [layoutG, neighG] = prep_layout_and_neigh(Gm1, elcPath);

    % Independent-samples cluster test (ITF-1 vs ITF+1) for condition c
    stat_group_c = run_between_groups(Gm1, Gp1, neighG, statWin, Nperm, twoSidedAlpha);
    print_cluster_summary('ITF−1 vs ITF+1 (Δ_c)', stat_group_c);
    save_stat_bundle('group_c', stat_group_c, layoutG, neighG, statsOutDir);
else
    fprintf('[Between-group skipped] No subjects found in one or both groups.\n');
end


%% 6) Visual example
% A) Topoplot of t-values, masked to that neg cluster
S = stat_group_a;

clIdx   = 1;             % NEG cluster #1
tRange  = [0.301 0.621];
fRange  = [3 7];

if isfield(S,'negclusterslabelmat')
    maskCluster = (S.negclusterslabelmat == clIdx);
else
    error('No negclusterslabelmat in stat_group_a.');
end
S.mask = maskCluster;    % FieldTrip will use this for masking

% ---- which channels are significant in THIS TF window? ----
freqIdx = S.freq >= fRange(1) & S.freq <= fRange(2);
timeIdx = S.time >= tRange(1) & S.time <= tRange(2);
maskWin = maskCluster(:, freqIdx, timeIdx);          % chan x f x t
chanSig = squeeze(any(any(maskWin, 3), 2));          % chan x 1 logical
sigLabels = S.label(chanSig);                        % cell of labels

%% A) t-map with cluster outline + sig-channel markers
cfg = [];
cfg.parameter     = 'stat';
cfg.maskparameter = 'mask';
cfg.maskstyle     = 'outline';     % or 'opacity'
cfg.xlim          = tRange;
cfg.ylim          = fRange;
cfg.avgovertime   = 'yes';
cfg.avgoverfreq   = 'yes';
cfg.layout        = layoutG;
cfg.zlim          = 'maxabs';

fA = figure('Name','ITF-1 vs ITF+1 (Δ_a) t-map','Color','w');
ft_topoplotTFR(cfg, S); colorbar; hold on;

% mark significant channels (black circles)
for ii = 1:numel(sigLabels)
    li = strcmp(layoutG.label, sigLabels{ii});
    if any(li)
        scatter(layoutG.pos(li,1), layoutG.pos(li,2), 80, 'k', 'LineWidth', 1.5);
    end
end
hold off;




%% B) Topoplots of Δ_a for each group separately
cfgGA = [];
cfgGA.parameter  = 'powspctrm';
cfgGA.keeptrials = 'no';
GA_m1 = ft_freqdescriptives(cfgGA, Gm1);   % ITF-1
GA_p1 = ft_freqdescriptives(cfgGA, Gp1);   % ITF+1

commonZLim = [-0.6 0.6];

cfgTop = [];
cfgTop.parameter    = 'powspctrm';
cfgTop.xlim         = tRange;
cfgTop.ylim         = fRange;
cfgTop.avgovertime  = 'yes';
cfgTop.avgoverfreq  = 'yes';
cfgTop.layout       = layoutG;
cfgTop.zlim         = commonZLim;

% ITF-1
fB1 = figure('Name','ITF-1: Δ_a (3–7 Hz, 0.30–0.62 s)','Color','w');
ft_topoplotTFR(cfgTop, GA_m1); colorbar; hold on;
for ii = 1:numel(sigLabels)
    li = strcmp(layoutG.label, sigLabels{ii});
    if any(li)
        scatter(layoutG.pos(li,1), layoutG.pos(li,2), 80, 'k', 'LineWidth', 1.5);
    end
end
hold off;
title('ITF-1 (Δ_a post–pre, dB)');



% ITF+1
fB2 = figure('Name','ITF+1: Δ_a (3–7 Hz, 0.30–0.62 s)','Color','w');
ft_topoplotTFR(cfgTop, GA_p1); colorbar; hold on;
for ii = 1:numel(sigLabels)
    li = strcmp(layoutG.label, sigLabels{ii});
    if any(li)
        scatter(layoutG.pos(li,1), layoutG.pos(li,2), 80, 'k', 'LineWidth', 1.5);
    end
end
hold off;
title('ITF+1 (Δ_a post–pre, dB)');



%% C) Difference map (ITF−1 minus ITF+1) in same window
Gdiff = GA_m1;
Gdiff.powspctrm = GA_m1.powspctrm - GA_p1.powspctrm;  % ITF-1 − ITF+1

cfgDiff = cfgTop;              % same TF window + same zlim
fC = figure('Name','Δ_a difference (ITF-1 − ITF+1)','Color','w');
ft_topoplotTFR(cfgDiff, Gdiff); colorbar; hold on;
for ii = 1:numel(sigLabels)
    li = strcmp(layoutG.label, sigLabels{ii});
    if any(li)
        scatter(layoutG.pos(li,1), layoutG.pos(li,2), 80, 'k', 'LineWidth', 1.5);
    end
end
hold off;
title('Δ_a (ITF-1 − ITF+1, dB)');


disp('All stats + saves done.');

%% =========================
%  Helper functions
%  =========================
function [G, S_kept] = load_diff_stack(subjects, condChar, tfrOutDir)
    S = {}; IDs = {};
    for i = 1:numel(subjects)
        f = fullfile(tfrOutDir, sprintf('tfrdiff_%s_%s_postminuspre.mat', subjects(i), condChar));
        if ~isfile(f), warning('Missing %s', f); continue; end
        L = load(f, 'diffTFR');
        S{end+1}  = L.diffTFR;           %#ok<AGROW>
        IDs{end+1}= char(subjects(i));   %#ok<AGROW>
    end
    assert(~isempty(S), 'No diff files found for cond %s', condChar);

    ref = S{1};
    nS  = numel(S);
    pow = nan(nS, numel(ref.label), numel(ref.freq), numel(ref.time));
    for k = 1:nS
        assert(isequal(S{k}.label, ref.label) && isequal(S{k}.freq, ref.freq) && isequal(S{k}.time, ref.time), ...
               'Axes mismatch across subjects. Harmonize before stacking.');
        pow(k,:,:,:) = S{k}.powspctrm;
    end
    G = struct('label',{ref.label}, 'freq',ref.freq, 'time',ref.time, ...
               'powspctrm',pow, 'dimord','rpt_chan_freq_time', 'cfg',[]);
    if isfield(ref,'elec'), G.elec = ref.elec; end
    if isfield(ref,'grad'), G.grad = ref.grad; end
    S_kept = string(IDs);
end

function G2 = subset_G_by_subjects(G, Sold, Skeep)
    [lia, idx] = ismember(Skeep, Sold);
    idx = idx(lia);
    G2 = G;
    G2.powspctrm = G.powspctrm(idx,:,:,:);
end


function [layout, neigh] = prep_layout_and_neigh(G, elcPath)

    % 1) Read template electrodes and convert units
    sensT = ft_read_sens(elcPath);                 % template EEG locations
    sensT = ft_convert_units(sensT, 'cm');

    % 2) Map template to your labels 
    nCh = numel(G.label);
    idxT = nan(nCh,1);
    for k = 1:nCh
        hit = find(strcmpi(sensT.label, G.label{k}), 1);
        if ~isempty(hit), idxT(k) = hit; end
    end
    if any(isnan(idxT))
        missing = G.label(isnan(idxT));
        error('Cannot map all channels to template coords. Missing: %s', strjoin(missing, ', '));
    end

    % 3) Build a MINIMAL elec 
    elec = [];
    elec.label   = G.label(:)';                      % 1 x N cell
    elec.chanpos = sensT.chanpos(idxT, :);          % N x 3
    elec.unit    = 'cm';
    elec.type    = 'eeg';

    % 4) Layout for exactly these channels
    cfgL = [];
    cfgL.elec    = elec;
    cfgL.channel = G.label;
    layout = ft_prepare_layout(cfgL);

    % 5) Neighbours from 2D layout positions (manual, robust)
    neigh = build_neigh_from_layout(layout, 0.25);   % 2D distance threshold (layout units)
end


function neigh = build_neigh_from_layout(layout, radius)

    labels = layout.label(:);
    pos    = layout.pos(:,1:2); % x-y
    good   = all(isfinite(pos),2);
    labels = labels(good);
    pos    = pos(good,:);

    % Pairwise distances
    D = squareform(pdist(pos));
    n = numel(labels);
    neigh = repmat(struct('label','','neighblabel',{{}}), n, 1);
    for i = 1:n
        neigh(i).label = labels{i};
        neighIdx = find(D(i,:) > 0 & D(i,:) <= radius);
        neigh(i).neighblabel = labels(neighIdx)';
    end
end


function stat = run_one_sample(G, neigh, statWin, Nperm, twoSidedAlpha)
    cfg = [];
    cfg.method           = 'montecarlo';
    cfg.statistic        = 'ft_statfun_onesampleT';
    cfg.parameter        = 'powspctrm';
    cfg.correctm         = 'cluster';
    cfg.clusteralpha     = 0.05;
    cfg.clusterstatistic = 'maxsum';
    cfg.minnbchan        = 2;         
    cfg.neighbours       = neigh;
    cfg.tail             = 0; cfg.clustertail = 0;
    cfg.alpha            = twoSidedAlpha;
    cfg.numrandomization = Nperm;
    cfg.frequency        = statWin.frequency;
    cfg.latency          = statWin.latency;
    cfg.randomseed       = 13;

    nSubj = size(G.powspctrm,1);
    cfg.design = 1:nSubj; cfg.uvar=[]; cfg.ivar=1;
    stat = ft_freqstatistics(cfg, G);
end

function stat = run_paired(G1, G2, neigh, statWin, Nperm, twoSidedAlpha)
    assert(isequal(size(G1.powspctrm), size(G2.powspctrm)));
    cfg = [];
    cfg.method           = 'montecarlo';
    cfg.statistic        = 'ft_statfun_depsamplesT';
    cfg.parameter        = 'powspctrm';
    cfg.correctm         = 'cluster';
    cfg.clusteralpha     = 0.05;
    cfg.clusterstatistic = 'maxsum';
    cfg.minnbchan        = 1;     % lenient
    cfg.neighbours       = neigh;
    cfg.tail             = 0; cfg.clustertail = 0;
    cfg.alpha            = twoSidedAlpha;
    cfg.numrandomization = Nperm;
    cfg.frequency        = statWin.frequency;
    cfg.latency          = statWin.latency;
    cfg.randomseed       = 13;

    nSubj = size(G1.powspctrm,1);
    design = zeros(2, 2*nSubj);
    design(1,1:nSubj)     = 1:nSubj;
    design(1,nSubj+1:end) = 1:nSubj;
    design(2,1:nSubj)     = 1;
    design(2,nSubj+1:end) = 2;
    cfg.design = design; cfg.uvar=1; cfg.ivar=2;

    stat = ft_freqstatistics(cfg, G1, G2);
end

function stat = run_between_groups(G1, G2, neigh, statWin, Nperm, twoSidedAlpha)
    cfg = [];
    cfg.method           = 'montecarlo';
    cfg.statistic        = 'ft_statfun_indepsamplesT';
    cfg.parameter        = 'powspctrm';
    cfg.correctm         = 'cluster';
    cfg.clusteralpha     = 0.05;
    cfg.clusterstatistic = 'maxsum';
    cfg.minnbchan        = 1;
    cfg.neighbours       = neigh;
    cfg.tail             = 0; cfg.clustertail = 0;
    cfg.alpha            = twoSidedAlpha;
    cfg.numrandomization = Nperm;
    cfg.frequency        = statWin.frequency;
    cfg.latency          = statWin.latency;
    cfg.randomseed       = 13;

    n1 = size(G1.powspctrm,1); n2 = size(G2.powspctrm,1);
    cfg.design = [ones(1,n1), 2*ones(1,n2)];
    cfg.ivar   = 1; % no uvar
    stat = ft_freqstatistics(cfg, G1, G2);
end

function [mask3d, info] = biggest_sig_cluster_mask(S, alpha)
    mask3d = false(numel(S.label), numel(S.freq), numel(S.time));
    info = struct('hasSig',false,'polarity','','pval',NaN,'fRange',[NaN NaN],'tRange',[NaN NaN]);
    bestMass = -inf;

    function [fr, tr] = bounds(M)
        fIdx = find(any(any(M,3),1)); tIdx = find(any(any(M,2),1));
        if isempty(fIdx)||isempty(tIdx), fr=[NaN NaN]; tr=[NaN NaN]; return; end
        fr=[S.freq(fIdx(1)) S.freq(fIdx(end))]; tr=[S.time(tIdx(1)) S.time(tIdx(end))];
    end

    if isfield(S,'posclusters') && ~isempty(S.posclusters)
        for i=1:numel(S.posclusters)
            p=S.posclusters(i).prob; if p<alpha
                M=(S.posclusterslabelmat==i);
                mass=nansum(S.stat(M),'all');
                if mass>bestMass, bestMass=mass; mask3d=M; info=struct('hasSig',true,'polarity','pos','pval',p,'fRange',bounds(M)); end
            end
        end
    end
    if isfield(S,'negclusters') && ~isempty(S.negclusters)
        for i=1:numel(S.negclusters)
            p=S.negclusters(i).prob; if p<alpha
                M=(S.negclusterslabelmat==i);
                mass=-nansum(S.stat(M),'all');
                if mass>bestMass, bestMass=mass; mask3d=M; info=struct('hasSig',true,'polarity','neg','pval',p,'fRange',bounds(M)); end
            end
        end
    end
    if info.hasSig
        [fr,tr]=bounds(mask3d); info.fRange=fr; info.tRange=tr;
    end
end

function print_cluster_summary(name, S)
    fprintf('\n-- %s --\n', name);
    hasSig=false;
    if isfield(S,'posclusters') && ~isempty(S.posclusters)
        for i=1:numel(S.posclusters)
            p=S.posclusters(i).prob;
            if p<0.05
                M=(S.posclusterslabelmat==i);
                [fr,tr]=local_bounds(S,M);
                fprintf('POS %d: p=%.4f | %.1f–%.1f Hz | %.3f–%.3f s\n',i,p,fr,tr);
                hasSig=true;
            end
        end
    end
    if isfield(S,'negclusters') && ~isempty(S.negclusters)
        for i=1:numel(S.negclusters)
            p=S.negclusters(i).prob;
            if p<0.05
                M=(S.negclusterslabelmat==i);
                [fr,tr]=local_bounds(S,M);
                fprintf('NEG %d: p=%.4f | %.1f–%.1f Hz | %.3f–%.3f s\n',i,p,fr,tr);
                hasSig=true;
            end
        end
    end
    if ~hasSig, fprintf('No significant clusters at p<0.05.\n'); end
end
function [fr,tr]=local_bounds(S,M)
    fIdx=find(any(any(M,3),1)); tIdx=find(any(any(M,2),1));
    fr=[S.freq(fIdx(1)) S.freq(fIdx(end))]; tr=[S.time(tIdx(1)) S.time(tIdx(end))];
end

function save_stat_bundle(name, stat, layout, neigh, outDir)
    % 1) Save raw stat + CSV summary
    save(fullfile(outDir, [name '.mat']), 'stat', '-v7.3');
    T = summarize_stat_to_table(stat);
    writetable(T, fullfile(outDir, [name '_clusters.csv']));

    % 2) Only attempt clusterplot if there is at least one sig cluster
    hasSig = false;
    if isfield(stat,'posclusters') && ~isempty(stat.posclusters)
        hasSig = hasSig || any(arrayfun(@(c) c.prob<0.05, stat.posclusters));
    end
    if isfield(stat,'negclusters') && ~isempty(stat.negclusters)
        hasSig = hasSig || any(arrayfun(@(c) c.prob<0.05, stat.negclusters));
    end

    if hasSig
        try
            cfgcp = [];
            cfgcp.alpha      = 0.05;
            cfgcp.parameter  = 'stat';
            cfgcp.zlim       = 'maxabs';
            cfgcp.layout     = layout;
            f = figure('Visible','off','Color','w','Name',['clusterplot_' name]);
            ft_clusterplot(cfgcp, stat);
            exportgraphics(f, fullfile(outDir, [name '_clusterplot.png']), 'Resolution', 200);
            close(f);
        catch ME
            warning('clusterplot skipped for %s: %s', name, ME.message);
        end
    else
        % Nothing to plot 
        fprintf('clusterplot skipped for %s (no sig clusters at alpha=0.05)\n', name);
    end

    % 3) Save label-masks for all clusters
    masks = struct();
    if isfield(stat,'posclusterslabelmat')
        npos = max(stat.posclusterslabelmat, [], 'all');
        masks.pos = cell(1, max(0,npos));
        for i=1:numel(masks.pos), masks.pos{i} = (stat.posclusterslabelmat==i); end
    end
    if isfield(stat,'negclusterslabelmat')
        nneg = max(stat.negclusterslabelmat, [], 'all');
        masks.neg = cell(1, max(0,nneg));
        for i=1:numel(masks.neg), masks.neg{i} = (stat.negclusterslabelmat==i); end
    end
    meta = struct('label',{stat.label},'freq',stat.freq,'time',stat.time,'dimord','chan_freq_time');
    save(fullfile(outDir, [name '_masks.mat']), 'masks','meta','-v7.3');

    fprintf('Saved bundle for %s → %s\n', name, outDir);
end


function T = summarize_stat_to_table(S)
    rows = [];
    function r = mkrow(M, p, pol, idx)
        vals=S.stat; fIdx=find(any(any(M,3),1)); tIdx=find(any(any(M,2),1));
        if isempty(fIdx)||isempty(tIdx)
            fr=[nan nan]; tr=[nan nan]; nF=0; nT=0; nC=0;
        else
            fr=[S.freq(fIdx(1)) S.freq(fIdx(end))];
            tr=[S.time(tIdx(1)) S.time(tIdx(end))];
            nF=numel(fIdx); nT=numel(tIdx); nC=numel(find(any(any(M,3),2)));
        end
        maskVals=vals; maskVals(~M)=0;
        if strcmp(pol,'pos'), [peakT,lin]=max(maskVals(:));
        else, maskVals(~M)=+inf; [peakT,lin]=min(maskVals(:)); end
        if isinf(peakT), peakT=NaN; peakChan=""; peakFreq=NaN; peakTime=NaN;
        else, [ci,fi,ti]=ind2sub(size(vals),lin); peakChan=string(S.label{ci}); peakFreq=S.freq(fi); peakTime=S.time(ti); end
        clusterMass = sum(vals(M),'omitnan');
        r = table(string(pol), idx, p, clusterMass, nC, nF, nT, fr(1),fr(2), tr(1),tr(2), ...
                  peakT, peakChan, peakFreq, peakTime, ...
            'VariableNames', {'Polarity','ClusterIndex','p_value','ClusterMass', ...
            'N_Channels','N_FreqBins','N_TimeBins','FreqMin','FreqMax','TimeMin','TimeMax', ...
            'Peak_t','Peak_Channel','Peak_Freq','Peak_Time'});
    end
    if isfield(S,'posclusters') && ~isempty(S.posclusters)
        for i=1:numel(S.posclusters)
            p=S.posclusters(i).prob; if p<0.05 && isfield(S,'posclusterslabelmat')
                rows=[rows; mkrow(S.posclusterslabelmat==i, p, 'pos', i)]; %#ok<AGROW>
            end
        end
    end
    if isfield(S,'negclusters') && ~isempty(S.negclusters)
        for i=1:numel(S.negclusters)
            p=S.negclusters(i).prob; if p<0.05 && isfield(S,'negclusterslabelmat')
                rows=[rows; mkrow(S.negclusterslabelmat==i, p, 'neg', i)]; %#ok<AGROW>
            end
        end
    end
    if isempty(rows)
        T = table('Size',[0 15], 'VariableTypes', ...
            {'string','double','double','double','double','double','double', ...
             'double','double','double','double','double','string','double','double'}, ...
            'VariableNames', {'Polarity','ClusterIndex','p_value','ClusterMass', ...
                              'N_Channels','N_FreqBins','N_TimeBins', ...
                              'FreqMin','FreqMax','TimeMin','TimeMax', ...
                              'Peak_t','Peak_Channel','Peak_Freq','Peak_Time'});
    else
        T = rows;
    end
end


function summarize_all_clusters(tag, S, outdir)
    T = all_clusters_table(S);   % includes both significant and non-significant clusters
    if isempty(T)
        fprintf('[%s] No observed clusters (unexpected).\n', tag);
        T = array2table(zeros(0,15), 'VariableNames', ...
            {'Polarity','ClusterIndex','p_value','ClusterMass','N_Channels','N_FreqBins','N_TimeBins', ...
             'FreqMin','FreqMax','TimeMin','TimeMax','Peak_t','Peak_Channel','Peak_Freq','Peak_Time'});
    end
    T = sortrows(T, 'p_value', 'ascend');
    writetable(T, fullfile(outdir, [tag '.csv']));
    fprintf('Saved %d clusters → %s\n', height(T), fullfile(outdir, [tag '.csv']));
end

function print_topK(S, name, K)
    T = all_clusters_table(S);
    if isempty(T)
        fprintf('\n-- %s --\n(no clusters found)\n', name);
        return;
    end
    T = sortrows(T, 'p_value', 'ascend');
    K = min(K, height(T));
    fprintf('\n-- %s : Top %d observed clusters (cluster-level p, mass, TF bounds) --\n', name, K);
    for i=1:K
        r = T(i,:);
        fprintf('%s #%d | p=%.4f | mass=%.2f | %s | %.1f–%.1f Hz, %.3f–%.3f s | peak t=%.2f @ %s %.1f Hz %.3f s\n', ...
            r.Polarity{1}, r.ClusterIndex, r.p_value, r.ClusterMass, name, ...
            r.FreqMin, r.FreqMax, r.TimeMin, r.TimeMax, r.Peak_t, r.Peak_Channel{1}, r.Peak_Freq, r.Peak_Time);
    end
end

function T = all_clusters_table(S)
    rows = [];
    % positive
    if isfield(S,'posclusters') && ~isempty(S.posclusters)
        for i=1:numel(S.posclusters)
            p = S.posclusters(i).prob;
            M = (S.posclusterslabelmat==i);
            rows = [rows; cluster_row(S, M, p, 'pos', i)]; %#ok<AGROW>
        end
    end
    % negative
    if isfield(S,'negclusters') && ~isempty(S.negclusters)
        for i=1:numel(S.negclusters)
            p = S.negclusters(i).prob;
            M = (S.negclusterslabelmat==i);
            rows = [rows; cluster_row(S, M, p, 'neg', i)]; %#ok<AGROW>
        end
    end
    if isempty(rows)
        T = [];
    else
        T = rows;
    end
end

function r = cluster_row(S, M, p, pol, idx)
    vals = S.stat;  % t-values
    % extent in each dimension
    fIdx = find(any(any(M,3),1)); tIdx = find(any(any(M,2),1)); cIdx = find(any(any(M,3),2));
    if isempty(fIdx) || isempty(tIdx) || isempty(cIdx)
        fr=[nan nan]; tr=[nan nan]; nF=0; nT=0; nC=0;
    else
        fr=[S.freq(fIdx(1)) S.freq(fIdx(end))];
        tr=[S.time(tIdx(1)) S.time(tIdx(end))];
        nF=numel(fIdx); nT=numel(tIdx); nC=numel(cIdx);
    end
    % peak t and its location
    maskVals = vals; maskVals(~M) = 0;
    if strcmp(pol,'pos')
        [peakT, lin] = max(maskVals(:));
    else
        maskVals(~M) = +inf;
        [peakT, lin] = min(maskVals(:));
    end
    if isinf(peakT)
        peakT = NaN; peakChan=""; peakFreq=NaN; peakTime=NaN;
    else
        [ci,fi,ti] = ind2sub(size(vals), lin);
        peakChan = string(S.label{ci}); peakFreq = S.freq(fi); peakTime = S.time(ti);
    end
    % cluster mass
    clusterMass = sum(vals(M), 'omitnan');
    r = table( string(pol), idx, p, clusterMass, nC, nF, nT, ...
               fr(1), fr(2), tr(1), tr(2), peakT, peakChan, peakFreq, peakTime, ...
        'VariableNames', {'Polarity','ClusterIndex','p_value','ClusterMass','N_Channels','N_FreqBins','N_TimeBins', ...
                          'FreqMin','FreqMax','TimeMin','TimeMax','Peak_t','Peak_Channel','Peak_Freq','Peak_Time'});
end


function vme_quick_layout_qc(layout)
    figure('Color','w','Name','Layout QC'); hold on;
    % head outline if present
    if isfield(layout,'outline')
        cellfun(@(o) plot(o(:,1), o(:,2), 'k-','LineWidth',1.5), layout.outline);
    end
    % channel positions
    scatter(layout.pos(:,1), layout.pos(:,2), 40, 'filled'); axis equal;
    text(layout.pos(:,1)+0.01, layout.pos(:,2), layout.label, 'FontSize',8);
    % helper markers
    title('Layout QC — check Fp*/F* at TOP, Oz at BOTTOM, odd=LEFT, even=RIGHT');
    xlabel('x (left < 0 < right)'); ylabel('y (bottom < 0 < top)');
    grid on; box on;
end


