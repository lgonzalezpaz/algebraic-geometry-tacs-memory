%% ============================================================
%  VMT — temporal order judgment task recall part EEG-TFR pipeline.
%  all epochs are included, both correctlly recalled and not recalled
%  Requires: FieldTrip (ft_defaults), EEGLAB on path helps but not required
% Last update: 09.06.2026
%  ------------------------------------------------------------
%  What it does:
%   - Epochs all clean trial markers (−2..+3 s)
%   - TFR (Morlet) with variable cycles (3→10 across 1–48 Hz)
%   - Baseline (−0.5..0 s)
%   - Saves per-session TFR and (optional) post-pre differences
%  ------------------------------------------------------------
%% =========================
%  USER PATHS & PARAMETERS
%  =========================
clear; clc;

% --- Core paths ---
rootTaskData    = '<PROJECT_ROOT>\...';
eegProcDir      = fullfile(rootTaskData, '...');   
sessionOrderXLS = fullfile(rootTaskData, '...');  
eegFileSuffix = '_vmt_afterICAremoval_CLEAN.set';
elecFile        = '<EEGLAB_ROOT>\plugins\dipfit\standard_BEM\elec\standard_1005.elc';

% --- FieldTrip ---
% addpath('C:\toolboxes\fieldtrip');  % <- EDIT to your FT path
% ft_defaults;

% --- Channels ---
eegChans = {'AF3','F5','F1','FC3','CP3','P5','P1','PO3', ...
            'AF4','F6','F2','FC4','CP4','P6','P2','PO4'};  
eogChans = {'VEOG','HEOG'};  
allChans = [eegChans, eogChans];

% --- Epoching ---
tPre  = 2.0;    
tPost = 3.0;    
blWin = [-0.5 0];  

% --- Time-frequency (Morlet) ---
foi = 3:1:48;                 
toi = -1.5:0.02:2.8;          
cyclesMin = 3; cyclesMax = 10;
cyclesVec = linspace(cyclesMin, cyclesMax, numel(foi)); % 1 Hz gets ~3 cycles (=3 s);

pairMarkerCode  = 6;     % marker number for pair presentation (S6)

% --- Output ---
tfrOutDir = fullfile(rootTaskData, 'vmt_DERIVATIVES_TFR_CLEAN_3-48Hz');
if ~exist(tfrOutDir,'dir'), mkdir(tfrOutDir); end

ITFminus1_range = 1:23;    % 001..023
ITFplus1_range  = 26:48;   % 026..048


%% =========================
%  LOAD SESSION ORDER (Excel)
%  =========================
assert(isfile(sessionOrderXLS), 'Session order Excel not found: %s', sessionOrderXLS);

opts = detectImportOptions(sessionOrderXLS);
opts = setvaropts(opts, opts.VariableNames, ...
                  'WhitespaceRule','preserve', 'EmptyFieldRule','auto');

sessOrder = readtable(sessionOrderXLS, opts);  % <-- no 'TextType' here

for vn = sessOrder.Properties.VariableNames
    col = sessOrder.(vn{1});
    if iscellstr(col) || isstring(col) || iscategorical(col)
        sessOrder.(vn{1}) = strtrim(string(col));
    end
end

sessOrder.Properties.VariableNames = lower(sessOrder.Properties.VariableNames);

needCols = ["subject_id","session01","session02","session03","session04","session05","session06"];
missing  = setdiff(needCols, string(sessOrder.Properties.VariableNames));
assert(isempty(missing), 'Missing columns in session order: %s', strjoin(missing, ', '));

fprintf('Loaded session order for %d subjects.\n', height(sessOrder));


%% ===================================================
%  MAIN: loop over subjects & sessions, build epochs,
%        run TFR (variable cycles), baseline, save
%  ===================================================

trialLog = struct( ...
    'subject',         {}, ...
    'sessionIdx',      {}, ...
    'tag',             {}, ...
    'n_trials',        {}, ...
    'eegFile',         {}, ...
    'included',        {}, ...
    'exclude_reason',  {} );

subjects = sessOrder.subject_id;    
if ~isstring(subjects), subjects = string(subjects); end

% Use this for to calculate specific subjects in the folder
% subjects = intersect(string(sessOrder.subject_id), compose("%03d", 26:48), 'stable');

for si = 1:numel(subjects)
    subjID = subjects(si);
    if strlength(subjID)==1, subjID = "00"+subjID; elseif strlength(subjID)==2, subjID = "0"+subjID; end

    row = sessOrder(sessOrder.subject_id == subjID, :);
    if isempty(row)
        warning('Subject %s not found in session order, skipping.', subjID);
        continue;
    end

    fprintf('\n===== SUBJECT %s =====\n', subjID);
    for sIdx = 1:6
        tag = row.(sprintf('session%02d', sIdx));   % apre/apost/... etc.
        if strlength(tag)==0
            warning('Subject %s session%02d has empty tag, skipping.', subjID, sIdx);
            continue;
        end

        % EEG file (EEGLAB .set)
        eegFile = fullfile(eegProcDir, sprintf('t%s%s%s', subjID, tag, eegFileSuffix));
        if ~isfile(eegFile)
            warning('EEG file not found: %s (skip this session)', eegFile);
            continue;
        end

        fprintf('Subj %s | session%02d (%s)\n', subjID, sIdx, tag);
        fprintf('  EEG: %s\n', eegFile);
        
        %% ---------------------------------------
        %  Define trials (ALL PAIR PRESENTATIONS: S6)
        %  ---------------------------------------
        cfg = [];
        cfg.trialfun               = 'vmt_trialfun_pairs';  
        cfg.dataset                = eegFile;
        cfg.trialdef.dataset       = eegFile;
        cfg.trialdef.prestim       = tPre;
        cfg.trialdef.poststim      = tPost;
        cfg.trialdef.pairCode      = pairMarkerCode;        % = 6

        try
            cfg = ft_definetrial(cfg);
        catch ME
            warning('ft_definetrial failed: %s', ME.message);
            continue;
        end
        if isempty(cfg.trl)
            warning('No pair trials (S%d) found for %s session%02d', pairMarkerCode, subjID, sIdx);
            continue;
        end

        minTrials = 10;
        
        nTrials = size(cfg.trl,1);
        fprintf('  Trials: %d pair epochs (S%d)\n', nTrials, pairMarkerCode);
        
        % Decide inclusion
        included = true;
        exclude_reason = "";
        
        if nTrials < minTrials
            included = false;
            exclude_reason = sprintf("too_few_trials_<%d", minTrials);
        end
        
        trialLog(end+1) = struct( ...
            'subject',        subjID, ...
            'sessionIdx',     sIdx, ...
            'tag',            char(tag), ...
            'n_trials',       nTrials, ...
            'eegFile',        eegFile, ...
            'included',       included, ...
            'exclude_reason', char(exclude_reason) );
        
        if ~included
            warning('Exclude %s session%02d (%s): %s', subjID, sIdx, tag, exclude_reason);
            continue;
        end



        %% -----------------------------
        %  Preprocess & select channels
        %  -----------------------------
        cfgPre              = [];
        cfgPre.dataset      = eegFile;
        cfgPre.trl          = cfg.trl;
        cfgPre.demean       = 'yes';
        cfgPre.baselinewindow = blWin;  
        cfgPre.channel      = allChans; 
        data = ft_preprocessing(cfgPre);

        haveChans = string(data.label);
        keepEEG   = haveChans(ismember(haveChans, string(eegChans)));
        if isempty(keepEEG)
            warning('No matching EEG channels found in data; found: %s', strjoin(cellstr(haveChans), ', '));
            continue;
        end
        cfgSel = [];
        cfgSel.channel = cellstr(keepEEG);
        dataEEG = ft_selectdata(cfgSel, data);



        %% ---- Save epoched EEG as EEGLAB .set metadata ----
        epochDir = fullfile(rootTaskData, '...');
        if ~exist(epochDir,'dir'), mkdir(epochDir); end
        

        condLetter = lower(extractBefore(tag, 2));   % 'a'|'b'|'c'
        timepoint  = lower(extractAfter(tag, 1));    % 'pre'|'post'
        if isempty(condLetter) || isempty(timepoint)
            warning('Could not parse tag "%s" into condition/timepoint, falling back.', tag);
            condLetter = char(tag); timepoint = 'na';
        end
        

        subjNum = str2double(subjID);
        if ismember(subjNum, 1:23)
            groupLabel = 'ITF-1';
        elseif ismember(subjNum, 26:48)
            groupLabel = 'ITF+1';
        else
            groupLabel = 'NA';
        end
        
        EEG_ep = fieldtrip2eeglab(data);  
        EEG_ep = eeg_checkset(EEG_ep);
        
        try
            EEG_ep = pop_chanedit(EEG_ep, 'lookup', elecFile);
        catch
            warning('Could not (re)lookup chanlocs for epoched file.');
        end
        

        EEG_ep.subject   = char(subjID);           % e.g., '037'
        EEG_ep.group     = groupLabel;             % 'ITF-1' or 'ITF+1'
        EEG_ep.condition = condLetter;             % factor level: 'a'|'b'|'c'
        EEG_ep.session   = strcmp(timepoint,'post') + 1;
        
        EEG_ep.setname   = sprintf('t%s_%s-%s_vmt_epoched', subjID, condLetter, timepoint);
        
        % --- Save .set ---
        epochSetName = sprintf('t%s_%s-%s_vmt_epoched.set', subjID, condLetter, timepoint);
        pop_saveset(EEG_ep, 'filename', epochSetName, 'filepath', epochDir);
        fprintf('  Saved epoched set: %s | subj=%s group=%s cond=%s time=%s session=%d\n', ...
            fullfile(epochDir, epochSetName), EEG_ep.subject, EEG_ep.group, EEG_ep.condition, EEG_ep.session);


        %% ------------------------------------------
        %  TFR (Morlet) with variable cycles per freq
        %  ------------------------------------------

        freqCells = cell(1, numel(foi));

        for fi = 1:numel(foi)
            fNow   = foi(fi);
            wNow   = cyclesVec(fi);

            cfgTFR = [];
            cfgTFR.method     = 'wavelet';
            cfgTFR.output     = 'pow';
            cfgTFR.foi        = fNow;             
            cfgTFR.width      = wNow;             
            cfgTFR.toi        = toi;              
            cfgTFR.keeptrials = 'yes';
            cfgTFR.pad        = 'maxperlen';      
            freqCells{fi}     = ft_freqanalysis(cfgTFR, dataEEG);
        end

        freqAll = freqCells{1};
        if numel(freqCells) > 1
            freqAll = ft_appendfreq([], freqCells{:});
        end

        cfgBL = [];
        cfgBL.baseline     = blWin;
        cfgBL.baselinetype = 'db';   % 10*log10(post/base)
        freqBL = ft_freqbaseline(cfgBL, freqAll);

        %% ---- Save per-session TFR ----
        outFile = fullfile(tfrOutDir, sprintf('tfrpow_%s_%s.mat', subjID, tag));
        meta = struct('subject', subjID, 'sessionIdx', sIdx, 'tag', tag, ...
                      'eegFile', eegFile, ...
                      'tPre', tPre, 'tPost', tPost, 'blWin', blWin, ...
                      'foi', foi, 'toi', toi, 'cyclesVec', cyclesVec);
        save(outFile, 'freqBL', 'meta', '-v7.3');
        fprintf('  Saved: %s\n', outFile);
    end
end

%% ============================================================
%  build post–pre difference TFRs for each condition
%  ------------------------------------------------------------
%  This prepares subject-level change maps (post minus pre) 
% =============================================================
doDiffs = true;
if doDiffs
    condPairs = {'a','b','c'};
    for si = 1:numel(subjects)
        subjID = subjects(si);
        if strlength(subjID)==1, subjID = "00"+subjID; elseif strlength(subjID)==2, subjID = "0"+subjID; end

        for ci = 1:numel(condPairs)
            c = condPairs{ci};
            fPre  = fullfile(tfrOutDir, sprintf('tfrpow_%s_%spre.mat',  subjID, c));
            fPost = fullfile(tfrOutDir, sprintf('tfrpow_%s_%spost.mat', subjID, c));
            if ~isfile(fPre) || ~isfile(fPost)
                fprintf('Diff skip subj %s cond %s (missing pre/post).\n', subjID, c);
                continue;
            end
            S1 = load(fPre,  'freqBL'); freqPre  = S1.freqBL;
            S2 = load(fPost, 'freqBL'); freqPost = S2.freqBL;

            diffTFR = vmt_freq_difference(freqPost, freqPre);  % local helper below
            outDiff = fullfile(tfrOutDir, sprintf('tfrdiff_%s_%s_postminuspre.mat', subjID, c));
            save(outDiff, 'diffTFR', '-v7.3');
            fprintf('  Saved diff: %s\n', outDiff);
        end
    end
end

%% =========================
%  Done
%  =========================

if ~isempty(trialLog)
    trialTbl = struct2table(trialLog);
    writetable(trialTbl, fullfile(tfrOutDir, 'trial_counts_per_session.csv'));
end


disp('All done. Ready for stats in FieldTrip (cluster-based).');



%% ======================================================================
%  LOCAL FUNCTIONS 
%  ======================================================================

function [trl, event] = vmt_trialfun_pairs(cfg)
% Build FieldTrip trl from ALL occurrences of the pair-presentation trigger (S6).
% cfg.trialdef.dataset  : path to .set
% cfg.trialdef.prestim  : seconds
% cfg.trialdef.poststim : seconds
% cfg.trialdef.pairCode : numeric code, e.g. 6 for S6

dataset  = cfg.trialdef.dataset;
prestim  = cfg.trialdef.prestim;
poststim = cfg.trialdef.poststim;

if isfield(cfg.trialdef,'pairCode')
    pairCode = cfg.trialdef.pairCode;
else
    pairCode = 6;
end

hdr   = ft_read_header(dataset);
event = ft_read_event(dataset);
Fs    = hdr.Fs;

ev_value = strings(1,numel(event));
if isfield(event, 'value')
    try
        ev_value = string({event.value});
    catch
        ev_value = strings(1,numel(event));
        for i=1:numel(event)
            if isfield(event(i),'value') && ~isempty(event(i).value)
                ev_value(i) = string(event(i).value);
            end
        end
    end
end
ev_type = string({event.type});

key = ev_value;
key(key=="") = ev_type(key=="");

if ~isfield(event,'sample') || isempty([event.sample])
    error('Event.sample is empty in %s (cannot build trials).', dataset);
end
ev_samp = double([event.sample]);

codeFromKey = nan(size(key));
for i = 1:numel(key)
    k = char(key(i));
    if contains(upper(k),'S')  % only S-markers
        tok = regexp(k, '(\d+)', 'tokens');
    else
        tok = {};
    end

    if ~isempty(tok)
        codeFromKey(i) = str2double(tok{end}{1});
    end
end

idx = find(codeFromKey == pairCode);

begS = round(ev_samp(idx) - prestim*Fs);
endS = round(ev_samp(idx) + poststim*Fs - 1);
offS = -round(prestim*Fs);

trl = [begS(:), endS(:), repmat(offS, numel(idx), 1)];

% clamp to data bounds
trl(trl(:,1) < 1, :) = [];
trl(trl(:,2) > hdr.nSamples, :) = [];

fprintf('Trialfun(pairs): %d trials from %s using pairCode=%d (Fs=%.1f, pre=%.2f, post=%.2f)\n', ...
    size(trl,1), dataset, pairCode, Fs, prestim, poststim);

if isempty(trl)
    warning('No S%d trials found. Check how triggers are stored in event.value/type.', pairCode);
end
end
