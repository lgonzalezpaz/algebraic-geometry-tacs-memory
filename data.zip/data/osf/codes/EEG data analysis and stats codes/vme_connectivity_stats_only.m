%% run_task_connectivity_stats_only 
clear; clc;

% ---- INPUT / OUTPUT PATHS ----
data_csv = '<PROJECT_ROOT>\...';
outdir   = '<PROJECT_ROOT>\...';
if ~exist(outdir,'dir'), mkdir(outdir); end

T = readtable(data_csv);

if ismember('Metric', T.Properties.VariableNames)
    T = T(string(T.Metric) == "wpli_debiased", :);
end

toCat = intersect({'SessionLabel','Group','Condition','Hemisphere','Metric','SessionLetter'}, T.Properties.VariableNames);
for c = 1:numel(toCat)
    T.(toCat{c}) = categorical(T.(toCat{c}));
end
T.Subject = string(T.Subject);

if ismember('SessionLetter', T.Properties.VariableNames)
    map = containers.Map({'a','b','c'},{'IP','AP','Sham'});  
    letters = cellstr(T.SessionLetter);
    mapped  = cell(size(letters));
    for i = 1:numel(letters)
        if isKey(map, letters{i})
            mapped{i} = map(letters{i});
        else
            mapped{i} = letters{i};  
        end
    end
    T.SessionLabel = categorical(mapped);
end

% Check Group
if ~ismember('Group', T.Properties.VariableNames)
    T.Group = categorical(repmat("UNK",height(T),1));
end

sessions = categories(T.SessionLabel);
groups   = categories(T.Group);
hemi     = categories(T.Hemisphere);
metrics  = categories(T.Metric);

nPerm = 50000; rng(13,'twister');

WITHIN = table(); BETWEEN = table(); WITHIN_SESS = table();

%% ---------- WITHIN: paired permutation (Post vs Pre) ----------
for s = 1:numel(sessions)
  for g = 1:numel(groups)
    for h = 1:numel(hemi)
      for m = 1:numel(metrics)
        subT = T(T.SessionLabel==sessions{s} & T.Group==groups{g} & ...
                 T.Hemisphere==hemi{h} & T.Metric==metrics{m}, :);
        if isempty(subT), continue; end
        piv = unstack(subT(:,{'Subject','Condition','Value'}),'Value','Condition');
        if ~all(ismember({'Pre','Post'}, piv.Properties.VariableNames)), continue; end
        piv = piv(~isnan(piv.Pre) & ~isnan(piv.Post), :);
        if height(piv) < 3, continue; end

        d  = piv.Post - piv.Pre;
        [~,p_t,~,st] = ttest(piv.Post, piv.Pre);
        cohen_dz = mean(d)/std(d);

        % permutation test (paired, sign-flip)
        t_obs = st.tstat;
        signs = sign(randn(numel(d), nPerm));
        t_perm = zeros(nPerm,1);
        for k=1:nPerm
            d_perm = d .* signs(:,k);
            t_perm(k) = mean(d_perm) / (std(d_perm)+eps) * sqrt(numel(d_perm));
        end
        p_perm = mean(abs(t_perm)>=abs(t_obs));
       
        WITHIN = [WITHIN; table( ...
          string(sessions{s}), string(groups{g}), string(hemi{h}), string(metrics{m}), height(piv), ...
          mean(piv.Pre), mean(piv.Post), mean(d), cohen_dz, p_t, p_perm, ...
          'VariableNames', {'Session','Group','Hemisphere','Metric','N','MeanPre','MeanPost','MeanDelta','CohensDz','p_t','p_perm'})];


      end
    end
  end
end

if ~iscategorical(WITHIN.Session),  WITHIN.Session  = categorical(string(WITHIN.Session)); end
if ~iscategorical(WITHIN.Metric),   WITHIN.Metric   = categorical(string(WITHIN.Metric)); end

WITHIN.q_FDR = nan(height(WITHIN),1);
for s = 1:numel(sessions)
  for m = 1:numel(metrics)
    ix = WITHIN.Session==sessions{s} & WITHIN.Metric==metrics{m};
    if any(ix)
      WITHIN.q_FDR(ix) = mafdr(WITHIN.p_perm(ix),'BHFDR','true');
    end
  end
end
writetable(WITHIN, fullfile(outdir,'...'));


%% ---------- BETWEEN: independent permutation on Δ(Post−Pre) ----------
for s = 1:numel(sessions)
  for h = 1:numel(hemi)
    for m = 1:numel(metrics)
      subS = T(T.SessionLabel==sessions{s} & T.Hemisphere==hemi{h} & T.Metric==metrics{m}, :);
      if isempty(subS), continue; end
      P = unstack(subS(:,{'Subject','Group','Condition','Value'}),'Value','Condition');
      if ~all(ismember({'Pre','Post'}, P.Properties.VariableNames)), continue; end
      P = P(~isnan(P.Pre) & ~isnan(P.Post), :);
      if isempty(P), continue; end
      P.Delta = P.Post - P.Pre;

      g1 = P(P.Group=="ITF-1",:);
      g2 = P(P.Group=="ITF+1",:);
      if height(g1)<3 || height(g2)<3, continue; end

      [~,p_t,~,st] = ttest2(g1.Delta, g2.Delta); % ITF-1 minus ITF+1
      sP = sqrt(((height(g1)-1)*var(g1.Delta) + (height(g2)-1)*var(g2.Delta)) / (height(g1)+height(g2)-2));
      MeanDiff = mean(g1.Delta) - mean(g2.Delta);     % ITF-1 - ITF+1
      hedges_g = MeanDiff / (sP+eps);

      allD = [g1.Delta; g2.Delta];
      n1 = height(g1); n2 = height(g2);
      t_obs = st.tstat;
      t_perm = zeros(nPerm,1);
      for k=1:nPerm
          idx = randperm(n1+n2);
          idx1 = idx(1:n1); idx2 = idx(n1+1:end);
          mu1 = mean(allD(idx1)); mu2 = mean(allD(idx2));
          v1  = var(allD(idx1));  v2  = var(allD(idx2));
          t_perm(k) = (mu1 - mu2) / sqrt(v1/n1 + v2/n2 + eps);   % ITF-1 - ITF+1
      end
      p_perm = mean(abs(t_perm) >= abs(t_obs));

      BETWEEN = [BETWEEN; table( ...
          string(sessions{s}), string(hemi{h}), string(metrics{m}), height(g1), height(g2), ...
          mean(g1.Delta), mean(g2.Delta), MeanDiff, hedges_g, p_t, p_perm, ...
          'VariableNames', {'Session','Hemisphere','Metric','N_ITFminus','N_ITFplus', ...
          'MeanDelta_ITFminus','MeanDelta_ITFplus','MeanDiff','Hedges_g','p_t','p_perm'})];
      
    end
  end
end

if ~iscategorical(BETWEEN.Session),  BETWEEN.Session  = categorical(string(BETWEEN.Session)); end
if ~iscategorical(BETWEEN.Metric),   BETWEEN.Metric   = categorical(string(BETWEEN.Metric)); end

BETWEEN.q_FDR = nan(height(BETWEEN),1);
for s = 1:numel(sessions)
  for m = 1:numel(metrics)
    ix = BETWEEN.Session==sessions{s} & BETWEEN.Metric==metrics{m};
    if any(ix)
      BETWEEN.q_FDR(ix) = mafdr(BETWEEN.p_perm(ix),'BHFDR','true');
    end
  end
end
writetable(BETWEEN, fullfile(outdir,'BETWEEN_Event_Theta_Encoding_IndepPermutation_Delta_0.3_2s.csv'));


%% ---------- WITHIN-GROUP Between-Session (paired on Δ(Post−Pre)) ----------
% For each Group × Hemisphere × Metric, compare session pairs (AP vs IP, AP vs Sham, IP vs Sham)
sessionPairs = {'AP','IP'; 'AP','Sham'; 'IP','Sham'};

for g = 1:numel(groups)
  for h = 1:numel(hemi)
    for m = 1:numel(metrics)

      % Build subject-level Δ per session first
      DeltaBySess = containers.Map;
      SubsBySess  = containers.Map;

      for s = 1:numel(sessions)
          subS = T(T.SessionLabel==sessions{s} & T.Group==groups{g} & ...
                   T.Hemisphere==hemi{h} & T.Metric==metrics{m}, :);
          if isempty(subS), continue; end
          P = unstack(subS(:,{'Subject','Condition','Value'}),'Value','Condition');
          if ~all(ismember({'Pre','Post'}, P.Properties.VariableNames)), continue; end
          P = P(~isnan(P.Pre) & ~isnan(P.Post), :);
          if isempty(P), continue; end
          P.Delta = P.Post - P.Pre;

          DeltaBySess(sessions{s}) = P.Delta;
          SubsBySess(sessions{s})  = string(P.Subject);
      end

      % Paired comparisons across session pairs
      for sp = 1:size(sessionPairs,1)
          A = sessionPairs{sp,1}; B = sessionPairs{sp,2};
          if ~isKey(DeltaBySess, A) || ~isKey(DeltaBySess, B), continue; end

          subsA = SubsBySess(A); subsB = SubsBySess(B);
          [subsPair, ia, ib] = intersect(subsA, subsB, 'stable');
          if numel(subsPair) < 3, continue; end

          dA = DeltaBySess(A); dB = DeltaBySess(B);
          dA = dA(ia); dB = dB(ib);

          % paired difference (B - A)
          d = dB - dA;
          [~,p_t,~,st] = ttest(dB, dA);
          dz = mean(d) / (std(d)+eps);  % Cohen's dz

          % permutation (sign-flip on paired diffs)
          t_obs = st.tstat;
          signs = sign(randn(numel(d), nPerm));
          t_perm = zeros(nPerm,1);
          for k=1:nPerm
              d_perm = d .* signs(:,k);
              t_perm(k) = mean(d_perm) / (std(d_perm)+eps) * sqrt(numel(d_perm));
          end
          p_perm = mean(abs(t_perm)>=abs(t_obs));
          WITHIN_SESS = [WITHIN_SESS; table( ...
              string(groups{g}), string(hemi{h}), string(metrics{m}), ...
              string(A), string(B), numel(subsPair), ...
              mean(dA), mean(dB), mean(dB)-mean(dA), dz, p_t, p_perm, ...
              'VariableNames', {'Group','Hemisphere','Metric','SessionA','SessionB','N', ...
                               'MeanDelta_A','MeanDelta_B','MeanDiff_BminusA','CohensDz','p_t','p_perm'})];

      end
    end
  end
end

WITHIN_SESS.Group      = categorical(WITHIN_SESS.Group);
WITHIN_SESS.Hemisphere = categorical(WITHIN_SESS.Hemisphere);
WITHIN_SESS.Metric     = categorical(WITHIN_SESS.Metric);
WITHIN_SESS.SessionA   = categorical(WITHIN_SESS.SessionA);
WITHIN_SESS.SessionB   = categorical(WITHIN_SESS.SessionB);

% FDR per metric across all (Group×Hemisphere×Session-pair)
WITHIN_SESS.q_FDR = nan(height(WITHIN_SESS),1);
for m = 1:numel(metrics)
    ix = WITHIN_SESS.Metric==metrics{m};
    if any(ix)
        WITHIN_SESS.q_FDR(ix) = mafdr(WITHIN_SESS.p_perm(ix),'BHFDR','true');
    end
end
writetable(WITHIN_SESS, fullfile(outdir,'...'));

fprintf('Stats saved to: %s\n', outdir);
