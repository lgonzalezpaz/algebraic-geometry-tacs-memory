%% ============================================================
%  VME — Encoding EEG pipeline: epochs (remembered only) + TFR
%  Requires: FieldTrip (ft_defaults), EEGLAB on path helps but not required
% Last update: 20.12.2025
%  ------------------------------------------------------------
%  What it does:
%   - Reads session order from Excel (session01..06 -> apre/apost/bpre/bpost/cpre/cpost)
%   - Matches remembered_events_sessionXX.csv to EEG session
%   - Epochs only remembered-trial markers (−2..+3 s)
%   - TFR (Morlet) with variable cycles (3→10 across 1–48 Hz)
%   - Baseline (−0.5..0 s)
%   - Saves per-session TFR and (optional) post-pre differences
%  ------------------------------------------------------------
%% =========================
%  USER PATHS & PARAMETERS
%  =========================
clear; clc;

% --- Core paths (EDIT THESE) ---
rootTaskData    = '<PROJECT_ROOT>\...';
eegProcDir      = fullfile(rootTaskData, 'PROCESSED_TASK_EEG_vme');   % where .set/.fdt live
sessionOrderXLS = fullfile(rootTaskData, 'Session Order.xlsx');   % your Excel file (as shown)
taskRoot        = '<RAW_DATA_ROOT>';                  % where remembered_events live
elecFile        = '<EEGLAB_ROOT>\plugins\dipfit\standard_BEM\elec\standard_1005.elc';

% --- FieldTrip ---
% addpath('C:\toolboxes\fieldtrip');  % <- EDIT to your FT path
% ft_defaults;

% --- Channels ---
eegChans = {'AF3','F5','F1','FC3','CP3','P5','P1','PO3', ...
            'AF4','F6','F2','FC4','CP4','P6','P2','PO4'};  % 16 scalp
eogChans = {'VEOG','HEOG'};  
allChans = [eegChans, eogChans];

% --- Epoching ---
tPre  = 2.0;   
tPost = 3.0;    
blWin = [-0.5 0];  

minTrials = 10;

% --- Time-frequency (Morlet) ---
foi = 3:1:48;                 
toi = -1.5:0.02:2.8;          
cyclesMin = 3; cyclesMax = 10;
cyclesVec = linspace(cyclesMin, cyclesMax, numel(foi)); % 1 Hz gets ~3 cycles (=3 s);

% --- File naming conventions ---
eegFileSuffix = '_vme_afterICAremoval_CLEAN.set';   % t<subj3><tag> + this suffix
rememberedMarkerColumn = 'Marker';            % column in remembered_events CSV with EEG trigger codes

tfrOutDir = fullfile(rootTaskData, '...');
if ~exist(tfrOutDir,'dir'), mkdir(tfrOutDir); end

ITFminus1_range = 1:23;    % 001..023
ITFplus1_range  = 26:48;   % 026..048


%% =========================
%  LOAD SESSION ORDER (Excel)
%  =========================
assert(isfile(sessionOrderXLS), 'Session order Excel not found: %s', sessionOrderXLS);

opts = detectImportOptions(sessionOrderXLS);
opts = setvaropts(opts, opts.VariableNames, ...
                  'WhitespaceRule','preserve', 'EmptyFieldRule','auto');

sessOrder = readtable(sessionOrderXLS, opts);  % <-- no 'TextType' here

for vn = sessOrder.Properties.VariableNames
    col = sessOrder.(vn{1});
    if iscellstr(col) || isstring(col) || iscategorical(col)
        sessOrder.(vn{1}) = strtrim(string(col));
    end
end

sessOrder.Properties.VariableNames = lower(sessOrder.Properties.VariableNames);

needCols = ["subject_id","session01","session02","session03","session04","session05","session06"];
missing  = setdiff(needCols, string(sessOrder.Properties.VariableNames));
assert(isempty(missing), 'Missing columns in session order: %s', strjoin(missing, ', '));

fprintf('Loaded session order for %d subjects.\n', height(sessOrder));


%% ===================================================
%  MAIN: loop over subjects & sessions, build epochs,
%        run TFR (variable cycles), baseline, save
%  ===================================================

trialLog = struct( ...
    'subject',    {}, ...
    'sessionIdx', {}, ...
    'tag',        {}, ...
    'n_trials',   {}, ...
    'eegFile',    {}, ...
    'remCSV',     {} );


subjects = sessOrder.subject_id;    
if ~isstring(subjects), subjects = string(subjects); end

% subjects = intersect(string(sessOrder.subject_id), compose("%03d", 26:48), 'stable');

for si = 1:numel(subjects)
    subjID = subjects(si);
    if strlength(subjID)==1, subjID = "00"+subjID; elseif strlength(subjID)==2, subjID = "0"+subjID; end

    row = sessOrder(sessOrder.subject_id == subjID, :);
    if isempty(row)
        warning('Subject %s not found in session order, skipping.', subjID);
        continue;
    end

    fprintf('\n===== SUBJECT %s =====\n', subjID);
    for sIdx = 1:6
        tag = row.(sprintf('session%02d', sIdx));   % apre/apost/... etc.
        if strlength(tag)==0
            warning('Subject %s session%02d has empty tag, skipping.', subjID, sIdx);
            continue;
        end

        % EEG file (EEGLAB .set)
        eegFile = fullfile(eegProcDir, sprintf('t%s%s%s', subjID, tag, eegFileSuffix));
        if ~isfile(eegFile)
            warning('EEG file not found: %s (skip this session)', eegFile);
            continue;
        end

        % Remembered-events CSV for this session
        remCSV  = fullfile(taskRoot, subjID, sprintf('%s_Task', subjID), ...
                           sprintf('remembered_events_session%02d.csv', sIdx));
        if ~isfile(remCSV)
            warning('Remembered CSV missing: %s (skip this session)', remCSV);
            continue;
        end

        fprintf('Subj %s | session%02d (%s)\n', subjID, sIdx, tag);
        fprintf('  EEG: %s\n  REM: %s\n', eegFile, remCSV);

        %% ---------------------------------------
        %  Define trials (remembered markers only)
        %  ---------------------------------------
        cfg = [];
        cfg.trialfun               = 'vme_trialfun_remembered'; 
        cfg.dataset                = eegFile;                    
        cfg.trialdef.dataset       = eegFile;                   
        cfg.trialdef.remcsv        = remCSV;
        cfg.trialdef.prestim       = tPre;
        cfg.trialdef.poststim      = tPost;
        cfg.trialdef.markerCol     = rememberedMarkerColumn;
        try
            cfg = ft_definetrial(cfg);
        catch ME
            warning('ft_definetrial failed: %s', ME.message);
            continue;
        end
        
        if isempty(cfg.trl)
            warning('No remembered trials found for %s session%02d', subjID, sIdx);
            continue;
        end
        
        nTrials = size(cfg.trl,1);
        
        if nTrials < minTrials
            warning('Only %d remembered trials for %s session%02d (%s) < minTrials=%d, skipping session.', ...
                nTrials, subjID, sIdx, tag, minTrials);
            continue;
        end
        
        fprintf('  Trials kept: %d remembered\n', nTrials);
        
        trialLog(end+1) = struct( ...  %#ok<SAGROW>
            'subject',    subjID, ...
            'sessionIdx', sIdx, ...
            'tag',        char(tag), ...
            'n_trials',   nTrials, ...
            'eegFile',    eegFile, ...
            'remCSV',     remCSV );



        %% -----------------------------
        %  Preprocess & select channels
        %  -----------------------------
        cfgPre              = [];
        cfgPre.dataset      = eegFile;
        cfgPre.trl          = cfg.trl;
        cfgPre.demean       = 'yes';
        cfgPre.baselinewindow = blWin;  
        cfgPre.channel      = allChans; 

        data = ft_preprocessing(cfgPre);

        haveChans = string(data.label);
        keepEEG   = haveChans(ismember(haveChans, string(eegChans)));
        if isempty(keepEEG)
            warning('No matching EEG channels found in data; found: %s', strjoin(cellstr(haveChans), ', '));
            continue;
        end
        cfgSel = [];
        cfgSel.channel = cellstr(keepEEG);
        dataEEG = ft_selectdata(cfgSel, data);



        %% ---- Save epoched EEG as EEGLAB .set  metadata ----
        epochDir = fullfile(rootTaskData, '...');
        if ~exist(epochDir,'dir'), mkdir(epochDir); end
        

        condLetter = lower(extractBefore(tag, 2));   % 'a'|'b'|'c'
        timepoint  = lower(extractAfter(tag, 1));    % 'pre'|'post'
        if isempty(condLetter) || isempty(timepoint)
            warning('Could not parse tag "%s" into condition/timepoint, falling back.', tag);
            condLetter = char(tag); timepoint = 'na';
        end
        
        subjNum = str2double(subjID);
        if ismember(subjNum, 1:23)
            groupLabel = 'ITF-1';
        elseif ismember(subjNum, 26:48)
            groupLabel = 'ITF+1';
        else
            groupLabel = 'NA';
        end
        
        EEG_ep = fieldtrip2eeglab(data);  
        EEG_ep = eeg_checkset(EEG_ep);
        
        try
            EEG_ep = pop_chanedit(EEG_ep, 'lookup', elecFile);
        catch
            warning('Could not (re)lookup chanlocs for epoched file.');
        end
        
        % --- Populate STUDY-relevant fields ---
        % EEGLAB/STUDY commonly uses: subject, group, condition, session
        EEG_ep.subject   = char(subjID);           % e.g., '037'
        EEG_ep.group     = groupLabel;             % 'ITF-1' or 'ITF+1'
        % Two useful encodings (keep both):
        EEG_ep.condition = condLetter;             % factor level: 'a'|'b'|'c'
        EEG_ep.session   = strcmp(timepoint,'post') + 1;
        
        EEG_ep.setname   = sprintf('t%s_%s-%s_vme_epoched', subjID, condLetter, timepoint);
        
        % --- Save .set ---
        epochSetName = sprintf('t%s_%s-%s_vme_epoched.set', subjID, condLetter, timepoint);
        pop_saveset(EEG_ep, 'filename', epochSetName, 'filepath', epochDir);
        fprintf('  Saved epoched set: %s | subj=%s group=%s cond=%s time=%s session=%d\n', ...
            fullfile(epochDir, epochSetName), EEG_ep.subject, EEG_ep.group, EEG_ep.condition, EEG_ep.session);


        %% ------------------------------------------
        %  TFR (Morlet) with variable cycles per freq
        %  ------------------------------------------

        freqCells = cell(1, numel(foi));

        for fi = 1:numel(foi)
            fNow   = foi(fi);
            wNow   = cyclesVec(fi);

            cfgTFR = [];
            cfgTFR.method     = 'wavelet';
            cfgTFR.output     = 'pow';
            cfgTFR.foi        = fNow;           
            cfgTFR.width      = wNow;             
            cfgTFR.toi        = toi;             
            cfgTFR.keeptrials = 'yes';
            cfgTFR.pad        = 'maxperlen';      
            freqCells{fi}     = ft_freqanalysis(cfgTFR, dataEEG);
        end

        freqAll = freqCells{1};
        if numel(freqCells) > 1
            freqAll = ft_appendfreq([], freqCells{:});
        end

        cfgBL = [];
        cfgBL.baseline     = blWin;
        cfgBL.baselinetype = 'db';   % 10*log10(post/base)
        freqBL = ft_freqbaseline(cfgBL, freqAll);

        %% ---- Save per-session TFR ----
        outFile = fullfile(tfrOutDir, sprintf('tfrpow_%s_%s.mat', subjID, tag));
        meta = struct('subject', subjID, 'sessionIdx', sIdx, 'tag', tag, ...
                      'eegFile', eegFile, 'remCSV', remCSV, ...
                      'tPre', tPre, 'tPost', tPost, 'blWin', blWin, ...
                      'foi', foi, 'toi', toi, 'cyclesVec', cyclesVec);
        save(outFile, 'freqBL', 'meta', '-v7.3');
        fprintf('  Saved: %s\n', outFile);
    end
end

%% ============================================================
%  build post–pre difference TFRs for each condition
%  ------------------------------------------------------------
%  This prepares subject-level change maps (post minus pre) 
% =============================================================
doDiffs = true;
if doDiffs
    condPairs = {'a','b','c'};
    for si = 1:numel(subjects)
        subjID = subjects(si);
        if strlength(subjID)==1, subjID = "00"+subjID; elseif strlength(subjID)==2, subjID = "0"+subjID; end

        for ci = 1:numel(condPairs)
            c = condPairs{ci};
            fPre  = fullfile(tfrOutDir, sprintf('tfrpow_%s_%spre.mat',  subjID, c));
            fPost = fullfile(tfrOutDir, sprintf('tfrpow_%s_%spost.mat', subjID, c));
            if ~isfile(fPre) || ~isfile(fPost)
                fprintf('Diff skip subj %s cond %s (missing pre/post).\n', subjID, c);
                continue;
            end
            S1 = load(fPre,  'freqBL'); freqPre  = S1.freqBL;
            S2 = load(fPost, 'freqBL'); freqPost = S2.freqBL;

            diffTFR = vme_freq_difference(freqPost, freqPre);  % local helper below
            outDiff = fullfile(tfrOutDir, sprintf('tfrdiff_%s_%s_postminuspre.mat', subjID, c));
            save(outDiff, 'diffTFR', '-v7.3');
            fprintf('  Saved diff: %s\n', outDiff);
        end
    end
end

%% =========================
%  Done
%  =========================

if ~isempty(trialLog)
    trialTbl = struct2table(trialLog);
    writetable(trialTbl, fullfile(tfrOutDir, 'trial_counts_per_session.csv'));
end


disp('All done. Ready for stats in FieldTrip (cluster-based).');



%% ======================================================================
%  LOCAL FUNCTIONS 
%  ======================================================================

function [trl, event] = vme_trialfun_remembered(cfg)
% Build FieldTrip trl from remembered-events CSV using the 'Marker' column.
% cfg.trialdef.dataset  : path to .set
% cfg.trialdef.remcsv   : remembered_events_sessionXX.csv
% cfg.trialdef.prestim  : seconds
% cfg.trialdef.poststim : seconds

% --- unpack
dataset  = cfg.trialdef.dataset;
remcsv   = cfg.trialdef.remcsv;
prestim  = cfg.trialdef.prestim;
poststim = cfg.trialdef.poststim;

% --- read EEG header/events
hdr   = ft_read_header(dataset);
event = ft_read_event(dataset);
Fs    = hdr.Fs;

% ---  CSV read 
[~,~,ext] = fileparts(remcsv);
if ~isfile(remcsv)
    error('Remembered-events file not found: %s', remcsv);
end
if any(strcmpi(ext,{'.xlsx','.xls'}))
    T = readtable(remcsv);
else
    opts = detectImportOptions(remcsv, 'Delimiter', ',');
    opts.Delimiter = ',';
    if numel(opts.VariableNames) == 1
        opts.VariableNames = {'Filename','PresentationOrder','ImageOrder','Marker'};
        opts.SelectedVariableNames = opts.VariableNames;
        opts = setvartype(opts, {'Filename'}, 'string');
        opts = setvartype(opts, {'PresentationOrder','ImageOrder','Marker'}, 'double');
    end
    T = readtable(remcsv, opts);
end
T.Properties.VariableNames = lower(T.Properties.VariableNames);
if ~ismember('marker', T.Properties.VariableNames)
    error('Expected a "Marker" column in %s, got: %s', remcsv, strjoin(T.Properties.VariableNames, ', '));
end

% --- wanted markers (as numeric -> formatted like EEGLAB values 'S  1', 'S 10', ...)
mk = T.marker;
mk = mk(~isnan(mk));
mk = unique(mk(:).');
mk_labels = strings(size(mk));
for i = 1:numel(mk)
    mk_labels(i) = string(sprintf('S%3d', round(mk(i))));  % -> 'S  1','S 10','S 11'
end

% --- choose event KEY: prefer value, fallback to type
ev_value = strings(1,numel(event));
if isfield(event, 'value')
    ev_value = string({event.value});
end
ev_type = string({event.type});
key = ev_value;
key(key=="") = ev_type(key=="");    % if value empty, use type

% --- event samples (needed to build trl)
if isfield(event,'sample') && ~isempty([event.sample])
    ev_samp = double([event.sample]);
else
    error('Event.sample is empty in %s (cannot build trials).', dataset);
end

% --- keep only stimulus-like events 
isStim = contains(lower(key), "s ");     % catches 'S  1','S 10',...
key    = key(isStim);
ev_samp= ev_samp(isStim);

% ---------- NEW: boundary samples for later check ----------
bndSamples = [];
if ~isempty(event) && any(strcmpi({event.type}, 'boundary'))
    bndIdx     = strcmpi({event.type}, 'boundary');
    bndSamples = double([event(bndIdx).sample]);
end

% --- match CSV markers to EEG event values
begS = []; endS = []; offS = [];
for i = 1:numel(mk_labels)
    m = find(key == mk_labels(i), 1, 'first');  % first occurrence
    if ~isempty(m)
        s0 = ev_samp(m);
        b  = round(s0 - prestim*Fs);
        e  = round(s0 + poststim*Fs - 1);
        o  = -round(prestim*Fs);
        begS(end+1,1) = b; %#ok<AGROW>
        endS(end+1,1) = e; %#ok<AGROW>
        offS(end+1,1) = o; %#ok<AGROW>
    end
end

trl = [begS, endS, offS];

% --- clamp to data bounds
trl(trl(:,1) < 1, :) = [];
trl(trl(:,2) > hdr.nSamples, :) = [];

% ---------- remove trials that cross a boundary ----------
if ~isempty(bndSamples) && ~isempty(trl)
    keep = true(size(trl,1),1);
    for tr = 1:size(trl,1)
        if any(bndSamples >= trl(tr,1) & bndSamples <= trl(tr,2))
            keep(tr) = false;
        end
    end
    nDrop = sum(~keep);
    if nDrop > 0
        fprintf('Trialfun: dropping %d trials that cross boundary events.\n', nDrop);
    end
    trl = trl(keep,:);
end

fprintf('Trialfun: %d trials from "%s" (Fs=%.1f, pre=%.2f, post=%.2f)\n', ...
    size(trl,1), remcsv, Fs, prestim, poststim);

if isempty(trl)
    warning('No valid trials found for %s (0 epochs). Check markers vs event.value and boundary cuts.', dataset);
end
end



function T = vme_read_remembered_table(csvPath)

    [~,~,ext] = fileparts(csvPath);
    if any(strcmpi(ext,{'.xlsx','.xls'}))
        opts = detectImportOptions(csvPath);
        T    = readtable(csvPath, opts);
    else
        opts = detectImportOptions(csvPath, 'NumHeaderLines',0);
        T    = readtable(csvPath, opts);
    end

    for vn = T.Properties.VariableNames
        col = T.(vn{1});
        if iscellstr(col) || isstring(col) || iscategorical(col)
            T.(vn{1}) = strtrim(string(col));
        end
    end
end

function out = vme_try_numeric(strVec)
    out = nan(size(strVec));
    for i = 1:numel(strVec)
        x = str2double(strVec(i));
        if ~isnan(x), out(i) = x; end
    end
end

function diffTFR = vme_freq_difference(freqPost, freqPre)
% Average-then-subtract difference on TFR structs (dB units)
% Produces a single averaged map: chan × freq × time (no trial dimension).

    % ---- sanity checks (same axes & channels) ----
    assert(isequal(freqPost.freq, freqPre.freq), 'freq axis differs between post and pre');
    assert(isequal(freqPost.time, freqPre.time), 'time axis differs between post and pre');
    assert(isequal(freqPost.label, freqPre.label), 'channel labels differ between post and pre');

    % ---- average across trials in each session ----
    % freq.powspctrm is rpt × chan × freq × time when keeptrials='yes'
    postAvg = squeeze(mean(freqPost.powspctrm, 1));   % chan × freq × time
    preAvg  = squeeze(mean(freqPre.powspctrm,  1));   % chan × freq × time

    % ---- post - pre (in dB) ----
    diffTFR            = struct();
    diffTFR.label      = freqPost.label;
    diffTFR.freq       = freqPost.freq;
    diffTFR.time       = freqPost.time;
    diffTFR.powspctrm  = postAvg - preAvg;            % chan × freq × time
    diffTFR.dimord     = 'chan_freq_time';
    diffTFR.cfg        = [];                          
end
