%% ============================================================
%  Manual continuous cleaning on *_afterICAremoval.set
%  - Open each dataset
%  - Mark bad segments in eegplot
%  - Apply cuts
%  - Save as *_afterICAremoval_CLEAN.set
% ============================================================

clear; clc;

% ===== EDIT THESE =====
% Folder where your tSUBJTAG_vmt_afterICAremoval.set live
procRoot = '<Path>';

% Subjects you want to clean
% Example: 001–048
subjects = compose('%03d', 1:48);   % or e.g. subjects = ["001" "008" "023"];

% Tags / sessions you used
tags = {'apre','apost','bpre','bpost','cpre','cpost'};

% ======================
[ALLEEG, EEG, CURRENTSET, ALLCOM] = eeglab; %#ok<ASGLU>

for si = 1:numel(subjects)
    subj = char(subjects(si));

    for ti = 1:numel(tags)
        tag = tags{ti};

        inName = sprintf('t%s%s_vmt_afterICAremoval.set', subj, tag);
        inPath = fullfile(procRoot, inName);

        if ~exist(inPath, 'file')
            fprintf('Skipping (file not found): %s\n', inPath);
            continue;
        end

        fprintf('\n===============================\n');
        fprintf(' Subject %s | %s\n', subj, tag);
        fprintf(' Loading: %s\n', inPath);

        EEG = pop_loadset('filename', inName, 'filepath', procRoot);
        [ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, 1); %#ok<NASGU>

        %% ----- Continuous inspection -----
        % Mark bad segments in the eegplot window (click-drag),
        % then press "update marks" and CLOSE the window.

        pop_eegplot(EEG, 1, 1, 1);
        title(sprintf('t%s%s_vmt_afterICAremoval — mark bad segments, then close', subj, tag));
        uiwait(gcf);   % wait until you close the eegplot window

        %% ----- Apply marked rejections (TMPREJ) -----
        if evalin('base','exist(''TMPREJ'',''var'')')
            TMPREJ = evalin('base','TMPREJ');  % [nSeg x 7] matrix

            if ~isempty(TMPREJ)
                EEG = eeg_eegrej(EEG, TMPREJ);  % remove segments + insert boundary
                EEG = eeg_checkset(EEG);
                fprintf('  Applied %d rejected segments. New length: %.1f s\n', ...
                    size(TMPREJ,1), EEG.pnts/EEG.srate);
            else
                fprintf('  No segments marked. Keeping full data.\n');
            end

            evalin('base','clear TMPREJ');
        else
            fprintf('  No TMPREJ found. Assuming no cuts.\n');
        end

        %% ----- Save CLEAN dataset -----
        outName = sprintf('t%s%s_vmt_afterICAremoval_CLEAN.set', subj, tag);
        EEG.setname = sprintf('t%s%s_vmt_afterICAremoval_CLEAN', subj, tag);

        EEG = pop_saveset(EEG, 'filename', outName, 'filepath', procRoot);
        fprintf('  Saved CLEAN file: %s\n', fullfile(procRoot, outName));
    end
end

disp('All subjects/sessions processed (where files existed).');
