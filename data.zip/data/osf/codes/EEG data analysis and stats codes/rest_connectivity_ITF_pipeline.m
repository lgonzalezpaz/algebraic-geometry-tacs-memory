function rest_connectivity_ITF_pipeline()
% REST_CONNECTIVITY_ITF_PIPELINE
% ------------------------------------------------------------
% Computes resting connectivity at ITF±1.5 Hz using FieldTrip:
%   - Phase-based: debiased wPLI
% Aggregates ROI->ROI:
%   LF={AF3,F5,F1,FC3}  LP={CP3,P5,P1,PO3}
%   RF={AF4,F6,F2,FC4}  RP={CP4,P6,P2,PO4}
%
% INPUTS (set in "USER SETTINGS"):
%   - Folder of *_preprocessed_data.set (epoched)
%   - ITFFreq.xlsx with columns: SubjectNo, a_ITF, b_ITF, c_ITF
%   - Optional RestMeta.xlsx with: Subject, SessionLetter, SessionLabel, Group
%
% OUTPUTS:
%   - RestConnectivity_ITFcentered_PrePost.csv 
% ------------------------------------------------------------

%% -------------------- USER SETTINGS -----------------------
data_folder = '<PROJECT_ROOT>\...';
itf_table   = 'ITFFreq.xlsx';   % SubjectNo, a_ITF, b_ITF, c_ITF
meta_table  = 'RestMeta.xlsx';  % OPTIONAL: Subject, SessionLetter (a/b/c), SessionLabel (IP/AP/Sham), Group (ITF-1/ITF+1)
outdir      = fullfile(fileparts(data_folder), 'stat', 'RestConnectivity');
if ~exist(outdir,'dir'), mkdir(outdir); end
out_csv     = fullfile(data_folder,'...');

itf_halfwidth = 1.5;    % ITF ± 1.5 Hz
tapsmofrq     = 1.0;    % DPSS smoothing (Hz) for mtmfft
min_trials    = 10;      % min #epochs to include
nPerm         = 50000;  % permutation iterations

% ROIs
LF = {'AF3','F5','F1','FC3'};   LP = {'CP3','P5','P1','PO3'};
RF = {'AF4','F6','F2','FC4'};   RP = {'CP4','P6','P2','PO4'};
roiPairs = { {'LF','LP',LF,LP}, {'RF','RP',RF,RP} };

% connectivity metric
do_wpli = true;
%% ------------------- LIBS & FILES -------------------------
eeglab; %#ok<*NOPTS>
ft_defaults;

files = dir(fullfile(data_folder, '*_preprocessed_data.set'));
if isempty(files), error('No .set files found in %s', data_folder); end

ITF = readtable(itf_table,'ReadVariableNames',true);
needITF = {'SubjectNo','a_ITF','b_ITF','c_ITF'};
if ~all(ismember(needITF, ITF.Properties.VariableNames))
    error('ITFFreq.xlsx must contain columns: %s', strjoin(needITF,', '));
end

hasMeta = exist(fullfile(data_folder, meta_table),'file')==2 || exist(meta_table,'file')==2;
if hasMeta
    META = readtable(meta_table);
    needMeta = {'Subject','SessionLetter','SessionLabel','Group'};
    if ~all(ismember(needMeta, META.Properties.VariableNames))
        warning('RestMeta.xlsx found but missing some of: %s. Proceeding without meta.', strjoin(needMeta,', '));
        hasMeta = false;
    end
end

all_needed = unique([LF,LP,RF,RP]);

%% ----------------- CONNECTIVITY EXTRACTION ----------------
RES = table(); % Subject, SessionLetter, Condition, Hemisphere, Metric, Value, [SessionLabel, Group]

for iFile = 1:numel(files)
    fname = files(iFile).name;
    fpath = fullfile(files(iFile).folder, fname);

    % Parse t(\d+)([abc])(pre|post)_preprocessed_data.set
    tok = regexp(fname, '^t(\d+)([abc])(pre|post)_preprocessed_data\.set$', 'tokens','once');
    if isempty(tok), fprintf('Skip non-matching: %s\n', fname); continue; end
    subjStr = tok{1}; sessLet = tok{2}; cond = lower(tok{3});
    if strcmp(cond,'pre'),  Condition = "Pre"; else, Condition = "Post"; end

    % Robust load
    S = []; loadedFromMat = false;
    try
        S = load(fpath,'-mat'); loadedFromMat = isfield(S,'EEG');
    catch, loadedFromMat = false;
    end
    if loadedFromMat, EEG = S.EEG; else, EEG = pop_loadset('filename',fname,'filepath',files(iFile).folder); end

    % Epoch check
    if ndims(EEG.data) < 3
        fprintf('Not epoched in %s. Skipping.\n', fname); continue;
    end
    nEp = size(EEG.data,3);
    if nEp < min_trials
        fprintf('Too few epochs (n=%d) in %s. Skipping.\n', nEp, fname); continue;
    end

    % Channel presence
    labs = string({EEG.chanlocs.labels});
    [tf_keep, idx_keep] = ismember(all_needed, cellstr(labs));
    if ~all(tf_keep)
        miss = all_needed(~tf_keep);
        fprintf('Missing needed chans in %s: %s. Skipping.\n', fname, strjoin(miss,', ')); continue;
    end

    % ITF for this subject/session
    rowMask = ITF.SubjectNo == str2double(subjStr);
    if ~any(rowMask)
        fprintf('No ITF row for subject %s. Skipping.\n', subjStr); continue;
    end
    switch sessLet
        case 'a', ITF_subj = ITF.a_ITF(rowMask);
        case 'b', ITF_subj = ITF.b_ITF(rowMask);
        case 'c', ITF_subj = ITF.c_ITF(rowMask);
    end
    if isnan(ITF_subj) || ITF_subj<=0
        fprintf('Invalid ITF for t%s(%s). Skipping.\n', subjStr, sessLet); continue;
    end
    fwin = [ITF_subj-itf_halfwidth, ITF_subj+itf_halfwidth];

    % Build FT data (ROI channels only)
    keepLabs = unique([LF,LP,RF,RP]);
    [tfK, idxK] = ismember(keepLabs, cellstr(labs));
    data = [];
    data.label   = keepLabs(:);
    data.fsample = EEG.srate;
    data.trial   = cell(1,nEp);
    data.time    = cell(1,nEp);
    for ep = 1:nEp
        x = double(EEG.data(idxK(tfK),:,ep)); % chan x time
        data.trial{ep} = x;
        data.time{ep}  = (0:size(x,2)-1)/EEG.srate;
    end

    % Spectral estimation (Fourier per trial)
    cfg = [];
    cfg.method     = 'mtmfft';
    cfg.taper      = 'dpss';
    cfg.tapsmofrq  = tapsmofrq;
    cfg.output     = 'fourier';
    cfg.keeptrials = 'yes';
    cfg.foilim     = fwin;
    freq = ft_freqanalysis(cfg, data); % fourierspctrm: trials x chan x freq

    % Connectivity metrics
    metric_out = struct();

    if do_wpli
        cfgc = []; cfgc.method = 'wpli_debiased';
        C = ft_connectivityanalysis(cfgc, freq);
        [M, lab] = getConnMatrix(C);  % chan x chan x freq
        metric_out.wpli_debiased = struct('M',M,'label',{lab});
    end

    % ROI→ROI aggregation (mean over edges & freqs)
    roiMean = @(M,lab,roiA,roiB) mean( reshape( M(ismember(lab,roiA), ismember(lab,roiB), :), [], 1 ), 'omitnan');

    metricNames = fieldnames(metric_out);
    for m = 1:numel(metricNames)
        X = metric_out.(metricNames{m});
        for p = 1:numel(roiPairs)
            hemiName = sprintf('%s2%s', roiPairs{p}{1}, roiPairs{p}{2}); % e.g., LF2LP
            roiA = roiPairs{p}{3}; roiB = roiPairs{p}{4};
            val = roiMean(X.M, X.label, roiA, roiB);
            if isnan(val), continue; end

            newrow = table( ...
                string(subjStr), string(sessLet), string(Condition), ...
                string(hemiName), string(metricNames{m}), double(val), ...
                'VariableNames', {'Subject','SessionLetter','Condition','Hemisphere','Metric','Value'});
            RES = [RES; newrow]; %#ok<AGROW>
        end
    end
end

% Attach SessionLabel/Group if available
if hasMeta
    RES = outerjoin(RES, META, 'Keys',{'Subject','SessionLetter'}, 'MergeKeys', true, 'Type','left');
end

% Save long table
writetable(RES, out_csv);
fprintf('Saved connectivity table: %s\n', out_csv);

end

%% ===================== HELPERS ============================
function [mat, labels] = getConnMatrix(C)

    if ~isstruct(C) || ~isfield(C,'label')
        error('Connectivity struct missing labels.');
    end
    labels = C.label;

    % 1) Try known field names first (covers most FT versions)
    known = {'wplispctrm','cohspctrm','plvspctrm','ppcspctrm','powcorrspctrm', ...
             'wpli_debiasedspctrm','wplidebiasedspctrm','corrspctrm','amplcorrspctrm'};
    valField = '';
    for k = 1:numel(known)
        if isfield(C, known{k}) && isnumeric(C.(known{k}))
            valField = known{k}; break;
        end
    end

    % 2) If still not found, auto-detect any numeric "...spctrm" field
    if isempty(valField)
        fns = fieldnames(C);
        for k = 1:numel(fns)
            fn = fns{k};
            if endsWith(fn,'spctrm') && isnumeric(C.(fn))
                valField = fn; break;
            end
        end
    end

    if isempty(valField)
        error('Unknown connectivity output fields in struct. Fields were: %s', strjoin(fieldnames(C),', '));
    end

    X = C.(valField);

    % Handle label-pair (labelcmb) format by rebuilding a square matrix
    if isfield(C,'labelcmb') && ~isempty(C.labelcmb)
        nC = numel(labels);
        % X is typically (nPairs x nFreq)
        if ndims(X)==2
            nF = size(X,2);
            M = nan(nC,nC,nF);
            for r = 1:size(C.labelcmb,1)
                i = find(strcmp(labels, C.labelcmb{r,1}));
                j = find(strcmp(labels, C.labelcmb{r,2}));
                if ~isempty(i) && ~isempty(j)
                    M(i,j,:) = reshape(X(r,:),1,1,[]);
                    M(j,i,:) = reshape(X(r,:),1,1,[]);
                end
            end
            mat = M;
        else
            % If already 3-D in pair-space, squeeze to freq and rebuild similarly
            nF = size(X,3);
            M = nan(nC,nC,nF);
            for r = 1:size(C.labelcmb,1)
                i = find(strcmp(labels, C.labelcmb{r,1}));
                j = find(strcmp(labels, C.labelcmb{r,2}));
                if ~isempty(i) && ~isempty(j)
                    M(i,j,:) = squeeze(X(r,1,:));
                    M(j,i,:) = squeeze(X(r,1,:));
                end
            end
            mat = M;
        end
    else
        % Expect chan x chan x freq
        if ndims(X)==2
            % Some methods can return chan x chan (single freq). Add freq dim.
            mat = reshape(X, size(X,1), size(X,2), 1);
        else
            mat = X;
        end
    end
end
