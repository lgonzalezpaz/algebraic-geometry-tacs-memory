% ITF calculation
%restoredefaultpath

% Load EEGLAB
[ALLEEG, EEG, CURRENTSET, ALLCOM] = eeglab;


% Preprocessing steps
% 1. Bandpass filter the data (1-60 Hz)
EEG = pop_eegfiltnew(EEG, parameters.bandpass_filter(1), parameters.bandpass_filter(2), [], 0, [], 0);

% 2. Notch filter at 50 Hz
EEG = pop_eegfiltnew(EEG, parameters.notch_filter(1), parameters.notch_filter(2), [], 1, [], 0);

% Save a copy of the data before ASR for comparison
originalEEG = EEG;

% 3. Apply ASR (Artifact Subspace Reconstruction) with specified parameters
% Exclude EOG channels from being marked as bad channels
nonEOG_inds = find(~ismember({EEG.chanlocs.labels}, parameters.EOG_channels));
EEG = pop_clean_rawdata(EEG, 'FlatlineCriterion', 'off', 'ChannelCriterion', parameters.ASR(1), ...
    'LineNoiseCriterion', 'off', 'Highpass', 'off', ...
    'BurstCriterion', parameters.ASR(2), 'WindowCriterion', 'off', ...
    'BurstRejection', 'off', 'Distance', 'Euclidian', ...
    'ChannelSubset', nonEOG_inds, 'WindowCriterionTolerances', [-Inf 7]);

% % Visualize the artifacts before and after ASR
% vis_artifacts(originalEEG, EEG, 'Title', 'Comparison of Original and Cleaned Data');

% Save a copy of the data before OLS regression for comparison
EEG_before_OLS = EEG;

% 4. Handle eye artifacts using linear regression (OLS method)
EOG_inds = find(ismember({EEG.chanlocs.labels}, parameters.EOG_channels));
EOG_data = EEG.data(EOG_inds, :)';

for ch = 1:EEG.nbchan
    if ~ismember(ch, EOG_inds)
        EEG_channel_data = EEG.data(ch, :)';
        beta = EOG_data \ EEG_channel_data; % Regression coefficients
        estimated_artifact = EOG_data * beta; % Estimated EOG artifact
        EEG.data(ch, :) = (EEG_channel_data - estimated_artifact)'; % Remove artifact
    end
end



% 5. Interpolate bad channels
EEG = pop_interp(EEG, originalEEG.chanlocs, 'spherical');

% 6. Use eeg_regepochs to create equally spaced epochs
epoch_length = 5; % seconds
EEG = eeg_regepochs(EEG, 'recurrence', epoch_length, 'limits', [0 epoch_length]);
EEG = eeg_checkset(EEG);

if isempty(EEG.data)
    error('No epochs were created.');
end

fprintf('Number of epochs created: %d\n', size(EEG.data, 3));

% Save the dataset after epoching and before manual artifact rejection
EEG = eeg_checkset(EEG);
[ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, CURRENTSET);

% Manual artifact rejection on epoched data 
%Here try to not exclude if there are no so extremes
pop_eegplot(EEG, 1, 1, 1); %
disp('Please inspect the epoched data and reject artifacts manually. Press "Update Marks" to save your changes.');
uiwait(gcf); 

EEG = eeg_checkset(EEG);
[ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, CURRENTSET);


% Save preprocessed EEG data as .set file
EEG = pop_saveset(EEG, 'filename', 'preprocessed_data.set', 'filepath', '<RAW_DATA_ROOT>\...');

