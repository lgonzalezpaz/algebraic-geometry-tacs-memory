%% Group Analysis on Preprocessed .set files with Session-specific ITF
% Expects filenames like: t[subject][session][condition]_preprocessed_data.set
% Example: t004apost_preprocessed_data.set

clear; clc;
eeglab;  % Start EEGLAB

%% Parameters
parameters = struct();
parameters.itf_band_halfwidth = 1.5;          % ITF ± 1.5 Hz window
parameters.channel_location_file = ...
 '<EEGLAB_ROOT>\plugins\dipfit\standard_BEM\elec\standard_1005.elc';

% Data folder
data_folder = '<PROJECT_ROOT>\...';

% Find preprocessed EEGLAB sets
files = dir(fullfile(data_folder, '*_preprocessed_data.set'));

% Electrodes of interest
channels = {'AF3','F5','F1','FC3','CP3','P5','P1','PO3', ...
            'AF4','F6','F2','FC4','CP4','P6','P2','PO4'};

% Load ITF table (SubjectNo + a_ITF, b_ITF, c_ITF)
stimFreqTable = readtable('ITFFreq.xlsx','ReadVariableNames',true);

% Results table
results = table();

%% Loop over files
for iFile = 1:numel(files)
    ALLEEG = []; EEG = []; CURRENTSET = [];
    fname = files(iFile).name;
    fpath = fullfile(files(iFile).folder, fname);
    fprintf('Processing file: %s\n', fpath);

    % Parse filename
    pattern = '^t(\d+)([abc])(pre|post)_preprocessed_data\.set$';
    tok = regexp(fname, pattern, 'tokens');
    if isempty(tok)
        warning('Filename "%s" does not match expected pattern. Skipping.', fname);
        continue;
    end
    tok = tok{1};
    subject_code   = tok{1};   % e.g., "004"
    session_letter = tok{2};   % "a" | "b" | "c"
    condition_raw  = tok{3};   % "pre" | "post"

    % Condition (capitalize)
    if strcmpi(condition_raw,'pre')
        condition = 'Pre';
    else
        condition = 'Post';
    end

    %% Load EEG (preprocessed)
    loadedFromMat = false;
    try
        S = load(fpath, '-mat');             
        if isfield(S, 'EEG')
            EEG = S.EEG;
            loadedFromMat = true;
        end
    catch
        loadedFromMat = false;
    end

    if ~loadedFromMat
        try
            EEG = pop_loadset('filename', fname, 'filepath', files(iFile).folder);
        catch ME
            if contains(ME.message, 'not found')
                EEG = pop_loadset('filename', fname, 'filepath', files(iFile).folder, 'loadmode', 'info');
                [~, baseNoExt] = fileparts(fname);
                fdt_guess = [baseNoExt '.fdt'];
                if exist(fullfile(files(iFile).folder, fdt_guess), 'file')
                    EEG.datfile = fdt_guess;
                    EEG.filepath = files(iFile).folder;
                    EEG = eeg_checkset(EEG, 'loaddata');
                else
                    error('Could not load %s as MAT or find accompanying .fdt.', fname);
                end
            else
                rethrow(ME);
            end
        end
    end

    [ALLEEG, EEG, CURRENTSET] = eeg_store(ALLEEG, EEG, 0);

    try
        hasChanlocs = isfield(EEG,'chanlocs') && ~isempty(EEG.chanlocs) && ~isempty({EEG.chanlocs.labels});
    catch
        hasChanlocs = false;
    end
    if ~hasChanlocs && exist(parameters.channel_location_file,'file')
        EEG = pop_chanedit(EEG, 'lookup', parameters.channel_location_file);
    end

    % Channels of interest
    chan_inds = find(ismember({EEG.chanlocs.labels}, channels));
    if isempty(chan_inds)
        warning('No specified channels found in file %s. Skipping.', fname);
        continue;
    end

    % Frequency axis
    n_epochs = size(EEG.data, 3);
    n_points = size(EEG.data, 2);
    fs       = EEG.srate;
    f        = fs * (0:(n_points/2)) / n_points;  % 0..Nyquist
    hann_window = hann(n_points);

    %% --- Get ITF for this subject/session ---
    subjQuery = str2double(subject_code);
    rowMask = stimFreqTable.SubjectNo == subjQuery;
    if ~any(rowMask)
        warning('No row found for subject %s in ITFFreq.xlsx. Skipping.', subject_code);
        continue;
    end

    switch lower(session_letter)
        case 'a'
            ITF_subj = stimFreqTable.a_ITF(rowMask);
        case 'b'
            ITF_subj = stimFreqTable.b_ITF(rowMask);
        case 'c'
            ITF_subj = stimFreqTable.c_ITF(rowMask);
        otherwise
            warning('Invalid session letter "%s" for subject %s. Skipping.', session_letter, subject_code);
            continue;
    end

    if isnan(ITF_subj) || ITF_subj <= 0
        warning('Invalid ITF for subject %s session %s. Skipping.', subject_code, session_letter);
        continue;
    end

    %% Compute FFT for each epoch/channel
    P_all_epochs = zeros(n_epochs, numel(chan_inds), numel(f), 'double');
    for ep = 1:n_epochs
        for cj = 1:numel(chan_inds)
            x = double(squeeze(EEG.data(chan_inds(cj), :, ep)));
            xw = x .* hann_window';
            Y  = fft(xw);
            P2 = (abs(Y)/n_points).^2;
            P1 = P2(1:n_points/2+1);
            P1(2:end-1) = 2*P1(2:end-1);
            P_all_epochs(ep, cj, :) = P1;
        end
    end

    %% Theta metrics
    theta_range = [ITF_subj - parameters.itf_band_halfwidth, ITF_subj + parameters.itf_band_halfwidth];
    theta_inds  = find(f >= theta_range(1) & f <= theta_range(2));
    if isempty(theta_inds)
        warning('No FFT bins in [%0.2f %0.2f] Hz for subject %s session %s.', ...
                 theta_range(1), theta_range(2), subject_code, session_letter);
        continue;
    end

    for cj = 1:numel(chan_inds)
        % Average spectrum across epochs
        P_avg = squeeze(mean(P_all_epochs(:, cj, :), 1));

        % Total theta power
        theta_power = sum(P_avg(theta_inds));

        % ITF peak (max bin in band) and power
        [~, max_theta_idx] = max(P_avg(theta_inds));
        ITF_peak   = f(theta_inds(max_theta_idx));
        ITF_power  = P_avg(theta_inds(max_theta_idx));

        % Save row
        new_row = table({subject_code}, {session_letter}, {condition}, ...
            channels(ismember(channels, EEG.chanlocs(chan_inds(cj)).labels)), ...
            ITF_peak, ITF_power, theta_power, ...
            'VariableNames', {'Subject','Session','Condition','Electrode','ITF','ITF_power','Theta_power'});
        results = [results; new_row]; %#ok<AGROW>
    end

    clear EEG CURRENTSET ALLEEG
end

%% Save results
output_excel = fullfile(data_folder, '...');
writetable(results, output_excel);
fprintf('Results saved to: %s\n', output_excel);
