%% run_ITF_stats_permutation_FDR.m  
clear; clc;

data_file = '<PROJECT_ROOT>\...';
outdir    = '<PROJECT_ROOT>\...';
if ~exist(outdir,'dir'), mkdir(outdir); end

% ---------- helper: robust categorical for scalars ----------
cat1 = @(x) categorical(string(x));

% ---------- load & tidy ----------
T = readtable(data_file);
need = {'Subject','Group','SessionLabel','Condition','Electrode','ITF','Cluster'};
miss = setdiff(need, T.Properties.VariableNames);
assert(isempty(miss), 'Missing columns: %s', strjoin(miss, ', '));

T.Subject      = string(T.Subject);
T.Group        = categorical(string(T.Group));
T.SessionLabel = categorical(string(T.SessionLabel));   % IP/AP/Sham
T.Condition    = categorical(string(T.Condition));      % Pre/Post
T.Cluster      = categorical(string(T.Cluster));        % 4 regions
T = T(~isnan(T.ITF), :);

T.SessionLabel = reordercats(T.SessionLabel, {'IP','AP','Sham'});
T.Group        = reordercats(T.Group, {'ITF-1','ITF+1'});
T.Cluster      = reordercats(T.Cluster, {'LeftFrontal','LeftParietal','RightFrontal','RightParietal'});

sessions = categories(T.SessionLabel);  % cellstr
groups   = categories(T.Group);
clusters = categories(T.Cluster);

% ---------- aggregate to cluster ----------
G = groupsummary(T, {'Subject','Group','SessionLabel','Condition','Cluster'}, 'mean','ITF');
G.Properties.VariableNames{end} = 'ITF_mean';
W = unstack(G(:,{'Subject','Group','SessionLabel','Cluster','Condition','ITF_mean'}),'ITF_mean','Condition');
W = W(~isnan(W.Pre) & ~isnan(W.Post), :);
W.Delta = W.Post - W.Pre;

% ---------- permutation settings ----------
nPerm = 50000; rng(13,'twister');

%% (A) WITHIN: paired Post vs Pre
WITHIN = table();
for s = 1:numel(sessions)
  for g = 1:numel(groups)
    for c = 1:numel(clusters)
        sub = W(W.SessionLabel==sessions{s} & W.Group==groups{g} & W.Cluster==clusters{c}, :);
        if height(sub) < 3, continue; end
        d = sub.Post - sub.Pre;

        [~,p_t,~,st] = ttest(sub.Post, sub.Pre);
        dz = mean(d) / (std(d)+eps);

        t_obs = st.tstat;
        signs = sign(randn(numel(d), nPerm));
        t_perm = zeros(nPerm,1);
        for k = 1:nPerm
            d_perm = d .* signs(:,k);
            t_perm(k) = mean(d_perm) / (std(d_perm)+eps) * sqrt(numel(d_perm));
        end
        p_perm = mean(abs(t_perm) >= abs(t_obs));

        WITHIN = [WITHIN; table( ...
            cat1(sessions{s}), cat1(groups{g}), cat1(clusters{c}), ...
            height(sub), mean(sub.Pre), mean(sub.Post), mean(d), dz, p_t, p_perm, ...
            'VariableNames', {'Session','Group','Cluster','N','MeanPre','MeanPost','MeanDelta','CohensDz','p_t','p_perm'})];
    end
  end
end

% FDR per Session
WITHIN.q_FDR = nan(height(WITHIN),1);
for s = 1:numel(sessions)
    ix = WITHIN.Session==sessions{s};
    if any(ix), WITHIN.q_FDR(ix) = mafdr(WITHIN.p_perm(ix),'BHFDR','true'); end
end
writetable(WITHIN, fullfile(outdir,'ITF_WITHIN_PairedPermutation.csv'));

%% (B) BETWEEN: independent on Δ(Post−Pre) between groups
BETWEEN = table();
for s = 1:numel(sessions)
  for c = 1:numel(clusters)
      sub = W(W.SessionLabel==sessions{s} & W.Cluster==clusters{c}, :);
      if isempty(sub), continue; end
      g1 = sub(sub.Group=="ITF-1",:); g2 = sub(sub.Group=="ITF+1",:);
      if height(g1)<3 || height(g2)<3, continue; end

      [~,p_t,~,st] = ttest2(g2.Delta, g1.Delta);
      sP = sqrt(((height(g1)-1)*var(g1.Delta) + (height(g2)-1)*var(g2.Delta)) / (height(g1)+height(g2)-2));
      hedges_g = (mean(g2.Delta)-mean(g1.Delta)) / (sP+eps);

      allD = [g2.Delta; g1.Delta];
      n2 = height(g2); n1 = height(g1);
      t_obs = st.tstat; t_perm = zeros(nPerm,1);
      for k = 1:nPerm
          idx = randperm(n1+n2);
          idx2 = idx(1:n2); idx1 = idx(n2+1:end);
          mu2 = mean(allD(idx2)); mu1 = mean(allD(idx1));
          v2 = var(allD(idx2));   v1 = var(allD(idx1));
          t_perm(k) = (mu2 - mu1) / sqrt(v2/n2 + v1/n1 + eps);
      end
      p_perm = mean(abs(t_perm) >= abs(t_obs));

      BETWEEN = [BETWEEN; table( ...
        cat1(sessions{s}), cat1(clusters{c}), ...
        height(g1), height(g2), ...
        mean(g1.Delta), mean(g2.Delta), (mean(g2.Delta)-mean(g1.Delta)), hedges_g, p_t, p_perm, ...
        'VariableNames', {'Session','Cluster','N_ITFminus','N_ITFplus', ...
                          'MeanDelta_ITFminus','MeanDelta_ITFplus','MeanDiff','Hedges_g','p_t','p_perm'})];
  end
end

BETWEEN.q_FDR = nan(height(BETWEEN),1);
for s = 1:numel(sessions)
    ix = BETWEEN.Session==sessions{s};
    if any(ix), BETWEEN.q_FDR(ix) = mafdr(BETWEEN.p_perm(ix),'BHFDR','true'); end
end
writetable(BETWEEN, fullfile(outdir,'ITF_BETWEEN_IndepPermutation_Delta.csv'));

%% (C) WITHIN-GROUP between-session (paired on Δ): AP–IP, AP–Sham, IP–Sham
sessionPairs = {'AP','IP'; 'AP','Sham'; 'IP','Sham'};
WITHIN_SESS = table();

for g = 1:numel(groups)
  for c = 1:numel(clusters)
      DeltaBySess = containers.Map; SubsBySess = containers.Map;
      for s = 1:numel(sessions)
          subS = W(W.SessionLabel==sessions{s} & W.Group==groups{g} & W.Cluster==clusters{c}, :);
          if isempty(subS), continue; end
          DeltaBySess(char(sessions{s})) = subS.Delta;
          SubsBySess(char(sessions{s}))  = subS.Subject;
      end

      for sp = 1:size(sessionPairs,1)
          A = sessionPairs{sp,1}; B = sessionPairs{sp,2};
          if ~isKey(DeltaBySess,A) || ~isKey(DeltaBySess,B), continue; end
          subsA = SubsBySess(A); subsB = SubsBySess(B);
          [subsPair, ia, ib] = intersect(subsA, subsB, 'stable');
          if numel(subsPair) < 3, continue; end

          dA = DeltaBySess(A); dB = DeltaBySess(B); dA = dA(ia); dB = dB(ib);
          d  = dB - dA;
          [~,p_t,~,st] = ttest(dB, dA);
          dz = mean(d) / (std(d)+eps);

          t_obs = st.tstat; t_perm = zeros(nPerm,1);
          signs = sign(randn(numel(d), nPerm));
          for k = 1:nPerm
              d_perm = d .* signs(:,k);
              t_perm(k) = mean(d_perm) / (std(d_perm)+eps) * sqrt(numel(d_perm));
          end
          p_perm = mean(abs(t_perm) >= abs(t_obs));

          WITHIN_SESS = [WITHIN_SESS; table( ...
              cat1(groups{g}), cat1(clusters{c}), cat1(A), cat1(B), ...
              numel(subsPair), mean(dA), mean(dB), mean(dB)-mean(dA), dz, p_t, p_perm, ...
              'VariableNames', {'Group','Cluster','SessionA','SessionB','N', ...
                                'MeanDelta_A','MeanDelta_B','MeanDiff_BminusA','CohensDz','p_t','p_perm'})];
      end
  end
end

WITHIN_SESS.q_FDR = mafdr(WITHIN_SESS.p_perm,'BHFDR','true');
writetable(WITHIN_SESS, fullfile(outdir,'...'));

fprintf('ITF permutation stats saved in:\n%s\n', outdir);
